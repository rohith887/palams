import {
  AppBar,
  Toolbar,
  Typography,
  Chip,
  IconButton,
  Badge,
  Box,
  useMediaQuery,
  useTheme,
} from '@mui/material';
import MenuIcon from '@mui/icons-material/Menu';
import LogoutIcon from '@mui/icons-material/Logout';
import NotificationsIcon from '@mui/icons-material/Notifications';
import PersonIcon from '@mui/icons-material/Person';

/**
 * PBLMS — Header
 * Pharmaceutical Bin Lifecycle Management System
 *
 * Top header bar displayed on all authenticated portal pages.
 * Shows user full name, role badge (color-coded chip), alert
 * notification icon (Administrator only — with count badge),
 * and logout button (56px minimum height).
 *
 * @param {Object} props
 * @param {Function} props.onMenuToggle — Sidebar toggle callback (mobile)
 * @param {{ fullName: string, role: string }} [props.user] — Current user
 * @param {number} [props.alertCount=0] — Unread alert count
 * @param {Function} [props.onLogout] — Logout handler
 */
export default function Header({ onMenuToggle, user, alertCount = 0, onLogout }) {
  const theme = useTheme();
  const isDesktop = useMediaQuery(theme.breakpoints.up('md'));

  const roleColors = {
    Administrator: '#1a237e',
    Loader: '#1565c0',
    Unloader: '#ef6c00',
    Cleaner: '#2e7d32',
    QA_Inspector: '#6a1b9a',
  };

  return (
    <AppBar
      position="sticky"
      color="inherit"
      elevation={0}
      sx={{
        borderBottom: '1px solid',
        borderColor: 'divider',
        backgroundColor: 'background.paper',
        zIndex: theme.zIndex.drawer + 1,
      }}
    >
      <Toolbar sx={{ minHeight: { xs: 56, sm: 64 }, px: { xs: 2, sm: 3 } }}>
        {/* Mobile menu toggle */}
        {!isDesktop && (
          <IconButton
            edge="start"
            onClick={onMenuToggle}
            sx={{ mr: 1 }}
            aria-label="Toggle sidebar"
          >
            <MenuIcon />
          </IconButton>
        )}

        {/* Left spacer */}
        <Box sx={{ flexGrow: 1 }} />

        {/* User info */}
        {user && (
          <Box sx={{ display: 'flex', alignItems: 'center', gap: { xs: 1, sm: 2 } }}>
            <Box sx={{ display: { xs: 'none', sm: 'flex' }, alignItems: 'center', gap: 1 }}>
              <PersonIcon color="action" fontSize="small" />
              <Typography variant="body2" sx={{ fontWeight: 500 }}>
                {user.fullName}
              </Typography>
            </Box>
            <Chip
              label={user.role?.replace('_', ' ') || 'User'}
              size="small"
              sx={{
                backgroundColor: (roleColors[user.role] || theme.palette.primary.main) + '1A',
                color: roleColors[user.role] || theme.palette.primary.main,
                fontWeight: 600,
                fontSize: '0.75rem',
                height: 28,
              }}
            />

            {/* Alert notification (Administrator only) */}
            {user.role === 'Administrator' && (
              <IconButton
                size="small"
                sx={{ minWidth: 40, minHeight: 40 }}
                aria-label={`${alertCount} unread alerts`}
              >
                <Badge badgeContent={alertCount} color="error" max={99}>
                  <NotificationsIcon color="action" />
                </Badge>
              </IconButton>
            )}

            {/* Logout */}
            <IconButton
              onClick={onLogout}
              size="small"
              sx={{ minWidth: 40, minHeight: 40 }}
              aria-label="Logout"
              title="Logout"
            >
              <LogoutIcon color="action" />
            </IconButton>
          </Box>
        )}

        {/* No user — just show logout placeholder */}
        {!user && (
          <IconButton
            onClick={onLogout}
            size="small"
            sx={{ minWidth: 40, minHeight: 40 }}
            title="Logout"
          >
            <LogoutIcon color="action" />
          </IconButton>
        )}
      </Toolbar>
    </AppBar>
  );
}