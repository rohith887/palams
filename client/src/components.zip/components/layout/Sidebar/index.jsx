import { useLocation, useNavigate } from 'react-router-dom';
import {
  Drawer,
  List,
  ListItem,
  ListItemButton,
  ListItemIcon,
  ListItemText,
  useMediaQuery,
  useTheme,
  Box,
  Typography,
  IconButton,
  Divider,
} from '@mui/material';
import DashboardIcon from '@mui/icons-material/Dashboard';
import InventoryIcon from '@mui/icons-material/Inventory';
import LocationOnIcon from '@mui/icons-material/LocationOn';
import StorageIcon from '@mui/icons-material/Storage';
import ScienceIcon from '@mui/icons-material/Science';
import PeopleIcon from '@mui/icons-material/People';
import AssessmentIcon from '@mui/icons-material/Assessment';
import HistoryIcon from '@mui/icons-material/History';
import TimelineIcon from '@mui/icons-material/Timeline';
import NotificationsIcon from '@mui/icons-material/Notifications';
import QrCodeScannerIcon from '@mui/icons-material/QrCodeScanner';
import ChevronLeftIcon from '@mui/icons-material/ChevronLeft';
import Inventory2Icon from '@mui/icons-material/Inventory2';
import { sidebarConfig } from '../../../constants/routePaths';
import { ROLES, ROLE_LABELS } from '../../../constants/roles';

// Icon mapping per sidebar label
const ICON_MAP = {
  Dashboard: DashboardIcon,
  Bins: InventoryIcon,
  Bays: LocationOnIcon,
  Tanks: StorageIcon,
  Materials: ScienceIcon,
  Users: PeopleIcon,
  Reports: AssessmentIcon,
  'Audit Trail': HistoryIcon,
  'Bin History': TimelineIcon,
  Alerts: NotificationsIcon,
  'Scan & Load': QrCodeScannerIcon,
  'Scan & Unload': QrCodeScannerIcon,
  'Scan & Clean': QrCodeScannerIcon,
  'Scan & Inspect': QrCodeScannerIcon,
};

const DRAWER_WIDTH = 260;
const COLLAPSED_WIDTH = 64;

/**
 * PBLMS — Sidebar
 * Pharmaceutical Bin Lifecycle Management System
 *
 * Persistent left navigation drawer. Reads navigation links from
 * sidebarConfig keyed by role. All nav items minimum 56px tap height.
 * Collapsible on smaller screens.
 *
 * @param {Object} props
 * @param {boolean} props.open — Drawer open state
 * @param {Function} props.onToggle — Toggle callback
 * @param {string} [props.userRole] — Current user role for link filtering
 */
export default function Sidebar({ open = true, onToggle, userRole }) {
  const location = useLocation();
  const navigate = useNavigate();
  const theme = useTheme();
  const isDesktop = useMediaQuery(theme.breakpoints.up('md'));

  const links = sidebarConfig[userRole] || sidebarConfig[ROLES.LOADER] || [];

  // Map each link to include its icon component
  const navLinks = links.map((link) => ({
    ...link,
    Icon: ICON_MAP[link.label] || DashboardIcon,
  }));

  const isActive = (path) => location.pathname === path || location.pathname.startsWith(`${path}/`);

  const drawerWidth = open ? DRAWER_WIDTH : COLLAPSED_WIDTH;

  return (
    <Drawer
      variant={isDesktop ? 'permanent' : 'temporary'}
      open={isDesktop ? true : open}
      onClose={isDesktop ? undefined : onToggle}
      sx={{
        width: drawerWidth,
        flexShrink: 0,
        '& .MuiDrawer-paper': {
          width: drawerWidth,
          boxSizing: 'border-box',
          transition: theme.transitions.create('width', {
            easing: theme.transitions.easing.sharp,
            duration: 200,
          }),
          overflowX: 'hidden',
        },
      }}
    >
      {/* Brand header */}
      <Box
        sx={{
          display: 'flex',
          alignItems: 'center',
          justifyContent: open ? 'space-between' : 'center',
          px: open ? 2 : 0,
          py: 2,
          minHeight: 64,
        }}
      >
        {open && (
          <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
            <Inventory2Icon sx={{ color: 'primary.main' }} />
            <Typography variant="h4" noWrap>PBLMS</Typography>
          </Box>
        )}
        {isDesktop && (
          <IconButton onClick={onToggle} size="small">
            <ChevronLeftIcon />
          </IconButton>
        )}
      </Box>

      <Divider />

      {/* Role badge */}
      {open && userRole && (
        <Box sx={{ px: 2, py: 1.5 }}>
          <Typography variant="caption" color="text.secondary" sx={{ textTransform: 'uppercase', letterSpacing: 1, fontWeight: 500 }}>
            {ROLE_LABELS[userRole] || userRole}
          </Typography>
        </Box>
      )}

      {/* Navigation links */}
      <List sx={{ px: open ? 1 : 0.5 }}>
        {navLinks.map((link) => (
          <ListItem key={link.path} disablePadding sx={{ mb: 0.5 }}>
            <ListItemButton
              onClick={() => navigate(link.path)}
              selected={isActive(link.path)}
              sx={{
                minHeight: 56,
                justifyContent: open ? 'initial' : 'center',
                borderRadius: 1.5,
                px: open ? 2 : 1,
              }}
              title={!open ? link.label : undefined}
            >
              <ListItemIcon
                sx={{
                  minWidth: open ? 40 : 0,
                  mr: open ? 2 : 'auto',
                  justifyContent: 'center',
                  color: isActive(link.path) ? 'primary.main' : 'text.secondary',
                }}
              >
                <link.Icon />
              </ListItemIcon>
              {open && (
                <ListItemText
                  primary={link.label}
                  primaryTypographyProps={{
                    fontSize: '0.875rem',
                    fontWeight: isActive(link.path) ? 600 : 400,
                  }}
                />
              )}
            </ListItemButton>
          </ListItem>
        ))}
      </List>
    </Drawer>
  );
}