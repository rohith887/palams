import { useState, useCallback } from 'react';
import { Outlet } from 'react-router-dom';
import { Box, useMediaQuery, useTheme } from '@mui/material';
import Sidebar from '../Sidebar';
import Header from '../Header';
import ErrorBoundary from '../../common/ErrorBoundary';

const DRAWER_WIDTH = 260;
const COLLAPSED_WIDTH = 64;

/**
 * PBLMS — Portal Layout
 * Pharmaceutical Bin Lifecycle Management System
 *
 * Authenticated pages wrapper: persistent left Sidebar + top Header +
 * main content area (React Router <Outlet />). Registers ErrorBoundary
 * at this level to catch unhandled render errors in any portal page.
 *
 * @param {Object} props
 * @param {{ fullName: string, role: string }} [props.user] — Current user from AuthContext
 * @param {number} [props.alertCount=0] — Unread alert count
 * @param {Function} [props.onLogout] — Logout handler
 */
export default function PortalLayout({ user, alertCount = 0, onLogout }) {
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const theme = useTheme();
  const isDesktop = useMediaQuery(theme.breakpoints.up('md'));

  const handleSidebarToggle = useCallback(() => {
    setSidebarOpen((prev) => !prev);
  }, []);

  const sidebarWidth = sidebarOpen ? DRAWER_WIDTH : COLLAPSED_WIDTH;

  return (
    <Box sx={{ display: 'flex', minHeight: '100vh' }}>
      {/* Persistent sidebar */}
      <Sidebar
        open={sidebarOpen}
        onToggle={handleSidebarToggle}
        userRole={user?.role}
      />

      {/* Header + Content area */}
      <Box
        sx={{
          display: 'flex',
          flexDirection: 'column',
          flexGrow: 1,
          ml: isDesktop ? `${sidebarWidth}px` : 0,
          transition: theme.transitions.create('margin-left', {
            easing: theme.transitions.easing.sharp,
            duration: 200,
          }),
          width: isDesktop ? `calc(100% - ${sidebarWidth}px)` : '100%',
        }}
      >
        <Header
          onMenuToggle={handleSidebarToggle}
          user={user}
          alertCount={alertCount}
          onLogout={onLogout}
        />

        {/* Main content area */}
        <Box
          component="main"
          sx={{
            flexGrow: 1,
            p: { xs: 2, sm: 3 },
            backgroundColor: 'background.default',
            overflow: 'auto',
          }}
        >
          <ErrorBoundary>
            <Outlet />
          </ErrorBoundary>
        </Box>
      </Box>
    </Box>
  );
}