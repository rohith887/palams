-- =============================================================================
-- PBLMS — Complete Database Installation Script
-- Pharmaceutical Bin Lifecycle Management System
--
-- This script concatenates all 28 migrations (000 through 027)
-- in sequential order for deployment on a fresh empty MySQL database.
--
-- Generated: 2026-06-27
-- =============================================================================

-- ============================================================
-- Migration 000: 000_create_schema_migrations_table.sql
-- ============================================================

-- =============================================================================
-- PBLMS — Migration 000: Schema_Migrations Tracking Table
-- Pharmaceutical Bin Lifecycle Management System
-- =============================================================================
-- Purpose:
--   Creates the Schema_Migrations table that tracks which migration files
--   have been applied to the database. The db-migrate.sh script checks this
--   table before applying any migration to prevent duplicate execution.
--
-- Table:
--   Schema_Migrations
--     migration_id  — Sequential primary key
--     filename      — Migration file name (e.g., '001_create_user_master.sql')
--     applied_at    — Timestamp when the migration was applied
--
-- Dependencies: None (this is the first migration applied)
-- =============================================================================

CREATE TABLE IF NOT EXISTS Schema_Migrations (
    migration_id INT AUTO_INCREMENT PRIMARY KEY,
    filename VARCHAR(200) NOT NULL,
    applied_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uq_filename (filename)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- Migration 001: 001_create_user_master.sql
-- ============================================================

-- =============================================================================
-- PBLMS — Migration 001: User_Master and Refresh_Token Tables
-- Pharmaceutical Bin Lifecycle Management System
-- =============================================================================
-- Purpose:
--   Creates the User_Master and Refresh_Token tables required for
--   authentication, session management, and account lockout.
--
-- Tables:
--   User_Master    — Central identity and credential store for all users
--   Refresh_Token  — Server-side refresh token storage with revocation support
--
-- Indexes:
--   UNIQUE on User_Master.Username
--   UNIQUE on Refresh_Token.Token_Hash
--   COMPOSITE on Refresh_Token(User_ID, Is_Revoked)
--
-- Foreign Keys:
--   User_Master.Created_By → User_Master.User_ID (self-referencing, NULL for bootstrap admin)
--   User_Master.Updated_By → User_Master.User_ID (NULL)
--   Refresh_Token.User_ID → User_Master.User_ID
--
-- Dependencies: None (User_Master is a foundational table)
-- Design Spec Reference: Sections 4.2, 4.4
-- =============================================================================

-- ---------------------------------------------------------------------------
-- User_Master — Central user identity table
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS User_Master (
    User_ID INT AUTO_INCREMENT PRIMARY KEY,
    Username VARCHAR(50) NOT NULL,
    Password_Hash VARCHAR(255) NOT NULL,
    Full_Name VARCHAR(150) NOT NULL,
    Role ENUM('Administrator', 'Loader', 'Unloader', 'Cleaner', 'QA_Inspector') NOT NULL,
    Is_Active TINYINT(1) NOT NULL DEFAULT 1,
    Failed_Login_Count TINYINT NOT NULL DEFAULT 0,
    Lockout_Until DATETIME NULL,
    Last_Login_At DATETIME NULL,
    Created_At DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    Created_By INT NULL,
    Updated_At DATETIME NULL,
    Updated_By INT NULL,

    UNIQUE KEY uq_username (Username),
    INDEX idx_role (Role),
    INDEX idx_is_active (Is_Active)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------------
-- Refresh_Token — Server-side refresh token management
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS Refresh_Token (
    Token_ID INT AUTO_INCREMENT PRIMARY KEY,
    User_ID INT NOT NULL,
    Token_Hash VARCHAR(255) NOT NULL,
    Issued_At DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    Expires_At DATETIME NOT NULL,
    Is_Revoked TINYINT(1) NOT NULL DEFAULT 0,
    Device_Info VARCHAR(500) NULL,

    UNIQUE KEY uq_token_hash (Token_Hash),
    INDEX idx_user_revoked (User_ID, Is_Revoked),
    INDEX idx_expires_at (Expires_At),
    CONSTRAINT fk_refresh_token_user
        FOREIGN KEY (User_ID) REFERENCES User_Master(User_ID)
        ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------------
-- Self-referencing foreign keys for audit columns
-- Added via ALTER TABLE after User_Master is created
-- ---------------------------------------------------------------------------
ALTER TABLE User_Master
    ADD CONSTRAINT fk_user_created_by
        FOREIGN KEY (Created_By) REFERENCES User_Master(User_ID)
        ON DELETE SET NULL,
    ADD CONSTRAINT fk_user_updated_by
        FOREIGN KEY (Updated_By) REFERENCES User_Master(User_ID)
        ON DELETE SET NULL;

-- ============================================================
-- Migration 002: 002_seed_admin_user.sql
-- ============================================================

-- =============================================================================
-- PBLMS — Migration 002: Bootstrap Administrator User
-- Pharmaceutical Bin Lifecycle Management System
-- =============================================================================
-- Purpose:
--   Inserts the initial Administrator account into User_Master so that
--   the system can be accessed after deployment. The password is a bcrypt
--   hash with cost factor 12.
--
-- Default Credentials:
--   Username: admin
--   Password: Admin@PBLMS2024!
--   Role:     Administrator
--
-- SECURITY NOTE:
--   The Administrator MUST change this password immediately after first login.
--   This default password should be treated as a shared secret that is only
--   valid during initial system setup. In production, the password should be
--   changed before exposing the system to any network.
--
--   bcrypt hash of 'Admin@PBLMS2024!' with cost factor 12:
--   $2b$12$LJ3m4ys3YOlDkOmMrPJ7OOCCpNn1XGM4FGpWmFJFAzVONtFMiG8LS
--
-- Dependencies: Migration 001 (User_Master table must exist)
-- =============================================================================

INSERT INTO User_Master (Username, Password_Hash, Full_Name, Role, Is_Active, Created_By, Updated_By)
VALUES (
    'admin',
    '$2b$12$LJ3m4ys3YOlDkOmMrPJ7OOCCpNn1XGM4FGpWmFJFAzVONtFMiG8LS',
    'System Administrator',
    'Administrator',
    1,
    NULL,
    NULL
);

-- ============================================================
-- Migration 003: 003_create_auth_procedures.sql
-- ============================================================

-- =============================================================================
-- PBLMS — Migration 003: Authentication Stored Procedures
-- Pharmaceutical Bin Lifecycle Management System
-- =============================================================================
-- Registers the three authentication stored procedures:
--   sp_login          — User lookup with lockout validation
--   sp_refresh_token  — Refresh token validation
--   sp_logout         — Refresh token revocation
-- =============================================================================

-- ---------------------------------------------------------------------------
-- sp_login
-- ---------------------------------------------------------------------------
DELIMITER //

CREATE PROCEDURE sp_login(
    IN  p_username    VARCHAR(50),
    IN  p_ip_address  VARCHAR(45),
    IN  p_user_agent  VARCHAR(500),
    OUT p_success       TINYINT(1),
    OUT p_error_code    VARCHAR(100),
    OUT p_error_message VARCHAR(500)
)
BEGIN
    DECLARE v_user_id        INT;
    DECLARE v_password_hash  VARCHAR(255);
    DECLARE v_full_name      VARCHAR(150);
    DECLARE v_role           VARCHAR(50);
    DECLARE v_is_active      TINYINT(1);
    DECLARE v_failed_count   TINYINT;
    DECLARE v_lockout_until  DATETIME;

    SET p_success = 0;
    SET p_error_code = NULL;
    SET p_error_message = NULL;

    SELECT User_ID, Password_Hash, Full_Name, Role, Is_Active,
           Failed_Login_Count, Lockout_Until
    INTO   v_user_id, v_password_hash, v_full_name, v_role, v_is_active,
           v_failed_count, v_lockout_until
    FROM   User_Master
    WHERE  Username = p_username;

    IF v_user_id IS NULL THEN
        SET p_error_code = 'AUTH_INVALID_CREDENTIALS';
        SET p_error_message = 'Invalid username or password';
    ELSE
        IF v_lockout_until IS NOT NULL AND v_lockout_until > NOW() THEN
            SET p_error_code = 'AUTH_ACCOUNT_LOCKED';
            SET p_error_message = 'Account is locked due to too many failed login attempts';
        ELSE
            SET p_success = 1;
            SELECT v_user_id AS user_id, p_username AS username,
                   v_password_hash AS password_hash, v_full_name AS full_name,
                   v_role AS role, v_is_active AS is_active;
        END IF;
    END IF;
END //

DELIMITER ;

-- ---------------------------------------------------------------------------
-- sp_refresh_token
-- ---------------------------------------------------------------------------
DELIMITER //

CREATE PROCEDURE sp_refresh_token(
    IN  p_token_hash    VARCHAR(255),
    OUT p_success       TINYINT(1),
    OUT p_error_code    VARCHAR(100),
    OUT p_error_message VARCHAR(500)
)
BEGIN
    DECLARE v_user_id   INT;
    DECLARE v_role      VARCHAR(50);
    DECLARE v_full_name VARCHAR(150);

    SET p_success = 0;
    SET p_error_code = NULL;
    SET p_error_message = NULL;

    SELECT rt.User_ID, u.Role, u.Full_Name
    INTO   v_user_id, v_role, v_full_name
    FROM   Refresh_Token rt
           INNER JOIN User_Master u ON u.User_ID = rt.User_ID
    WHERE  rt.Token_Hash = p_token_hash
      AND  rt.Is_Revoked = 0
      AND  rt.Expires_At > NOW();

    IF v_user_id IS NULL THEN
        SET p_error_code = 'AUTH_REFRESH_TOKEN_INVALID';
        SET p_error_message = 'Refresh token is invalid, revoked, or expired';
    ELSE
        SET p_success = 1;
        SELECT v_user_id AS user_id, v_role AS role, v_full_name AS full_name;
    END IF;
END //

DELIMITER ;

-- ---------------------------------------------------------------------------
-- sp_logout
-- ---------------------------------------------------------------------------
DELIMITER //

CREATE PROCEDURE sp_logout(
    IN  p_user_id       INT,
    IN  p_token_hash    VARCHAR(255),
    OUT p_success       TINYINT(1),
    OUT p_error_code    VARCHAR(100),
    OUT p_error_message VARCHAR(500)
)
BEGIN
    SET p_success = 0;
    SET p_error_code = NULL;
    SET p_error_message = NULL;

    UPDATE Refresh_Token
    SET    Is_Revoked = 1
    WHERE  Token_Hash = p_token_hash
      AND  User_ID = p_user_id;

    SET p_success = 1;
END //

DELIMITER ;

-- ============================================================
-- Migration 004: 004_create_master_tables.sql
-- ============================================================

-- =============================================================================
-- PBLMS — Migration 004: Master Data Tables
-- Pharmaceutical Bin Lifecycle Management System
-- =============================================================================
-- Purpose:
--   Creates the five master data tables required before any operational
--   or workflow tables can be created:
--     - Bay_Master        — Physical facility zones
--     - Tank_Master       — Sub-locations within bays
--     - Material_Master   — Validated pharmaceutical materials
--     - Bin_Type_Master   — Physical bin type classifications
--     - Bin_Category_Master — Operational bin category classifications
--
-- Design Spec Reference: Section 4.2
-- Dependencies: Migration 001 (User_Master must exist for FK references)
-- =============================================================================

-- ---------------------------------------------------------------------------
-- Bay_Master — Physical facility zones
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS Bay_Master (
    Bay_ID INT AUTO_INCREMENT PRIMARY KEY,
    Bay_Code VARCHAR(20) NOT NULL,
    Bay_Name VARCHAR(100) NOT NULL,
    Location_Description VARCHAR(500) NULL,
    Is_Active TINYINT(1) NOT NULL DEFAULT 1,
    Created_At DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    Created_By INT NULL,

    UNIQUE KEY uq_bay_code (Bay_Code),
    INDEX idx_is_active (Is_Active),
    CONSTRAINT fk_bay_created_by
        FOREIGN KEY (Created_By) REFERENCES User_Master(User_ID)
        ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------------
-- Tank_Master — Sub-locations within bays
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS Tank_Master (
    Tank_ID INT AUTO_INCREMENT PRIMARY KEY,
    Bay_ID INT NOT NULL,
    Tank_Code VARCHAR(20) NOT NULL,
    Tank_Name VARCHAR(100) NOT NULL,
    Tank_Capacity DECIMAL(10, 3) NULL,
    Is_Active TINYINT(1) NOT NULL DEFAULT 1,
    Created_At DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    Created_By INT NULL,

    UNIQUE KEY uq_tank_code (Tank_Code),
    INDEX idx_bay_id (Bay_ID),
    INDEX idx_is_active (Is_Active),
    CONSTRAINT fk_tank_bay
        FOREIGN KEY (Bay_ID) REFERENCES Bay_Master(Bay_ID)
        ON DELETE RESTRICT,
    CONSTRAINT fk_tank_created_by
        FOREIGN KEY (Created_By) REFERENCES User_Master(User_ID)
        ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------------
-- Material_Master — Validated pharmaceutical materials
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS Material_Master (
    Material_ID INT AUTO_INCREMENT PRIMARY KEY,
    Material_Code VARCHAR(30) NOT NULL,
    Material_Name VARCHAR(200) NOT NULL,
    Material_Category VARCHAR(100) NULL,
    Hazard_Level ENUM('Low', 'Medium', 'High') NOT NULL,
    Storage_Temp_Min_C DECIMAL(5, 2) NULL,
    Storage_Temp_Max_C DECIMAL(5, 2) NULL,
    Handling_Instructions VARCHAR(1000) NULL,
    Is_Active TINYINT(1) NOT NULL DEFAULT 1,
    Created_At DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    Created_By INT NULL,

    UNIQUE KEY uq_material_code (Material_Code),
    INDEX idx_is_active (Is_Active),
    INDEX idx_hazard_level (Hazard_Level),
    CONSTRAINT chk_temp_range CHECK (
        Storage_Temp_Max_C IS NULL OR Storage_Temp_Min_C IS NULL
        OR Storage_Temp_Max_C > Storage_Temp_Min_C
    ),
    CONSTRAINT fk_material_created_by
        FOREIGN KEY (Created_By) REFERENCES User_Master(User_ID)
        ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------------
-- Bin_Type_Master — Physical bin type classifications
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS Bin_Type_Master (
    Bin_Type_ID INT AUTO_INCREMENT PRIMARY KEY,
    Type_Code VARCHAR(30) NOT NULL,
    Type_Name VARCHAR(100) NOT NULL,
    Is_Active TINYINT(1) NOT NULL DEFAULT 1,

    UNIQUE KEY uq_type_code (Type_Code),
    INDEX idx_is_active (Is_Active)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------------
-- Bin_Category_Master — Operational bin category classifications
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS Bin_Category_Master (
    Bin_Category_ID INT AUTO_INCREMENT PRIMARY KEY,
    Category_Code VARCHAR(30) NOT NULL,
    Category_Name VARCHAR(100) NOT NULL,
    Is_Active TINYINT(1) NOT NULL DEFAULT 1,

    UNIQUE KEY uq_category_code (Category_Code),
    INDEX idx_is_active (Is_Active)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- Migration 005: 005_seed_master_data.sql
-- ============================================================

-- =============================================================================
-- PBLMS — Migration 005: Seed Master Data
-- Pharmaceutical Bin Lifecycle Management System
-- =============================================================================
-- Purpose:
--   Seeds sample records into all master data tables for development
--   and testing. These records provide the foundation for operational
--   workflows and UI dropdown population.
--
-- Dependencies: Migration 004 (all master tables must exist)
-- =============================================================================

-- ---------------------------------------------------------------------------
-- Bay_Master — Sample facility zones
-- ---------------------------------------------------------------------------
INSERT INTO Bay_Master (Bay_Code, Bay_Name, Location_Description, Is_Active) VALUES
('BAY-A', 'Production Bay A', 'Main production area — east wing', 1),
('BAY-B', 'Production Bay B', 'Main production area — west wing', 1),
('BAY-C', 'Storage Bay C', 'Cold storage area for temperature-sensitive materials', 1),
('BAY-Q', 'Quarantine Bay Q', 'Holding area for bins awaiting inspection', 1);

-- ---------------------------------------------------------------------------
-- Tank_Master — Sample sub-locations (one tank belongs to exactly one bay)
-- ---------------------------------------------------------------------------
-- BAY-A tanks
SET @bay_a_id = (SELECT Bay_ID FROM Bay_Master WHERE Bay_Code = 'BAY-A');
INSERT INTO Tank_Master (Bay_ID, Tank_Code, Tank_Name, Tank_Capacity, Is_Active) VALUES
(@bay_a_id, 'TNK-A1', 'Reactor Tank A1', 5000.000, 1),
(@bay_a_id, 'TNK-A2', 'Reactor Tank A2', 5000.000, 1),
(@bay_a_id, 'TNK-A3', 'Mixing Tank A3', 3000.000, 1);

-- BAY-B tanks
SET @bay_b_id = (SELECT Bay_ID FROM Bay_Master WHERE Bay_Code = 'BAY-B');
INSERT INTO Tank_Master (Bay_ID, Tank_Code, Tank_Name, Tank_Capacity, Is_Active) VALUES
(@bay_b_id, 'TNK-B1', 'Reactor Tank B1', 5000.000, 1),
(@bay_b_id, 'TNK-B2', 'Blending Tank B2', 4000.000, 1);

-- BAY-C tanks
SET @bay_c_id = (SELECT Bay_ID FROM Bay_Master WHERE Bay_Code = 'BAY-C');
INSERT INTO Tank_Master (Bay_ID, Tank_Code, Tank_Name, Tank_Capacity, Is_Active) VALUES
(@bay_c_id, 'TNK-C1', 'Cold Storage Tank C1', 2000.000, 1);

-- ---------------------------------------------------------------------------
-- Material_Master — Validated pharmaceutical substances
-- ---------------------------------------------------------------------------
INSERT INTO Material_Master (Material_Code, Material_Name, Material_Category, Hazard_Level, Storage_Temp_Min_C, Storage_Temp_Max_C, Handling_Instructions, Is_Active) VALUES
('MAT-001', 'Paracetamol API', 'Active Pharmaceutical Ingredient', 'Low', 15.00, 30.00, 'Store in a dry, well-ventilated area. Avoid direct sunlight.', 1),
('MAT-002', 'Ibuprofen API', 'Active Pharmaceutical Ingredient', 'Low', 15.00, 25.00, 'Keep container tightly closed. Protect from moisture.', 1),
('MAT-003', 'Amoxicillin Trihydrate', 'Antibiotic API', 'Medium', 2.00, 8.00, 'Store refrigerated. Handle with gloves. Avoid inhalation of dust.', 1),
('MAT-004', 'Methylprednisolone', 'Corticosteroid API', 'High', 2.00, 8.00, 'HIGHLY POTENT — Use full PPE. Dedicated equipment required. Consult SOP-PH-042 before handling.', 1),
('MAT-005', 'Sodium Chloride Excipient', 'Excipient', 'Low', NULL, NULL, 'No special handling required. Keep dry.', 1),
('MAT-006', 'Microcrystalline Cellulose', 'Excipient', 'Low', NULL, NULL, 'Avoid dust generation. Use dust mask if ventilation is inadequate.', 1),
('MAT-007', 'Ethanol 96%', 'Solvent', 'High', 10.00, 25.00, 'HIGHLY FLAMMABLE. Store away from ignition sources. Use explosion-proof equipment.', 1);

-- ---------------------------------------------------------------------------
-- Bin_Type_Master — Physical bin type classifications
-- ---------------------------------------------------------------------------
INSERT INTO Bin_Type_Master (Type_Code, Type_Name, Is_Active) VALUES
('IBC', 'Intermediate Bulk Container', 1),
('DRUM', 'Stainless Steel Drum', 1),
('TOTE', 'Plastic Tote', 1),
('BIN-SS', 'Stainless Steel Bin', 1),
('BIN-HD', 'Heavy Duty Poly Bin', 1);

-- ---------------------------------------------------------------------------
-- Bin_Category_Master — Operational category classifications
-- ---------------------------------------------------------------------------
INSERT INTO Bin_Category_Master (Category_Code, Category_Name, Is_Active) VALUES
('PRIMARY', 'Primary Production', 1),
('SECONDARY', 'Secondary Processing', 1),
('QUARANTINE', 'Quarantine / Hold', 1),
('SAMPLING', 'Sampling', 1),
('TRANSPORT', 'Transport / Logistics', 1);

-- ============================================================
-- Migration 006: 006_create_bin_master.sql
-- ============================================================

-- =============================================================================
-- PBLMS — Migration 006: Bin_Master Table
-- Pharmaceutical Bin Lifecycle Management System
-- =============================================================================
-- Purpose:
--   Creates the central Bin_Master table — the state record for every
--   physical bin in the system. This table drives all workflow decisions,
--   dashboard counts, and lock management.
--
--   Row_Version enables optimistic concurrency control.
--   Current_Status FK to Status_Master will be added in Phase 4 (migration 010).
--
-- Design Spec Reference: Section 4.2
-- Dependencies: Migration 004 (Bin_Type_Master, Bin_Category_Master, Bay_Master, Tank_Master)
--               Migration 001 (User_Master for Created_By FK)
-- =============================================================================

CREATE TABLE IF NOT EXISTS Bin_Master (
    Bin_ID INT AUTO_INCREMENT PRIMARY KEY,
    Bin_Number VARCHAR(30) NOT NULL,
    QR_Code_Value VARCHAR(200) NOT NULL,
    Bin_Type_ID INT NOT NULL,
    Bin_Category_ID INT NOT NULL,
    Capacity DECIMAL(10, 3) NOT NULL,
    Capacity_Unit VARCHAR(20) NOT NULL,
    Current_Status VARCHAR(50) NOT NULL DEFAULT 'Awaiting_Loading',
    Current_Bay_ID INT NULL,
    Current_Tank_ID INT NULL,
    Is_Active TINYINT(1) NOT NULL DEFAULT 1,
    Requires_Admin_Review TINYINT(1) NOT NULL DEFAULT 0,
    Requires_QA_Attention TINYINT(1) NOT NULL DEFAULT 0,
    Overdue_Unloading TINYINT(1) NOT NULL DEFAULT 0,
    Consecutive_Fail_Count TINYINT NOT NULL DEFAULT 0,
    Last_QA_Date DATETIME NULL,
    Row_Version INT NOT NULL DEFAULT 1,
    Created_At DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    Created_By INT NULL,
    Updated_At DATETIME NULL,

    UNIQUE KEY uq_bin_number (Bin_Number),
    UNIQUE KEY uq_qr_code_value (QR_Code_Value),
    INDEX idx_current_status (Current_Status),
    INDEX idx_current_bay_id (Current_Bay_ID),
    INDEX idx_is_active (Is_Active),
    INDEX idx_requires_admin_review (Requires_Admin_Review),

    CONSTRAINT chk_capacity_positive CHECK (Capacity > 0),
    CONSTRAINT fk_bin_type
        FOREIGN KEY (Bin_Type_ID) REFERENCES Bin_Type_Master(Bin_Type_ID)
        ON DELETE RESTRICT,
    CONSTRAINT fk_bin_category
        FOREIGN KEY (Bin_Category_ID) REFERENCES Bin_Category_Master(Bin_Category_ID)
        ON DELETE RESTRICT,
    CONSTRAINT fk_bin_bay
        FOREIGN KEY (Current_Bay_ID) REFERENCES Bay_Master(Bay_ID)
        ON DELETE RESTRICT,
    CONSTRAINT fk_bin_tank
        FOREIGN KEY (Current_Tank_ID) REFERENCES Tank_Master(Tank_ID)
        ON DELETE RESTRICT,
    CONSTRAINT fk_bin_created_by
        FOREIGN KEY (Created_By) REFERENCES User_Master(User_ID)
        ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- Migration 007: 007_create_master_procedures.sql
-- ============================================================

-- =============================================================================
-- PBLMS — Migration 007: Master Data Stored Procedures
-- =============================================================================
-- Registers: sp_manage_bay, sp_manage_tank, sp_manage_material
-- =============================================================================

DELIMITER //

CREATE PROCEDURE sp_manage_bay(
    IN  p_action         VARCHAR(20), IN  p_admin_user_id  INT,
    IN  p_bay_id         INT,         IN  p_bay_code       VARCHAR(20),
    IN  p_bay_name       VARCHAR(100),IN  p_location_desc  VARCHAR(500),
    OUT p_success        TINYINT(1),  OUT p_error_code     VARCHAR(100),
    OUT p_error_message  VARCHAR(500)
)
BEGIN
    SET p_success = 0; SET p_error_code = NULL; SET p_error_message = NULL;
    IF p_action = 'CREATE' THEN
        IF EXISTS (SELECT 1 FROM Bay_Master WHERE Bay_Code = p_bay_code) THEN
            SET p_error_code = 'DUPLICATE_ENTRY'; SET p_error_message = CONCAT('Bay code "', p_bay_code, '" already exists');
        ELSE
            INSERT INTO Bay_Master (Bay_Code, Bay_Name, Location_Description, Created_By) VALUES (p_bay_code, p_bay_name, p_location_desc, p_admin_user_id);
            SET p_success = 1; SELECT LAST_INSERT_ID() AS bay_id;
        END IF;
    ELSEIF p_action = 'UPDATE' THEN
        IF NOT EXISTS (SELECT 1 FROM Bay_Master WHERE Bay_ID = p_bay_id) THEN SET p_error_code = 'NOT_FOUND'; SET p_error_message = 'Bay not found';
        ELSE UPDATE Bay_Master SET Bay_Name = p_bay_name, Location_Description = p_location_desc WHERE Bay_ID = p_bay_id; SET p_success = 1; END IF;
    ELSEIF p_action = 'DEACTIVATE' THEN
        IF NOT EXISTS (SELECT 1 FROM Bay_Master WHERE Bay_ID = p_bay_id) THEN SET p_error_code = 'NOT_FOUND'; SET p_error_message = 'Bay not found';
        ELSEIF EXISTS (SELECT 1 FROM Bin_Master WHERE Current_Bay_ID = p_bay_id AND Current_Status NOT IN ('Awaiting_Loading','Retired') AND Is_Active = 1) THEN SET p_error_code = 'LOCATION_IN_USE'; SET p_error_message = 'Cannot deactivate bay with active bin assignments';
        ELSE UPDATE Bay_Master SET Is_Active = 0 WHERE Bay_ID = p_bay_id; UPDATE Tank_Master SET Is_Active = 0 WHERE Bay_ID = p_bay_id; SET p_success = 1; END IF;
    ELSE SET p_error_code = 'VALIDATION_ERROR'; SET p_error_message = CONCAT('Invalid action: ', p_action); END IF;
END //

CREATE PROCEDURE sp_manage_tank(
    IN  p_action          VARCHAR(20),  IN  p_admin_user_id   INT,
    IN  p_tank_id         INT,          IN  p_bay_id          INT,
    IN  p_tank_code       VARCHAR(20),  IN  p_tank_name       VARCHAR(100),
    IN  p_tank_capacity   DECIMAL(10,3),
    OUT p_success         TINYINT(1),   OUT p_error_code      VARCHAR(100),
    OUT p_error_message   VARCHAR(500)
)
BEGIN
    SET p_success = 0; SET p_error_code = NULL; SET p_error_message = NULL;
    IF p_action = 'CREATE' THEN
        IF NOT EXISTS (SELECT 1 FROM Bay_Master WHERE Bay_ID = p_bay_id AND Is_Active = 1) THEN SET p_error_code = 'NOT_FOUND'; SET p_error_message = 'Bay not found or inactive';
        ELSEIF EXISTS (SELECT 1 FROM Tank_Master WHERE Tank_Code = p_tank_code) THEN SET p_error_code = 'DUPLICATE_ENTRY'; SET p_error_message = CONCAT('Tank code "', p_tank_code, '" already exists');
        ELSE INSERT INTO Tank_Master (Bay_ID, Tank_Code, Tank_Name, Tank_Capacity, Created_By) VALUES (p_bay_id, p_tank_code, p_tank_name, p_tank_capacity, p_admin_user_id); SET p_success = 1; SELECT LAST_INSERT_ID() AS tank_id; END IF;
    ELSEIF p_action = 'UPDATE' THEN
        IF NOT EXISTS (SELECT 1 FROM Tank_Master WHERE Tank_ID = p_tank_id) THEN SET p_error_code = 'NOT_FOUND'; SET p_error_message = 'Tank not found';
        ELSE UPDATE Tank_Master SET Tank_Name = p_tank_name, Tank_Capacity = p_tank_capacity, Bay_ID = p_bay_id WHERE Tank_ID = p_tank_id; SET p_success = 1; END IF;
    ELSEIF p_action = 'DEACTIVATE' THEN
        IF NOT EXISTS (SELECT 1 FROM Tank_Master WHERE Tank_ID = p_tank_id) THEN SET p_error_code = 'NOT_FOUND'; SET p_error_message = 'Tank not found';
        ELSEIF EXISTS (SELECT 1 FROM Bin_Master WHERE Current_Tank_ID = p_tank_id AND Current_Status NOT IN ('Awaiting_Loading','Retired') AND Is_Active = 1) THEN SET p_error_code = 'LOCATION_IN_USE'; SET p_error_message = 'Cannot deactivate tank with active bin assignments';
        ELSE UPDATE Tank_Master SET Is_Active = 0 WHERE Tank_ID = p_tank_id; SET p_success = 1; END IF;
    ELSE SET p_error_code = 'VALIDATION_ERROR'; SET p_error_message = CONCAT('Invalid action: ', p_action); END IF;
END //

CREATE PROCEDURE sp_manage_material(
    IN  p_action                VARCHAR(20),  IN  p_admin_user_id         INT,
    IN  p_material_id           INT,          IN  p_material_code         VARCHAR(30),
    IN  p_material_name         VARCHAR(200), IN  p_material_category     VARCHAR(100),
    IN  p_hazard_level          VARCHAR(10),  IN  p_temp_min              DECIMAL(5,2),
    IN  p_temp_max              DECIMAL(5,2), IN  p_handling_instructions VARCHAR(1000),
    OUT p_success               TINYINT(1),   OUT p_error_code            VARCHAR(100),
    OUT p_error_message         VARCHAR(500)
)
BEGIN
    SET p_success = 0; SET p_error_code = NULL; SET p_error_message = NULL;
    IF p_hazard_level NOT IN ('Low','Medium','High') THEN SET p_error_code = 'VALIDATION_ERROR'; SET p_error_message = 'Hazard_Level must be Low, Medium, or High';
    ELSEIF p_temp_min IS NOT NULL AND p_temp_max IS NOT NULL AND p_temp_max <= p_temp_min THEN SET p_error_code = 'VALIDATION_ERROR'; SET p_error_message = 'Max temperature must exceed Min temperature';
    ELSEIF p_action = 'CREATE' THEN
        IF EXISTS (SELECT 1 FROM Material_Master WHERE Material_Code = p_material_code) THEN SET p_error_code = 'DUPLICATE_ENTRY'; SET p_error_message = CONCAT('Material code "', p_material_code, '" already exists');
        ELSE INSERT INTO Material_Master (Material_Code, Material_Name, Material_Category, Hazard_Level, Storage_Temp_Min_C, Storage_Temp_Max_C, Handling_Instructions, Created_By) VALUES (p_material_code, p_material_name, p_material_category, p_hazard_level, p_temp_min, p_temp_max, p_handling_instructions, p_admin_user_id); SET p_success = 1; SELECT LAST_INSERT_ID() AS material_id; END IF;
    ELSEIF p_action = 'UPDATE' THEN
        IF NOT EXISTS (SELECT 1 FROM Material_Master WHERE Material_ID = p_material_id) THEN SET p_error_code = 'NOT_FOUND'; SET p_error_message = 'Material not found';
        ELSE UPDATE Material_Master SET Material_Name = p_material_name, Material_Category = p_material_category, Hazard_Level = p_hazard_level, Storage_Temp_Min_C = p_temp_min, Storage_Temp_Max_C = p_temp_max, Handling_Instructions = p_handling_instructions WHERE Material_ID = p_material_id; SET p_success = 1; END IF;
    ELSEIF p_action = 'DEACTIVATE' THEN
        IF NOT EXISTS (SELECT 1 FROM Material_Master WHERE Material_ID = p_material_id) THEN SET p_error_code = 'NOT_FOUND'; SET p_error_message = 'Material not found';
        ELSE UPDATE Material_Master SET Is_Active = 0 WHERE Material_ID = p_material_id; SET p_success = 1; END IF;
    ELSE SET p_error_code = 'VALIDATION_ERROR'; SET p_error_message = CONCAT('Invalid action: ', p_action); END IF;
END //

DELIMITER ;

-- ============================================================
-- Migration 008: 008_create_bin_registration_procedure.sql
-- ============================================================

-- PBLMS — Migration 008: sp_register_bin
DELIMITER //
CREATE PROCEDURE sp_register_bin(
    IN  p_admin_user_id    INT, IN  p_bin_number       VARCHAR(30),
    IN  p_qr_code_value    VARCHAR(200), IN  p_bin_type_id      INT,
    IN  p_bin_category_id  INT, IN  p_capacity         DECIMAL(10,3),
    IN  p_capacity_unit    VARCHAR(20),
    OUT p_success          TINYINT(1), OUT p_error_code VARCHAR(100), OUT p_error_message VARCHAR(500)
)
BEGIN
    SET p_success = 0; SET p_error_code = NULL; SET p_error_message = NULL;
    IF EXISTS (SELECT 1 FROM Bin_Master WHERE Bin_Number = p_bin_number) THEN
        SET p_error_code = 'DUPLICATE_ENTRY'; SET p_error_message = CONCAT('Bin number "', p_bin_number, '" already exists');
    ELSEIF EXISTS (SELECT 1 FROM Bin_Master WHERE QR_Code_Value = p_qr_code_value) THEN
        SET p_error_code = 'DUPLICATE_ENTRY'; SET p_error_message = 'QR code value already in use';
    ELSEIF NOT EXISTS (SELECT 1 FROM Bin_Type_Master WHERE Bin_Type_ID = p_bin_type_id AND Is_Active = 1) THEN
        SET p_error_code = 'VALIDATION_ERROR'; SET p_error_message = 'Bin type not found or inactive';
    ELSEIF NOT EXISTS (SELECT 1 FROM Bin_Category_Master WHERE Bin_Category_ID = p_bin_category_id AND Is_Active = 1) THEN
        SET p_error_code = 'VALIDATION_ERROR'; SET p_error_message = 'Bin category not found or inactive';
    ELSEIF p_capacity <= 0 THEN
        SET p_error_code = 'VALIDATION_ERROR'; SET p_error_message = 'Capacity must be greater than zero';
    ELSE
        INSERT INTO Bin_Master (Bin_Number, QR_Code_Value, Bin_Type_ID, Bin_Category_ID, Capacity, Capacity_Unit, Current_Status, Row_Version, Created_By)
        VALUES (p_bin_number, p_qr_code_value, p_bin_type_id, p_bin_category_id, p_capacity, p_capacity_unit, 'Awaiting_Loading', 1, p_admin_user_id);
        SET p_success = 1; SELECT LAST_INSERT_ID() AS bin_id;
    END IF;
END //
DELIMITER ;

-- ============================================================
-- Migration 009: 009_create_user_management_procedure.sql
-- ============================================================

-- =============================================================================
-- PBLMS — Migration 009: User Management Stored Procedure (INSERTED AFTER 008)
-- =============================================================================
-- Purpose:
--   Creates sp_manage_user — a single stored procedure handling CREATE and
--   UPDATE actions on User_Master.  Passwords received from the service layer
--   are already bcrypt-hashed; no hashing occurs in MySQL.
--
--   Role changes are recorded in Audit_Log as specified by the design.
--
-- Design Spec Reference: Section 9.5 (sp_manage_user)
-- Tasks Reference: PBLMS-3-04
-- Dependencies: Migration 001 (User_Master), Migration 015 (Audit_Log — runtime only)
--
-- Note: This migration is numbered 009 even though it is being applied after
--       later-numbered migrations.  It fits logically between 008 (bin
--       registration) and 010 (workflow tables).  No renumbering of existing
--       migrations is required.
-- =============================================================================

DELIMITER //

CREATE PROCEDURE sp_manage_user(
    IN  p_admin_user_id    INT,
    IN  p_action           VARCHAR(10),    -- 'CREATE' or 'UPDATE'
    IN  p_target_user_id   INT,            -- required for UPDATE; NULL for CREATE
    IN  p_username         VARCHAR(50),    -- required for CREATE
    IN  p_password_hash    VARCHAR(255),   -- bcrypt hash from service layer; required for CREATE
    IN  p_full_name        VARCHAR(150),   -- required
    IN  p_role             VARCHAR(20),    -- required; validated against User_Master.Role enum
    IN  p_is_active        TINYINT(1),     -- only used on UPDATE; NULL means "no change"
    OUT p_success          TINYINT(1),
    OUT p_error_code       VARCHAR(100),
    OUT p_error_message    VARCHAR(500)
)
BEGIN
    DECLARE v_old_role VARCHAR(20);

    SET p_success = 0;
    SET p_error_code = NULL;
    SET p_error_message = NULL;

    -- ------------------------------------------------------------------
    -- Validate action
    -- ------------------------------------------------------------------
    IF p_action NOT IN ('CREATE', 'UPDATE') THEN
        SET p_error_code = 'VALIDATION_ERROR';
        SET p_error_message = 'Action must be CREATE or UPDATE';
        LEAVE sp_mu_label;
    END IF;

    -- ------------------------------------------------------------------
    -- CREATE
    -- ------------------------------------------------------------------
    IF p_action = 'CREATE' THEN
        -- All CREATE fields are mandatory
        IF p_username IS NULL OR p_password_hash IS NULL OR p_full_name IS NULL OR p_role IS NULL THEN
            SET p_error_code = 'VALIDATION_ERROR';
            SET p_error_message = 'Username, password, full name, and role are required';
            LEAVE sp_mu_label;
        END IF;

        -- Validate role
        IF p_role NOT IN ('Administrator', 'Loader', 'Unloader', 'Cleaner', 'QA_Inspector') THEN
            SET p_error_code = 'VALIDATION_ERROR';
            SET p_error_message = 'Invalid role. Must be Administrator, Loader, Unloader, Cleaner, or QA_Inspector';
            LEAVE sp_mu_label;
        END IF;

        -- Check duplicate username
        IF EXISTS (SELECT 1 FROM User_Master WHERE Username = p_username) THEN
            SET p_error_code = 'DUPLICATE_ENTRY';
            SET p_error_message = CONCAT('Username "', p_username, '" already exists');
            LEAVE sp_mu_label;
        END IF;

        INSERT INTO User_Master (Username, Password_Hash, Full_Name, Role, Created_By)
        VALUES (p_username, p_password_hash, p_full_name, p_role, p_admin_user_id);

        SET p_success = 1;
        SELECT LAST_INSERT_ID() AS user_id;
        LEAVE sp_mu_label;
    END IF;

    -- ------------------------------------------------------------------
    -- UPDATE
    -- ------------------------------------------------------------------
    IF p_action = 'UPDATE' THEN
        -- Target user must exist
        IF p_target_user_id IS NULL OR NOT EXISTS (SELECT 1 FROM User_Master WHERE User_ID = p_target_user_id) THEN
            SET p_error_code = 'NOT_FOUND';
            SET p_error_message = 'User not found';
            LEAVE sp_mu_label;
        END IF;

        -- Capture old role before any changes (for audit)
        SELECT Role INTO v_old_role FROM User_Master WHERE User_ID = p_target_user_id;

        -- Build UPDATE dynamically — only set provided fields
        -- Full_Name is always provided on UPDATE
        IF p_full_name IS NOT NULL THEN
            UPDATE User_Master SET Full_Name = p_full_name, Updated_At = NOW(), Updated_By = p_admin_user_id
            WHERE User_ID = p_target_user_id;
        END IF;

        -- Role change
        IF p_role IS NOT NULL AND p_role != '' THEN
            IF p_role NOT IN ('Administrator', 'Loader', 'Unloader', 'Cleaner', 'QA_Inspector') THEN
                SET p_error_code = 'VALIDATION_ERROR';
                SET p_error_message = 'Invalid role. Must be Administrator, Loader, Unloader, Cleaner, or QA_Inspector';
                LEAVE sp_mu_label;
            END IF;

            UPDATE User_Master SET Role = p_role, Updated_At = NOW(), Updated_By = p_admin_user_id
            WHERE User_ID = p_target_user_id;

            -- Record role change in Audit_Log
            IF v_old_role != p_role THEN
                INSERT INTO Audit_Log (Actor_User_ID, Action_Type, Target_Entity, Target_ID,
                    Old_Value, New_Value)
                VALUES (p_admin_user_id, 'ROLE_CHANGED', 'User_Master', p_target_user_id,
                    CONCAT('{"role":"', v_old_role, '"}'),
                    CONCAT('{"role":"', p_role, '"}'));
            END IF;
        END IF;

        -- Is_Active change
        IF p_is_active IS NOT NULL THEN
            UPDATE User_Master SET Is_Active = p_is_active, Updated_At = NOW(), Updated_By = p_admin_user_id
            WHERE User_ID = p_target_user_id;
        END IF;

        SET p_success = 1;
        LEAVE sp_mu_label;
    END IF;

    sp_mu_label: BEGIN END;
END //

DELIMITER ;

-- ============================================================
-- Migration 010: 010_create_workflow_tables.sql
-- ============================================================

-- Migration 010: Status_Master + Transition_Master tables + FK to Bin_Master
CREATE TABLE IF NOT EXISTS Status_Master (
    Status_Code VARCHAR(50) PRIMARY KEY,
    Status_Label VARCHAR(100) NOT NULL,
    Display_Order INT NOT NULL DEFAULT 0,
    Is_Terminal TINYINT(1) NOT NULL DEFAULT 0,
    Description VARCHAR(500) NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS Transition_Master (
    Transition_ID INT AUTO_INCREMENT PRIMARY KEY,
    From_Status VARCHAR(50) NOT NULL,
    To_Status VARCHAR(50) NOT NULL,
    Permitted_Role VARCHAR(50) NOT NULL,
    Operation_Type VARCHAR(50) NOT NULL,
    Requires_Lock TINYINT(1) NOT NULL DEFAULT 1,
    Description VARCHAR(500) NULL,
    UNIQUE KEY uq_transition (From_Status, To_Status, Permitted_Role),
    INDEX idx_from_status (From_Status),
    INDEX idx_to_status (To_Status),
    CONSTRAINT fk_transition_from FOREIGN KEY (From_Status) REFERENCES Status_Master(Status_Code) ON DELETE RESTRICT,
    CONSTRAINT fk_transition_to   FOREIGN KEY (To_Status)   REFERENCES Status_Master(Status_Code) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

ALTER TABLE Bin_Master ADD CONSTRAINT fk_bin_current_status
    FOREIGN KEY (Current_Status) REFERENCES Status_Master(Status_Code) ON DELETE RESTRICT;

-- ============================================================
-- Migration 011: 011_seed_status_and_transitions.sql
-- ============================================================

-- Migration 011: Seed all 13 lifecycle statuses and 15 workflow transitions
-- Statuses (design spec section 6.1)
INSERT INTO Status_Master (Status_Code, Status_Label, Display_Order, Is_Terminal, Description) VALUES
('Awaiting_Loading',       'Awaiting Loading',        1,  0, 'Bin ready for loading operation'),
('Loading_In_Progress',    'Loading In Progress',     2,  0, 'Loader actively filling the bin'),
('Awaiting_Unloading',     'Awaiting Unloading',      3,  0, 'Bin loaded, awaiting unloading'),
('Unloading_In_Progress',  'Unloading In Progress',   4,  0, 'Unloader actively emptying the bin'),
('Awaiting_Cleaning',      'Awaiting Cleaning',       5,  0, 'Bin emptied, needs cleaning'),
('Cleaning_In_Progress',   'Cleaning In Progress',    6,  0, 'Cleaner actively cleaning the bin'),
('Awaiting_QA',            'Awaiting QA',             7,  0, 'Bin cleaned, awaiting QA inspection'),
('QA_In_Progress',         'QA In Progress',          8,  0, 'QA Inspector evaluating the bin'),
('QA_Passed',              'QA Passed',               9,  0, 'Bin passed QA inspection'),
('QA_Failed',              'QA Failed',               10, 0, 'Bin failed QA inspection'),
('Reinspection_Cleaning',  'Reinspection Cleaning',   11, 0, 'Bin needs re-cleaning after QA failure'),
('Awaiting_Reinspection',  'Awaiting Reinspection',   12, 0, 'Bin re-cleaned, awaiting re-inspection'),
('Retired',                'Retired',                 13, 1, 'Bin permanently retired from service');

-- 15 transitions (design spec table 5.2)
INSERT INTO Transition_Master (From_Status, To_Status, Permitted_Role, Operation_Type, Requires_Lock, Description) VALUES
('Awaiting_Loading',       'Loading_In_Progress',   'Loader',         'START_LOADING',       1, 'Loader starts loading'),
('Loading_In_Progress',    'Awaiting_Unloading',    'Loader',         'COMPLETE_LOADING',    1, 'Loader completes loading'),
('Awaiting_Unloading',     'Unloading_In_Progress',  'Unloader',       'START_UNLOADING',     1, 'Unloader starts unloading'),
('Unloading_In_Progress',  'Awaiting_Cleaning',     'Unloader',       'COMPLETE_UNLOADING',  1, 'Unloader completes unloading'),
('Awaiting_Cleaning',      'Cleaning_In_Progress',  'Cleaner',        'START_CLEANING',      1, 'Cleaner starts cleaning'),
('Cleaning_In_Progress',   'Awaiting_QA',           'Cleaner',        'COMPLETE_CLEANING',   1, 'Cleaner completes cleaning'),
('Awaiting_QA',            'QA_In_Progress',        'QA_Inspector',   'START_QA',            1, 'QA Inspector starts inspection'),
('QA_In_Progress',         'QA_Passed',             'QA_Inspector',   'COMPLETE_QA_PASS',    1, 'QA Inspector marks PASS'),
('QA_Passed',              'Awaiting_Loading',      'System',         'CYCLE_RESET',         0, 'Auto: bin returns to loading pool'),
('QA_In_Progress',         'QA_Failed',             'QA_Inspector',   'COMPLETE_QA_FAIL',    1, 'QA Inspector marks FAIL'),
('QA_Failed',              'Reinspection_Cleaning', 'System',         'REINSPECTION_TRIGGER',0, 'Auto: bin sent for re-cleaning'),
('Reinspection_Cleaning',  'Cleaning_In_Progress',  'Cleaner',        'START_CLEANING',      1, 'Cleaner starts reinspection cleaning'),
('Awaiting_Reinspection',  'QA_In_Progress',        'QA_Inspector',   'START_QA',            1, 'QA Inspector starts re-inspection'),
('Awaiting_Loading',       'Retired',               'Administrator',  'RETIRE_BIN',          0, 'Administrator retires bin'),
('Any',                    'Any',                   'Administrator',  'ADMIN_LOCK_RELEASE',  0, 'Administrator forcibly releases lock');

-- ============================================================
-- Migration 012: 012_create_workflow_validation_procedure.sql
-- ============================================================

-- Migration 012: sp_validate_workflow_transition — single gatekeeper
DELIMITER //
CREATE PROCEDURE sp_validate_workflow_transition(
    IN  p_bin_id        INT,          IN  p_from_status   VARCHAR(50),
    IN  p_to_status     VARCHAR(50),  IN  p_user_role     VARCHAR(50),
    IN  p_row_version   INT,
    OUT p_success       TINYINT(1),   OUT p_error_code    VARCHAR(100),
    OUT p_error_message VARCHAR(500)
)
BEGIN
    DECLARE v_is_active TINYINT(1);   DECLARE v_current_status VARCHAR(50);
    DECLARE v_requires_admin TINYINT(1) DEFAULT 0;
    DECLARE v_current_row_version INT;
    DECLARE v_requires_lock TINYINT(1); DECLARE v_operation_type VARCHAR(50);
    DECLARE v_permitted_role VARCHAR(50);
    SET p_success=0; SET p_error_code=NULL; SET p_error_message=NULL;
    SELECT Is_Active,Current_Status,Requires_Admin_Review,Row_Version
    INTO v_is_active,v_current_status,v_requires_admin,v_current_row_version
    FROM Bin_Master WHERE Bin_ID=p_bin_id;
    IF v_current_row_version IS NULL THEN SET p_error_code='BIN_NOT_FOUND'; SET p_error_message='Bin not found';
    ELSEIF v_is_active=0 THEN SET p_error_code='BIN_INACTIVE'; SET p_error_message='Bin is inactive';
    ELSEIF v_current_status='Retired' THEN SET p_error_code='BIN_RETIRED'; SET p_error_message='Bin has been retired';
    ELSEIF v_requires_admin=1 THEN SET p_error_code='ADMIN_REVIEW_REQUIRED'; SET p_error_message='Bin requires Administrator review';
    ELSEIF v_current_row_version<>p_row_version THEN SET p_error_code='CONCURRENT_MODIFICATION_CONFLICT'; SET p_error_message='Bin modified by another user. Re-scan.';
    ELSE
        SELECT Requires_Lock,Operation_Type,Permitted_Role
        INTO v_requires_lock,v_operation_type,v_permitted_role
        FROM Transition_Master
        WHERE From_Status=p_from_status AND To_Status=p_to_status
          AND (Permitted_Role=p_user_role OR Permitted_Role='System');
        IF v_operation_type IS NULL THEN
            IF EXISTS(SELECT 1 FROM Transition_Master WHERE From_Status=p_from_status AND To_Status=p_to_status) THEN
                SET p_error_code='RBAC_FORBIDDEN'; SET p_error_message='Insufficient permissions';
            ELSE SET p_error_code='INVALID_TRANSITION'; SET p_error_message=CONCAT('Invalid transition from ',p_from_status,' to ',p_to_status); END IF;
        ELSE SET p_success=1; SELECT v_requires_lock AS requires_lock, v_operation_type AS operation_type; END IF;
    END IF;
END //
DELIMITER ;

-- ============================================================
-- Migration 013: 013_create_lock_table.sql
-- ============================================================

-- Migration 013: Lock_Table for concurrent bin operation exclusion
CREATE TABLE IF NOT EXISTS Lock_Table (
    Lock_ID INT AUTO_INCREMENT PRIMARY KEY,
    Bin_ID INT NOT NULL,
    Locked_By_User_ID INT NOT NULL,
    Lock_Timestamp DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    Operation_Type VARCHAR(50) NOT NULL,
    Expires_At DATETIME NOT NULL,
    UNIQUE KEY uq_bin_lock (Bin_ID),
    INDEX idx_expires_at (Expires_At),
    INDEX idx_locked_by (Locked_By_User_ID),
    CONSTRAINT fk_lock_bin
        FOREIGN KEY (Bin_ID) REFERENCES Bin_Master(Bin_ID)
        ON DELETE RESTRICT,
    CONSTRAINT fk_lock_user
        FOREIGN KEY (Locked_By_User_ID) REFERENCES User_Master(User_ID)
        ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- Migration 014: 014_create_lock_procedures.sql
-- ============================================================

-- Migration 014: sp_acquire_lock + sp_release_lock
DELIMITER //
CREATE PROCEDURE sp_acquire_lock(
    IN  p_bin_id                INT,          IN  p_user_id               INT,
    IN  p_operation_type        VARCHAR(50),  IN  p_lock_duration_minutes INT,
    OUT p_success               TINYINT(1),   OUT p_error_code            VARCHAR(100),
    OUT p_error_message         VARCHAR(500)
)
BEGIN
    DECLARE v_bin_exists TINYINT(1) DEFAULT 0; DECLARE v_existing_lock_id INT;
    DECLARE v_lock_expires DATETIME;           DECLARE v_lock_holder_id INT;
    DECLARE v_lock_holder_name VARCHAR(150);   DECLARE v_new_lock_id INT;
    DECLARE v_expires_at DATETIME;
    SET p_success=0; SET p_error_code=NULL; SET p_error_message=NULL;
    IF p_lock_duration_minutes IS NULL OR p_lock_duration_minutes<=0 THEN SET p_lock_duration_minutes=60; END IF;
    SELECT COUNT(*) INTO v_bin_exists FROM Bin_Master WHERE Bin_ID=p_bin_id;
    IF v_bin_exists=0 THEN SET p_error_code='BIN_NOT_FOUND'; SET p_error_message='Bin not found';
    ELSE START TRANSACTION;
        SELECT l.Lock_ID,l.Expires_At,l.Locked_By_User_ID,u.Full_Name
        INTO v_existing_lock_id,v_lock_expires,v_lock_holder_id,v_lock_holder_name
        FROM Lock_Table l LEFT JOIN User_Master u ON u.User_ID=l.Locked_By_User_ID WHERE l.Bin_ID=p_bin_id;
        IF v_existing_lock_id IS NOT NULL THEN
            IF v_lock_expires<=NOW() THEN DELETE FROM Lock_Table WHERE Lock_ID=v_existing_lock_id;
            ELSEIF v_lock_holder_id=p_user_id THEN SET p_success=1; SELECT v_existing_lock_id AS lock_id,v_lock_expires AS lock_expires_at; COMMIT;
            ELSE SET p_error_code='BIN_OPERATION_IN_PROGRESS'; SET p_error_message=CONCAT('Locked by ',v_lock_holder_name); ROLLBACK; SELECT v_lock_holder_name AS locked_by_name; END IF;
        END IF;
        IF p_success=0 AND p_error_code IS NULL THEN
            SET v_expires_at=DATE_ADD(NOW(),INTERVAL p_lock_duration_minutes MINUTE);
            INSERT INTO Lock_Table(Bin_ID,Locked_By_User_ID,Operation_Type,Expires_At) VALUES(p_bin_id,p_user_id,p_operation_type,v_expires_at);
            SET v_new_lock_id=LAST_INSERT_ID(); SET p_success=1;
            SELECT v_new_lock_id AS lock_id, v_expires_at AS lock_expires_at; COMMIT;
        END IF;
    END IF;
END //

CREATE PROCEDURE sp_release_lock(
    IN  p_bin_id        INT,  IN  p_user_id       INT,
    OUT p_success       TINYINT(1), OUT p_error_code VARCHAR(100), OUT p_error_message VARCHAR(500)
)
BEGIN
    DECLARE v_rows INT DEFAULT 0;
    SET p_success=0; SET p_error_code=NULL; SET p_error_message=NULL;
    START TRANSACTION;
    DELETE FROM Lock_Table WHERE Bin_ID=p_bin_id AND Locked_By_User_ID=p_user_id;
    SET v_rows=ROW_COUNT(); SET p_success=1; SELECT v_rows AS rows_deleted; COMMIT;
END //
DELIMITER ;

-- ============================================================
-- Migration 015: 015_create_history_audit_tables.sql
-- ============================================================

-- Migration 015: Bin_History + Audit_Log immutable tables
CREATE TABLE IF NOT EXISTS Bin_History (
    History_ID INT AUTO_INCREMENT PRIMARY KEY,
    Bin_ID INT NOT NULL,
    Previous_Status VARCHAR(50) NOT NULL,
    New_Status VARCHAR(50) NOT NULL,
    Acting_User_ID INT NOT NULL,
    Operation_Type VARCHAR(50) NOT NULL,
    Operation_Record_ID INT NULL,
    Operation_Record_Type VARCHAR(30) NULL,
    Remarks VARCHAR(500) NULL,
    Cycle_Number INT NULL,
    Event_Timestamp DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_bin_timestamp (Bin_ID, Event_Timestamp),
    INDEX idx_acting_user (Acting_User_ID),
    CONSTRAINT fk_history_bin FOREIGN KEY (Bin_ID) REFERENCES Bin_Master(Bin_ID) ON DELETE RESTRICT,
    CONSTRAINT fk_history_user FOREIGN KEY (Acting_User_ID) REFERENCES User_Master(User_ID) ON DELETE RESTRICT,
    CONSTRAINT fk_history_prev FOREIGN KEY (Previous_Status) REFERENCES Status_Master(Status_Code) ON DELETE RESTRICT,
    CONSTRAINT fk_history_new  FOREIGN KEY (New_Status) REFERENCES Status_Master(Status_Code) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS Audit_Log (
    Audit_ID INT AUTO_INCREMENT PRIMARY KEY,
    Actor_User_ID INT NULL,
    Action_Type VARCHAR(100) NOT NULL,
    Target_Entity VARCHAR(50) NULL,
    Target_ID INT NULL,
    Old_Value JSON NULL,
    New_Value JSON NULL,
    IP_Address VARCHAR(45) NULL,
    User_Agent VARCHAR(500) NULL,
    Event_Timestamp DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_actor_timestamp (Actor_User_ID, Event_Timestamp),
    INDEX idx_action_type (Action_Type),
    INDEX idx_target (Target_Entity, Target_ID),
    CONSTRAINT fk_audit_actor FOREIGN KEY (Actor_User_ID) REFERENCES User_Master(User_ID) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- Migration 016: 016_create_history_audit_procedures.sql
-- ============================================================

-- Migration 016: sp_insert_bin_history + sp_insert_audit_log
DELIMITER //

CREATE PROCEDURE sp_insert_bin_history(
    IN  p_bin_id INT, IN p_previous_status VARCHAR(50), IN p_new_status VARCHAR(50),
    IN  p_acting_user_id INT, IN p_operation_type VARCHAR(50),
    IN  p_operation_record_id INT, IN p_operation_record_type VARCHAR(30),
    IN  p_remarks VARCHAR(500), IN p_cycle_number INT,
    OUT p_success TINYINT(1), OUT p_error_code VARCHAR(100), OUT p_error_message VARCHAR(500)
)
BEGIN
    SET p_success=0; SET p_error_code=NULL; SET p_error_message=NULL;
    INSERT INTO Bin_History(Bin_ID,Previous_Status,New_Status,Acting_User_ID,Operation_Type,Operation_Record_ID,Operation_Record_Type,Remarks,Cycle_Number)
    VALUES(p_bin_id,p_previous_status,p_new_status,p_acting_user_id,p_operation_type,p_operation_record_id,p_operation_record_type,p_remarks,p_cycle_number);
    SET p_success=1; SELECT LAST_INSERT_ID() AS history_id;
END //

CREATE PROCEDURE sp_insert_audit_log(
    IN  p_actor_user_id INT, IN p_action_type VARCHAR(100), IN p_target_entity VARCHAR(50),
    IN  p_target_id INT, IN p_old_value JSON, IN p_new_value JSON,
    IN  p_ip_address VARCHAR(45), IN p_user_agent VARCHAR(500),
    OUT p_success TINYINT(1), OUT p_error_code VARCHAR(100), OUT p_error_message VARCHAR(500)
)
BEGIN
    SET p_success=0; SET p_error_code=NULL; SET p_error_message=NULL;
    INSERT INTO Audit_Log(Actor_User_ID,Action_Type,Target_Entity,Target_ID,Old_Value,New_Value,IP_Address,User_Agent)
    VALUES(p_actor_user_id,p_action_type,p_target_entity,p_target_id,p_old_value,p_new_value,p_ip_address,p_user_agent);
    SET p_success=1; SELECT LAST_INSERT_ID() AS audit_id;
END //

DELIMITER ;

-- ============================================================
-- Migration 017: 017_create_loading_record.sql
-- ============================================================

-- =============================================================================
-- PBLMS — Migration 017: Loading_Record Transaction Table
-- Pharmaceutical Bin Lifecycle Management System
-- =============================================================================
-- Design Spec Reference: Section 4.3
-- Dependencies:
--   Migration 006 (Bin_Master)
--   Migration 001 (User_Master)
--   Migration 004 (Bay_Master, Tank_Master, Material_Master)
-- =============================================================================

CREATE TABLE IF NOT EXISTS Loading_Record (
    Loading_ID INT AUTO_INCREMENT PRIMARY KEY,
    Bin_ID INT NOT NULL,
    Loader_User_ID INT NOT NULL,
    Bay_ID INT NOT NULL,
    Tank_ID INT NOT NULL,
    Material_ID INT NOT NULL,
    Quantity_Loaded DECIMAL(10, 3) NOT NULL,
    Unit_Of_Measure VARCHAR(20) NOT NULL,
    Batch_Number VARCHAR(100) NOT NULL,
    Expected_Unloading_Date DATE NOT NULL,
    Loading_Start_At DATETIME NOT NULL,
    Loading_Completed_At DATETIME NULL,
    Comments VARCHAR(500) NULL,
    Is_Current TINYINT(1) NOT NULL DEFAULT 1,

    INDEX idx_bin_id (Bin_ID),
    INDEX idx_loader_user (Loader_User_ID),
    INDEX idx_expected_unloading (Expected_Unloading_Date, Is_Current),
    INDEX idx_material (Material_ID),

    CONSTRAINT chk_quantity_positive CHECK (Quantity_Loaded > 0),

    CONSTRAINT fk_loading_bin
        FOREIGN KEY (Bin_ID) REFERENCES Bin_Master(Bin_ID)
        ON DELETE RESTRICT,
    CONSTRAINT fk_loading_loader
        FOREIGN KEY (Loader_User_ID) REFERENCES User_Master(User_ID)
        ON DELETE RESTRICT,
    CONSTRAINT fk_loading_bay
        FOREIGN KEY (Bay_ID) REFERENCES Bay_Master(Bay_ID)
        ON DELETE RESTRICT,
    CONSTRAINT fk_loading_tank
        FOREIGN KEY (Tank_ID) REFERENCES Tank_Master(Tank_ID)
        ON DELETE RESTRICT,
    CONSTRAINT fk_loading_material
        FOREIGN KEY (Material_ID) REFERENCES Material_Master(Material_ID)
        ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- Migration 018: 018_create_loading_procedures.sql
-- ============================================================

-- Migration 018: sp_insert_loading_record
DELIMITER //
CREATE PROCEDURE sp_insert_loading_record(
    IN  p_bin_id                  INT,
    IN  p_loader_user_id          INT,
    IN  p_bay_id                  INT,
    IN  p_tank_id                  INT,
    IN  p_material_id             INT,
    IN  p_quantity_loaded         DECIMAL(10,3),
    IN  p_unit_of_measure         VARCHAR(20),
    IN  p_batch_number            VARCHAR(100),
    IN  p_expected_unloading_date DATE,
    IN  p_loading_start_at        DATETIME,
    IN  p_comments                VARCHAR(500),
    OUT p_success                 TINYINT(1),
    OUT p_error_code              VARCHAR(100),
    OUT p_error_message           VARCHAR(500)
)
BEGIN
    SET p_success=0; SET p_error_code=NULL; SET p_error_message=NULL;
    IF NOT EXISTS(SELECT 1 FROM Bin_Master WHERE Bin_ID=p_bin_id AND Is_Active=1) THEN SET p_error_code='BIN_NOT_FOUND'; SET p_error_message='Bin not found or inactive';
    ELSEIF NOT EXISTS(SELECT 1 FROM User_Master WHERE User_ID=p_loader_user_id AND Is_Active=1) THEN SET p_error_code='NOT_FOUND'; SET p_error_message='Loader user not found or inactive';
    ELSEIF NOT EXISTS(SELECT 1 FROM Bay_Master WHERE Bay_ID=p_bay_id AND Is_Active=1) THEN SET p_error_code='NOT_FOUND'; SET p_error_message='Bay not found or inactive';
    ELSEIF NOT EXISTS(SELECT 1 FROM Tank_Master WHERE Tank_ID=p_tank_id AND Is_Active=1) THEN SET p_error_code='NOT_FOUND'; SET p_error_message='Tank not found or inactive';
    ELSEIF NOT EXISTS(SELECT 1 FROM Material_Master WHERE Material_ID=p_material_id AND Is_Active=1) THEN SET p_error_code='NOT_FOUND'; SET p_error_message='Material not found or inactive';
    ELSEIF p_quantity_loaded<=0 THEN SET p_error_code='VALIDATION_ERROR'; SET p_error_message='Quantity must be greater than zero';
    ELSEIF p_expected_unloading_date<=CURDATE() THEN SET p_error_code='VALIDATION_ERROR'; SET p_error_message='Expected unloading date must be in the future';
    ELSE START TRANSACTION;
        INSERT INTO Loading_Record(Bin_ID,Loader_User_ID,Bay_ID,Tank_ID,Material_ID,Quantity_Loaded,Unit_Of_Measure,Batch_Number,Expected_Unloading_Date,Loading_Start_At,Comments)
        VALUES(p_bin_id,p_loader_user_id,p_bay_id,p_tank_id,p_material_id,p_quantity_loaded,p_unit_of_measure,p_batch_number,p_expected_unloading_date,p_loading_start_at,p_comments);
        SET p_success=1; SELECT LAST_INSERT_ID() AS loading_id; COMMIT;
    END IF;
END //
DELIMITER ;

-- ============================================================
-- Migration 019: 019_create_unloading_record.sql
-- ============================================================

-- =============================================================================
-- PBLMS — Migration 019: Unloading_Record Transaction Table
-- Pharmaceutical Bin Lifecycle Management System
-- =============================================================================
-- Design Spec Reference: Section 4.3
-- Dependencies:
--   Migration 006 (Bin_Master)
--   Migration 001 (User_Master)
--   Migration 017 (Loading_Record)
-- =============================================================================

CREATE TABLE IF NOT EXISTS Unloading_Record (
    Unloading_ID INT AUTO_INCREMENT PRIMARY KEY,
    Bin_ID INT NOT NULL,
    Loading_ID INT NOT NULL,
    Unloader_User_ID INT NOT NULL,
    Quantity_Unloaded DECIMAL(10, 3) NOT NULL,
    Unloading_Condition ENUM('Normal', 'Damaged', 'Contamination_Suspected') NOT NULL DEFAULT 'Normal',
    Unloading_Start_At DATETIME NOT NULL,
    Unloading_Completed_At DATETIME NULL,
    Comments VARCHAR(500) NULL,

    INDEX idx_bin_id (Bin_ID),
    INDEX idx_loading_id (Loading_ID),
    INDEX idx_unloader_user (Unloader_User_ID),

    CONSTRAINT chk_quantity_unloaded_positive CHECK (Quantity_Unloaded > 0),

    CONSTRAINT fk_unloading_bin
        FOREIGN KEY (Bin_ID) REFERENCES Bin_Master(Bin_ID)
        ON DELETE RESTRICT,
    CONSTRAINT fk_unloading_loading
        FOREIGN KEY (Loading_ID) REFERENCES Loading_Record(Loading_ID)
        ON DELETE RESTRICT,
    CONSTRAINT fk_unloading_unloader
        FOREIGN KEY (Unloader_User_ID) REFERENCES User_Master(User_ID)
        ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- Migration 020: 020_create_unloading_procedures.sql
-- ============================================================

-- Migration 020: sp_insert_unloading_record
DELIMITER //
CREATE PROCEDURE sp_insert_unloading_record(
    IN  p_bin_id                INT,
    IN  p_loading_id            INT,
    IN  p_unloader_user_id      INT,
    IN  p_quantity_unloaded     DECIMAL(10,3),
    IN  p_unloading_condition   VARCHAR(30),
    IN  p_unloading_start_at    DATETIME,
    IN  p_comments              VARCHAR(500),
    OUT p_success               TINYINT(1),
    OUT p_error_code            VARCHAR(100),
    OUT p_error_message         VARCHAR(500)
)
BEGIN
    DECLARE v_loading_quantity DECIMAL(10,3);
    SET p_success=0; SET p_error_code=NULL; SET p_error_message=NULL;
    IF NOT EXISTS(SELECT 1 FROM Bin_Master WHERE Bin_ID=p_bin_id AND Is_Active=1) THEN SET p_error_code='BIN_NOT_FOUND'; SET p_error_message='Bin not found or inactive';
    ELSEIF NOT EXISTS(SELECT 1 FROM User_Master WHERE User_ID=p_unloader_user_id AND Is_Active=1) THEN SET p_error_code='NOT_FOUND'; SET p_error_message='Unloader user not found or inactive';
    ELSEIF NOT EXISTS(SELECT 1 FROM Loading_Record WHERE Loading_ID=p_loading_id) THEN SET p_error_code='NOT_FOUND'; SET p_error_message='Loading record not found';
    ELSEIF p_quantity_unloaded<=0 THEN SET p_error_code='VALIDATION_ERROR'; SET p_error_message='Quantity must be greater than zero';
    ELSEIF p_unloading_condition NOT IN('Normal','Damaged','Contamination_Suspected') THEN SET p_error_code='VALIDATION_ERROR'; SET p_error_message='Invalid unloading condition';
    ELSE SELECT Quantity_Loaded INTO v_loading_quantity FROM Loading_Record WHERE Loading_ID=p_loading_id;
        IF p_quantity_unloaded>v_loading_quantity THEN SET p_error_code='VALIDATION_ERROR'; SET p_error_message='Quantity unloaded exceeds quantity loaded';
        ELSE START TRANSACTION;
            INSERT INTO Unloading_Record(Bin_ID,Loading_ID,Unloader_User_ID,Quantity_Unloaded,Unloading_Condition,Unloading_Start_At,Comments)
            VALUES(p_bin_id,p_loading_id,p_unloader_user_id,p_quantity_unloaded,p_unloading_condition,p_unloading_start_at,p_comments);
            SET p_success=1; SELECT LAST_INSERT_ID() AS unloading_id; COMMIT;
        END IF;
    END IF;
END //
DELIMITER ;

-- ============================================================
-- Migration 021: 021_create_cleaning_procedures.sql
-- ============================================================

-- =============================================================================
-- PBLMS — Migration 021: Cleaning_Record Table + sp_start_cleaning + sp_complete_cleaning
-- =============================================================================
CREATE TABLE IF NOT EXISTS Cleaning_Record (
    Cleaning_ID INT AUTO_INCREMENT PRIMARY KEY,
    Bin_ID INT NOT NULL,
    Loading_ID INT NOT NULL,
    Cleaner_User_ID INT NOT NULL,
    Cleaning_Method ENUM('Rinse', 'Chemical_Wash', 'Steam_Clean') NOT NULL,
    Cleaning_Agent VARCHAR(100) NOT NULL,
    Water_Temp_Celsius DECIMAL(5,2) NOT NULL,
    Rinse_Cycles TINYINT NOT NULL DEFAULT 1,
    Is_Reinspection_Cycle TINYINT(1) NOT NULL DEFAULT 0,
    Cleaning_Start_At DATETIME NOT NULL,
    Cleaning_Completed_At DATETIME NULL,
    Comments VARCHAR(500) NULL,
    INDEX idx_bin_id (Bin_ID), INDEX idx_loading_id (Loading_ID),
    CONSTRAINT chk_water_temp CHECK (Water_Temp_Celsius BETWEEN 0 AND 100),
    CONSTRAINT chk_rinse_cycles CHECK (Rinse_Cycles >= 1),
    CONSTRAINT fk_cleaning_bin FOREIGN KEY (Bin_ID) REFERENCES Bin_Master(Bin_ID) ON DELETE RESTRICT,
    CONSTRAINT fk_cleaning_loading FOREIGN KEY (Loading_ID) REFERENCES Loading_Record(Loading_ID) ON DELETE RESTRICT,
    CONSTRAINT fk_cleaning_cleaner FOREIGN KEY (Cleaner_User_ID) REFERENCES User_Master(User_ID) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DELIMITER //

CREATE PROCEDURE sp_start_cleaning(
    IN  p_bin_id INT, IN p_user_id INT, IN p_user_role VARCHAR(50), IN p_row_version INT,
    OUT p_success TINYINT(1), OUT p_error_code VARCHAR(100), OUT p_error_message VARCHAR(500)
)
sp_start: BEGIN
    DECLARE v_from_status VARCHAR(50); DECLARE v_is_reinspection TINYINT DEFAULT 0;
    DECLARE v_lock_id INT; DECLARE v_rows_affected INT;

    SET p_success=0; SET p_error_code=NULL; SET p_error_message=NULL;

    -- Determine current status
    SELECT Current_Status INTO v_from_status FROM Bin_Master WHERE Bin_ID=p_bin_id;

    -- Validate bin is in a valid starting state
    IF v_from_status IS NULL THEN
        SET p_error_code='BIN_NOT_FOUND'; SET p_error_message='Bin not found'; LEAVE sp_start;
    ELSEIF v_from_status NOT IN('Awaiting_Cleaning','Reinspection_Cleaning') THEN
        SET p_error_code='INVALID_TRANSITION';
        SET p_error_message='Bin is not awaiting cleaning';
        LEAVE sp_start;
    END IF;

    IF v_from_status='Reinspection_Cleaning' THEN SET v_is_reinspection=1; END IF;

    -- Validate transition via session variables (OUT params require @)
    CALL sp_validate_workflow_transition(p_bin_id, v_from_status, 'Cleaning_In_Progress', p_user_role, p_row_version,
        @_v_p_success, @_v_p_error_code, @_v_p_error_message);
    SELECT @_v_p_success, @_v_p_error_code, @_v_p_error_message INTO p_success, p_error_code, p_error_message;
    IF p_success=0 THEN LEAVE sp_start; END IF;

    -- Acquire lock
    INSERT INTO Lock_Table (Bin_ID, Locked_By_User_ID, Operation_Type, Expires_At)
    VALUES (p_bin_id, p_user_id, 'START_CLEANING', DATE_ADD(NOW(), INTERVAL 60 MINUTE));

    -- Update bin status with optimistic locking
    UPDATE Bin_Master SET Current_Status='Cleaning_In_Progress', Row_Version=Row_Version+1
    WHERE Bin_ID=p_bin_id AND Row_Version=p_row_version;
    SET v_rows_affected=ROW_COUNT();
    IF v_rows_affected=0 THEN
        SET p_error_code='CONCURRENT_MODIFICATION_CONFLICT'; SET p_error_message='Bin modified by another user';
        ROLLBACK; LEAVE sp_start;
    END IF;

    -- Insert history and audit using session variables for OUT params
    CALL sp_insert_bin_history(p_bin_id, v_from_status, 'Cleaning_In_Progress', p_user_id,
        'START_CLEANING', NULL, NULL, NULL, NULL,
        @_hist_ok, @_hist_ec, @_hist_em);
    CALL sp_insert_audit_log(p_user_id, 'START_CLEANING', 'Bin_Master', p_bin_id,
        CONCAT('"', v_from_status, '"'), CONCAT('"Cleaning_In_Progress"'),
        NULL, NULL, @_aud_ok, @_aud_ec, @_aud_em);

    SET p_success=1;

    -- Return cleaning context from most recent loading record
    SELECT l.Loading_ID AS loading_id, l.Material_ID AS material_id, m.Material_Name,
           l.Batch_Number AS batch_number, l.Quantity_Loaded AS quantity_loaded,
           l.Loading_Start_At AS loading_start_at, l.Loading_Completed_At AS loading_completed_at,
           l.Comments AS loading_comments,
           un.Unloading_Condition AS unloading_condition, un.Comments AS unloading_comments,
           v_is_reinspection AS is_reinspection
    FROM Loading_Record l
    LEFT JOIN Material_Master m ON m.Material_ID=l.Material_ID
    LEFT JOIN Unloading_Record un ON un.Bin_ID=l.Bin_ID AND un.Loading_ID=l.Loading_ID
    WHERE l.Bin_ID=p_bin_id AND l.Is_Current=1
    ORDER BY l.Loading_ID DESC LIMIT 1;

END //

CREATE PROCEDURE sp_complete_cleaning(
    IN  p_bin_id INT, IN p_user_id INT, IN p_user_role VARCHAR(50),
    IN  p_method VARCHAR(20), IN p_agent VARCHAR(100), IN p_water_temp DECIMAL(5,2),
    IN  p_rinse_cycles INT, IN p_comments VARCHAR(500), IN p_row_version INT,
    OUT p_success TINYINT(1), OUT p_error_code VARCHAR(100), OUT p_error_message VARCHAR(500)
)
sp_complete: BEGIN
    DECLARE v_from_status VARCHAR(50); DECLARE v_to_status VARCHAR(50);
    DECLARE v_loading_id INT; DECLARE v_is_reinspection TINYINT DEFAULT 0;
    DECLARE v_cleaning_id INT; DECLARE v_rows_affected INT;

    SET p_success=0; SET p_error_code=NULL; SET p_error_message=NULL;

    -- Determine current status
    SELECT Current_Status INTO v_from_status FROM Bin_Master WHERE Bin_ID=p_bin_id;
    IF v_from_status IS NULL THEN
        SET p_error_code='BIN_NOT_FOUND'; SET p_error_message='Bin not found'; LEAVE sp_complete;
    END IF;

    -- Get active loading record
    SELECT Loading_ID INTO v_loading_id FROM Loading_Record
    WHERE Bin_ID=p_bin_id AND Is_Current=1 ORDER BY Loading_ID DESC LIMIT 1;
    IF v_loading_id IS NULL THEN
        SET p_error_code='NOT_FOUND'; SET p_error_message='No active loading record found'; LEAVE sp_complete;
    END IF;

    -- Determine if this is a reinspection cycle
    SET v_is_reinspection = EXISTS(
        SELECT 1 FROM Bin_History WHERE Bin_ID=p_bin_id AND Previous_Status='Reinspection_Cleaning'
    );

    -- Determine next status
    SET v_to_status = IF(v_is_reinspection, 'Awaiting_Reinspection', 'Awaiting_QA');

    -- Validate inputs
    IF p_method NOT IN('Rinse','Chemical_Wash','Steam_Clean') THEN
        SET p_error_code='VALIDATION_ERROR'; SET p_error_message='Invalid cleaning method'; LEAVE sp_complete;
    END IF;
    IF p_water_temp<0 OR p_water_temp>100 THEN
        SET p_error_code='VALIDATION_ERROR'; SET p_error_message='Water temperature must be 0-100°C'; LEAVE sp_complete;
    END IF;
    IF p_rinse_cycles<1 THEN
        SET p_error_code='VALIDATION_ERROR'; SET p_error_message='At least 1 rinse cycle required'; LEAVE sp_complete;
    END IF;

    START TRANSACTION;

    -- Validate transition
    CALL sp_validate_workflow_transition(p_bin_id, 'Cleaning_In_Progress', v_to_status, p_user_role, p_row_version,
        @_v_p_success, @_v_p_error_code, @_v_p_error_message);
    SELECT @_v_p_success, @_v_p_error_code, @_v_p_error_message INTO p_success, p_error_code, p_error_message;
    IF p_success=0 THEN ROLLBACK; LEAVE sp_complete; END IF;

    -- Insert cleaning record
    INSERT INTO Cleaning_Record (Bin_ID, Loading_ID, Cleaner_User_ID, Cleaning_Method, Cleaning_Agent,
        Water_Temp_Celsius, Rinse_Cycles, Is_Reinspection_Cycle, Cleaning_Start_At, Comments)
    VALUES (p_bin_id, v_loading_id, p_user_id, p_method, p_agent, p_water_temp, p_rinse_cycles,
        v_is_reinspection, NOW(), p_comments);
    SET v_cleaning_id=LAST_INSERT_ID();

    -- Update bin status
    UPDATE Bin_Master SET Current_Status=v_to_status, Row_Version=Row_Version+1
    WHERE Bin_ID=p_bin_id AND Row_Version=p_row_version;
    SET v_rows_affected=ROW_COUNT();
    IF v_rows_affected=0 THEN
        ROLLBACK; SET p_error_code='CONCURRENT_MODIFICATION_CONFLICT';
        SET p_error_message='Bin modified by another user'; LEAVE sp_complete;
    END IF;

    -- Release lock (idempotent)
    CALL sp_release_lock(p_bin_id, p_user_id, @_lock_ok, @_lock_ec, @_lock_em);

    -- History
    CALL sp_insert_bin_history(p_bin_id, 'Cleaning_In_Progress', v_to_status, p_user_id,
        'COMPLETE_CLEANING', v_cleaning_id, 'Cleaning_Record', p_comments, NULL,
        @_hist_ok, @_hist_ec, @_hist_em);

    -- Audit
    CALL sp_insert_audit_log(p_user_id, 'COMPLETE_CLEANING', 'Bin_Master', p_bin_id,
        CONCAT('"Cleaning_In_Progress"'), CONCAT('"', v_to_status, '"'), NULL, NULL,
        @_aud_ok, @_aud_ec, @_aud_em);

    SET p_success=1;
    SELECT v_cleaning_id AS cleaning_id, v_to_status AS next_status;
    COMMIT;
END //

DELIMITER ;

-- ============================================================
-- Migration 022: 022_create_qa_procedures.sql
-- ============================================================

-- =============================================================================
-- PBLMS — Migration 022: QA_Record Table + sp_start_qa + sp_complete_qa
-- =============================================================================
CREATE TABLE IF NOT EXISTS QA_Record (
    QA_ID INT AUTO_INCREMENT PRIMARY KEY,
    Bin_ID INT NOT NULL,
    Cleaning_ID INT NOT NULL,
    QA_Inspector_User_ID INT NOT NULL,
    Visual_Inspection ENUM('Pass','Fail') NOT NULL,
    Visual_Notes VARCHAR(500) NULL,
    Residue_Check ENUM('Pass','Fail') NOT NULL,
    Residue_Notes VARCHAR(500) NULL,
    Damage_Assessment ENUM('Pass','Fail') NOT NULL,
    Damage_Notes VARCHAR(500) NULL,
    Odor_Check ENUM('Pass','Fail') NOT NULL,
    Odor_Notes VARCHAR(500) NULL,
    Label_Integrity ENUM('Pass','Fail') NOT NULL,
    Label_Notes VARCHAR(500) NULL,
    Seal_Integrity ENUM('Pass','Fail') NOT NULL,
    Seal_Notes VARCHAR(500) NULL,
    Overall_Result ENUM('PASS','FAIL') NOT NULL,
    Failure_Reason VARCHAR(1000) NULL,
    Is_Reinspection TINYINT(1) NOT NULL DEFAULT 0,
    QA_Start_At DATETIME NOT NULL,
    QA_Completed_At DATETIME NULL,
    INDEX idx_bin_id (Bin_ID), INDEX idx_cleaning_id (Cleaning_ID),
    CONSTRAINT chk_failure_reason CHECK (Overall_Result='PASS' OR Failure_Reason IS NOT NULL),
    CONSTRAINT fk_qa_bin FOREIGN KEY (Bin_ID) REFERENCES Bin_Master(Bin_ID) ON DELETE RESTRICT,
    CONSTRAINT fk_qa_cleaning FOREIGN KEY (Cleaning_ID) REFERENCES Cleaning_Record(Cleaning_ID) ON DELETE RESTRICT,
    CONSTRAINT fk_qa_inspector FOREIGN KEY (QA_Inspector_User_ID) REFERENCES User_Master(User_ID) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DELIMITER //

CREATE PROCEDURE sp_start_qa(
    IN  p_bin_id INT, IN p_user_id INT, IN p_user_role VARCHAR(50), IN p_row_version INT,
    OUT p_success TINYINT(1), OUT p_error_code VARCHAR(100), OUT p_error_message VARCHAR(500)
)
sp_start: BEGIN
    DECLARE v_from_status VARCHAR(50); DECLARE v_is_reinspection TINYINT DEFAULT 0;
    DECLARE v_rows_affected INT; DECLARE v_requires_qa TINYINT;

    SET p_success=0; SET p_error_code=NULL; SET p_error_message=NULL;

    SELECT Current_Status, Requires_QA_Attention INTO v_from_status, v_requires_qa FROM Bin_Master WHERE Bin_ID=p_bin_id;
    IF v_from_status IS NULL THEN SET p_error_code='BIN_NOT_FOUND'; SET p_error_message='Bin not found'; LEAVE sp_start;
    ELSEIF v_from_status NOT IN('Awaiting_QA','Awaiting_Reinspection') THEN
        SET p_error_code='INVALID_TRANSITION'; SET p_error_message='Bin is not awaiting QA'; LEAVE sp_start;
    END IF;
    IF v_from_status='Awaiting_Reinspection' THEN SET v_is_reinspection=1; END IF;

    CALL sp_validate_workflow_transition(p_bin_id,v_from_status,'QA_In_Progress',p_user_role,p_row_version,
        @_v_p_success,@_v_p_error_code,@_v_p_error_message);
    SELECT @_v_p_success,@_v_p_error_code,@_v_p_error_message INTO p_success,p_error_code,p_error_message;
    IF p_success=0 THEN LEAVE sp_start; END IF;

    INSERT INTO Lock_Table(Bin_ID,Locked_By_User_ID,Operation_Type,Expires_At)
    VALUES(p_bin_id,p_user_id,'START_QA',DATE_ADD(NOW(),INTERVAL 60 MINUTE));

    UPDATE Bin_Master SET Current_Status='QA_In_Progress',Row_Version=Row_Version+1
    WHERE Bin_ID=p_bin_id AND Row_Version=p_row_version;
    SET v_rows_affected=ROW_COUNT();
    IF v_rows_affected=0 THEN
        SET p_error_code='CONCURRENT_MODIFICATION_CONFLICT'; SET p_error_message='Bin modified by another user';
        ROLLBACK; LEAVE sp_start;
    END IF;

    CALL sp_insert_bin_history(p_bin_id,v_from_status,'QA_In_Progress',p_user_id,'START_QA',NULL,NULL,NULL,NULL,
        @_hist_ok,@_hist_ec,@_hist_em);
    CALL sp_insert_audit_log(p_user_id,'START_QA','Bin_Master',p_bin_id,
        CONCAT('"',v_from_status,'"'),CONCAT('"QA_In_Progress"'),NULL,NULL,@_aud_ok,@_aud_ec,@_aud_em);

    SET p_success=1;
    SELECT cr.Cleaning_ID, cr.Cleaning_Method, cr.Cleaning_Agent, cr.Water_Temp_Celsius, cr.Rinse_Cycles,
           cr.Cleaning_Start_At, cr.Comments AS cleaning_comments,
           l.Material_ID, m.Material_Name, l.Batch_Number, l.Quantity_Loaded,
           v_requires_qa AS requires_qa_attention, v_is_reinspection AS is_reinspection
    FROM Cleaning_Record cr
    LEFT JOIN Loading_Record l ON l.Loading_ID=cr.Loading_ID
    LEFT JOIN Material_Master m ON m.Material_ID=l.Material_ID
    WHERE cr.Bin_ID=p_bin_id ORDER BY cr.Cleaning_ID DESC LIMIT 1;
END //

CREATE PROCEDURE sp_complete_qa(
    IN  p_bin_id INT, IN p_user_id INT, IN p_user_role VARCHAR(50),
    IN  p_visual ENUM('Pass','Fail'), IN p_visual_notes VARCHAR(500),
    IN  p_residue ENUM('Pass','Fail'), IN p_residue_notes VARCHAR(500),
    IN  p_damage ENUM('Pass','Fail'), IN p_damage_notes VARCHAR(500),
    IN  p_odor ENUM('Pass','Fail'), IN p_odor_notes VARCHAR(500),
    IN  p_label ENUM('Pass','Fail'), IN p_label_notes VARCHAR(500),
    IN  p_seal ENUM('Pass','Fail'), IN p_seal_notes VARCHAR(500),
    IN  p_overall_result ENUM('PASS','FAIL'), IN p_failure_reason VARCHAR(1000),
    IN  p_row_version INT,
    OUT p_success TINYINT(1), OUT p_error_code VARCHAR(100), OUT p_error_message VARCHAR(500)
)
sp_complete: BEGIN
    DECLARE v_is_reinspection TINYINT DEFAULT 0;
    DECLARE v_fail_count INT DEFAULT 0; DECLARE v_cleaning_id INT; DECLARE v_qa_id INT;
    DECLARE v_rows_affected INT; DECLARE v_final_status VARCHAR(50);

    SET p_success=0; SET p_error_code=NULL; SET p_error_message=NULL;

    -- Validate FAIL requires failure reason
    IF p_overall_result='FAIL' AND (p_failure_reason IS NULL OR CHAR_LENGTH(p_failure_reason)<20) THEN
        SET p_error_code='VALIDATION_ERROR'; SET p_error_message='Failure reason is required (minimum 20 characters)'; LEAVE sp_complete;
    END IF;

    SELECT Cleaning_ID INTO v_cleaning_id FROM Cleaning_Record WHERE Bin_ID=p_bin_id ORDER BY Cleaning_ID DESC LIMIT 1;
    IF v_cleaning_id IS NULL THEN SET p_error_code='NOT_FOUND'; SET p_error_message='No cleaning record found'; LEAVE sp_complete; END IF;

    SELECT EXISTS(SELECT 1 FROM Bin_History WHERE Bin_ID=p_bin_id AND Previous_Status='Reinspection_Cleaning') INTO v_is_reinspection;

    -- Determine final status
    IF p_overall_result='PASS' THEN
        SET v_final_status='Awaiting_Loading';
        -- Auto-transition: QA_In_Progress → QA_Passed → Awaiting_Loading
        -- Validate first transition
        CALL sp_validate_workflow_transition(p_bin_id,'QA_In_Progress','QA_Passed',p_user_role,p_row_version,
            @_v1,@_ec1,@_em1);
        SELECT @_v1 INTO p_success; SELECT @_ec1 INTO p_error_code; SELECT @_em1 INTO p_error_message;
        IF p_success=0 THEN LEAVE sp_complete; END IF;
    ELSE
        SET v_final_status='Reinspection_Cleaning';
        -- Auto-transition: QA_In_Progress → QA_Failed → Reinspection_Cleaning
        CALL sp_validate_workflow_transition(p_bin_id,'QA_In_Progress','QA_Failed',p_user_role,p_row_version,
            @_v1,@_ec1,@_em1);
        SELECT @_v1 INTO p_success; SELECT @_ec1 INTO p_error_code; SELECT @_em1 INTO p_error_message;
        IF p_success=0 THEN LEAVE sp_complete; END IF;
    END IF;

    START TRANSACTION;

    -- Increment fail count for FAIL, reset for PASS
    IF p_overall_result='FAIL' THEN
        SELECT Consecutive_Fail_Count+1 INTO v_fail_count FROM Bin_Master WHERE Bin_ID=p_bin_id;
        IF v_fail_count>=3 THEN
            ROLLBACK; SET p_error_code='ADMIN_REVIEW_REQUIRED'; SET p_error_message='Bin requires Administrator review after 3+ consecutive QA failures'; LEAVE sp_complete;
        END IF;
    ELSE
        SET v_fail_count=0;
    END IF;

    -- Insert QA record
    INSERT INTO QA_Record(Bin_ID,Cleaning_ID,QA_Inspector_User_ID,
        Visual_Inspection,Visual_Notes,Residue_Check,Residue_Notes,
        Damage_Assessment,Damage_Notes,Odor_Check,Odor_Notes,
        Label_Integrity,Label_Notes,Seal_Integrity,Seal_Notes,
        Overall_Result,Failure_Reason,Is_Reinspection,QA_Start_At)
    VALUES(p_bin_id,v_cleaning_id,p_user_id,
        p_visual,p_visual_notes,p_residue,p_residue_notes,
        p_damage,p_damage_notes,p_odor,p_odor_notes,
        p_label,p_label_notes,p_seal,p_seal_notes,
        p_overall_result,p_failure_reason,v_is_reinspection,NOW());
    SET v_qa_id=LAST_INSERT_ID();

    -- Update bin status
    UPDATE Bin_Master SET Current_Status=v_final_status, Row_Version=Row_Version+1,
        Consecutive_Fail_Count=v_fail_count,
        Last_QA_Date=IF(p_overall_result='PASS',NOW(),Last_QA_Date),
        Requires_QA_Attention=0
    WHERE Bin_ID=p_bin_id AND Row_Version=p_row_version;
    SET v_rows_affected=ROW_COUNT();
    IF v_rows_affected=0 THEN ROLLBACK; SET p_error_code='CONCURRENT_MODIFICATION_CONFLICT'; LEAVE sp_complete; END IF;

    -- Release lock, history, audit
    CALL sp_release_lock(p_bin_id,p_user_id,@_lock_ok,@_lock_ec,@_lock_em);
    CALL sp_insert_bin_history(p_bin_id,'QA_In_Progress',v_final_status,p_user_id,'COMPLETE_QA',v_qa_id,'QA_Record',
        IF(p_overall_result='PASS','QA Passed','QA Failed'),NULL,@_hist_ok,@_hist_ec,@_hist_em);
    CALL sp_insert_audit_log(p_user_id,'COMPLETE_QA','Bin_Master',p_bin_id,
        CONCAT('"QA_In_Progress"'),CONCAT('"',v_final_status,'"'),NULL,NULL,@_aud_ok,@_aud_ec,@_aud_em);

    SET p_success=1;
    SELECT v_qa_id AS qa_id, v_final_status AS final_status;
    COMMIT;
END //

DELIMITER ;

-- ============================================================
-- Migration 023: 023_create_dashboard_views.sql
-- ============================================================

-- PBLMS Migration 023: Cycle_Record + Dashboard Views
CREATE TABLE IF NOT EXISTS Cycle_Record (
    Cycle_ID INT AUTO_INCREMENT PRIMARY KEY,
    Bin_ID INT NOT NULL,
    QA_ID INT NOT NULL,
    Cycle_Start_At DATETIME NOT NULL,
    Cycle_End_At DATETIME NOT NULL,
    Total_Cycle_Duration_Minutes INT NOT NULL,
    Loading_Duration_Minutes INT NOT NULL,
    Unloading_Duration_Minutes INT NOT NULL,
    Cleaning_Duration_Minutes INT NOT NULL,
    QA_Duration_Minutes INT NOT NULL,
    Reinspection_Count TINYINT NOT NULL DEFAULT 0,
    INDEX idx_bin_id (Bin_ID), INDEX idx_cycle_end (Cycle_End_At),
    CONSTRAINT fk_cycle_bin FOREIGN KEY (Bin_ID) REFERENCES Bin_Master(Bin_ID) ON DELETE RESTRICT,
    CONSTRAINT fk_cycle_qa FOREIGN KEY (QA_ID) REFERENCES QA_Record(QA_ID) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Active locks view
CREATE OR REPLACE VIEW vw_active_locks AS
SELECT l.Lock_ID, l.Bin_ID, b.Bin_Number, l.Locked_By_User_ID, u.Full_Name AS locked_by_name,
       l.Operation_Type, l.Lock_Timestamp, l.Expires_At
FROM Lock_Table l
JOIN Bin_Master b ON b.Bin_ID = l.Bin_ID
JOIN User_Master u ON u.User_ID = l.Locked_By_User_ID;

-- Admin dashboard
CREATE OR REPLACE VIEW vw_dashboard_admin AS
SELECT
  (SELECT COUNT(*) FROM Bin_Master WHERE Is_Active=1) AS total_active_bins,
  (SELECT COUNT(*) FROM Bin_Master WHERE Current_Status='Awaiting_Loading' AND Is_Active=1) AS awaiting_loading,
  (SELECT COUNT(*) FROM Bin_Master WHERE Current_Status='Loading_In_Progress' AND Is_Active=1) AS loading_in_progress,
  (SELECT COUNT(*) FROM Bin_Master WHERE Current_Status='Awaiting_Unloading' AND Is_Active=1) AS awaiting_unloading,
  (SELECT COUNT(*) FROM Bin_Master WHERE Current_Status='Unloading_In_Progress' AND Is_Active=1) AS unloading_in_progress,
  (SELECT COUNT(*) FROM Bin_Master WHERE Current_Status='Awaiting_Cleaning' AND Is_Active=1) AS awaiting_cleaning,
  (SELECT COUNT(*) FROM Bin_Master WHERE Current_Status='Cleaning_In_Progress' AND Is_Active=1) AS cleaning_in_progress,
  (SELECT COUNT(*) FROM Bin_Master WHERE Current_Status='Awaiting_QA' AND Is_Active=1) AS awaiting_qa,
  (SELECT COUNT(*) FROM Bin_Master WHERE Current_Status='QA_In_Progress' AND Is_Active=1) AS qa_in_progress,
  (SELECT COUNT(*) FROM Bin_Master WHERE Current_Status='QA_Failed' AND Is_Active=1) AS qa_failed,
  (SELECT COUNT(*) FROM Bin_Master WHERE Current_Status='Reinspection_Cleaning' AND Is_Active=1) AS reinspection_cleaning,
  (SELECT COUNT(*) FROM Bin_Master WHERE Current_Status='Awaiting_Reinspection' AND Is_Active=1) AS awaiting_reinspection,
  (SELECT COUNT(*) FROM Bin_Master WHERE Current_Status='Retired' AND Is_Active=1) AS retired,
  (SELECT COUNT(*) FROM Bin_Master WHERE Requires_Admin_Review=1) AS admin_review_bins,
  (SELECT COUNT(*) FROM Bin_Master WHERE Overdue_Unloading=1) AS overdue_unloading,
  (SELECT COUNT(*) FROM Loading_Record WHERE DATE(Loading_Start_At)=CURDATE()) AS today_loading,
  (SELECT COUNT(*) FROM Unloading_Record WHERE DATE(Unloading_Start_At)=CURDATE()) AS today_unloading,
  (SELECT COUNT(*) FROM Cleaning_Record WHERE DATE(Cleaning_Start_At)=CURDATE()) AS today_cleaning,
  (SELECT COUNT(*) FROM QA_Record WHERE DATE(QA_Start_At)=CURDATE()) AS today_qa,
  COALESCE((SELECT ROUND(SUM(Overall_Result='PASS')*100.0/COUNT(*),1) FROM QA_Record WHERE DATE(QA_Start_At)=CURDATE()),0) AS qa_pass_rate_today,
  COALESCE((SELECT ROUND(SUM(Overall_Result='PASS')*100.0/COUNT(*),1) FROM QA_Record WHERE QA_Start_At>=DATE_SUB(CURDATE(),INTERVAL 7 DAY)),0) AS qa_pass_rate_7day,
  COALESCE((SELECT ROUND(AVG(Total_Cycle_Duration_Minutes)) FROM Cycle_Record WHERE Cycle_End_At>=DATE_SUB(CURDATE(),INTERVAL 30 DAY)),0) AS avg_cycle_time_30day;

-- Loader dashboard
CREATE OR REPLACE VIEW vw_dashboard_loader AS
SELECT
  (SELECT COUNT(*) FROM Bin_Master WHERE Current_Status='Awaiting_Loading' AND Is_Active=1) AS awaiting_loading,
  (SELECT COUNT(*) FROM Loading_Record WHERE DATE(Loading_Start_At)=CURDATE()) AS today_loadings;

-- Unloader dashboard
CREATE OR REPLACE VIEW vw_dashboard_unloader AS
SELECT
  (SELECT COUNT(*) FROM Bin_Master WHERE Current_Status='Awaiting_Unloading' AND Is_Active=1) AS awaiting_unloading,
  (SELECT COUNT(*) FROM Loading_Record l JOIN Bin_Master b ON b.Bin_ID=l.Bin_ID WHERE b.Overdue_Unloading=1 AND l.Is_Current=1) AS overdue_unloading;

-- Cleaner dashboard
CREATE OR REPLACE VIEW vw_dashboard_cleaner AS
SELECT
  (SELECT COUNT(*) FROM Bin_Master WHERE Current_Status='Awaiting_Cleaning' AND Is_Active=1) AS awaiting_cleaning,
  (SELECT COUNT(*) FROM Bin_Master WHERE Current_Status='Reinspection_Cleaning' AND Is_Active=1) AS reinspection_cleaning;

-- QA dashboard
CREATE OR REPLACE VIEW vw_dashboard_qa AS
SELECT
  (SELECT COUNT(*) FROM Bin_Master WHERE Current_Status='Awaiting_QA' AND Is_Active=1) AS awaiting_qa,
  (SELECT COUNT(*) FROM Bin_Master WHERE Current_Status='Awaiting_Reinspection' AND Is_Active=1) AS awaiting_reinspection,
  (SELECT COUNT(*) FROM QA_Record WHERE DATE(QA_Start_At)=CURDATE() AND Overall_Result='FAIL') AS today_failures,
  COALESCE((SELECT ROUND(SUM(Overall_Result='PASS')*100.0/COUNT(*),1) FROM QA_Record WHERE QA_Start_At>=DATE_SUB(CURDATE(),INTERVAL 7 DAY)),0) AS pass_rate_week;

-- Average cycle time
CREATE OR REPLACE VIEW vw_avg_cycle_time AS
SELECT COALESCE(ROUND(AVG(Total_Cycle_Duration_Minutes)),0) AS avg_minutes
FROM Cycle_Record WHERE Cycle_End_At>=DATE_SUB(CURDATE(),INTERVAL 30 DAY);

-- ============================================================
-- Migration 024: 024_create_dashboard_procedure.sql
-- ============================================================

-- PBLMS — Migration 024: sp_generate_dashboard_metrics
DELIMITER //

CREATE PROCEDURE sp_generate_dashboard_metrics(
    IN  p_user_role     VARCHAR(50),
    OUT p_success       TINYINT(1),
    OUT p_error_code    VARCHAR(100),
    OUT p_error_message VARCHAR(500)
)
BEGIN
    SET p_success=0; SET p_error_code=NULL; SET p_error_message=NULL;

    IF p_user_role='Administrator' THEN
        SELECT * FROM vw_dashboard_admin;
    ELSEIF p_user_role='Loader' THEN
        SELECT * FROM vw_dashboard_loader;
    ELSEIF p_user_role='Unloader' THEN
        SELECT * FROM vw_dashboard_unloader;
    ELSEIF p_user_role='Cleaner' THEN
        SELECT * FROM vw_dashboard_cleaner;
    ELSEIF p_user_role='QA_Inspector' THEN
        SELECT * FROM vw_dashboard_qa;
    ELSE
        SELECT * FROM vw_dashboard_loader;
    END IF;

    SET p_success=1;
END //

DELIMITER ;

-- ============================================================
-- Migration 025: 025_create_report_objects.sql
-- ============================================================

-- =============================================================================
-- PBLMS — Migration 025: Report Database Objects
-- Pharmaceutical Bin Lifecycle Management System
-- =============================================================================
-- Design Spec Reference: Section 4.5
-- Creates all report-related views required by the Reports module.
-- =============================================================================

-- ---------------------------------------------------------------------------
-- 1. vw_bin_lifecycle_summary — Per-bin current state with latest operation
-- ---------------------------------------------------------------------------
CREATE OR REPLACE VIEW vw_bin_lifecycle_summary AS
SELECT
  b.Bin_ID, b.Bin_Number, b.QR_Code_Value, b.Current_Status, b.Is_Active,
  b.Current_Bay_ID, b.Current_Tank_ID, b.Requires_Admin_Review,
  b.Requires_QA_Attention, b.Overdue_Unloading, b.Consecutive_Fail_Count,
  b.Last_QA_Date, b.Row_Version, b.Created_At,
  bt.Type_Name AS Bin_Type_Name,
  bc.Category_Name AS Bin_Category_Name,
  bay.Bay_Code, bay.Bay_Name,
  tank.Tank_Code, tank.Tank_Name,
  l.Loading_ID, l.Loader_User_ID, lu.Full_Name AS Loader_Name,
  l.Material_ID, m.Material_Name, l.Batch_Number, l.Quantity_Loaded,
  l.Unit_Of_Measure, l.Expected_Unloading_Date,
  l.Loading_Start_At, l.Loading_Completed_At,
  un.Unloading_ID, un.Unloader_User_ID, uu.Full_Name AS Unloader_Name,
  un.Unloading_Condition, un.Quantity_Unloaded,
  cr.Cleaning_ID, cr.Cleaner_User_ID, cu.Full_Name AS Cleaner_Name,
  cr.Cleaning_Method, cr.Cleaning_Agent,
  qa.QA_ID, qa.QA_Inspector_User_ID, qu.Full_Name AS QA_Inspector_Name,
  qa.Overall_Result, qa.Failure_Reason, qa.QA_Completed_At
FROM Bin_Master b
LEFT JOIN Bin_Type_Master bt ON bt.Bin_Type_ID = b.Bin_Type_ID
LEFT JOIN Bin_Category_Master bc ON bc.Bin_Category_ID = b.Bin_Category_ID
LEFT JOIN Bay_Master bay ON bay.Bay_ID = b.Current_Bay_ID
LEFT JOIN Tank_Master tank ON tank.Tank_ID = b.Current_Tank_ID
LEFT JOIN Loading_Record l ON l.Bin_ID = b.Bin_ID AND l.Is_Current = 1
LEFT JOIN User_Master lu ON lu.User_ID = l.Loader_User_ID
LEFT JOIN Material_Master m ON m.Material_ID = l.Material_ID
LEFT JOIN Unloading_Record un ON un.Bin_ID = b.Bin_ID AND un.Loading_ID = l.Loading_ID
LEFT JOIN User_Master uu ON uu.User_ID = un.Unloader_User_ID
LEFT JOIN Cleaning_Record cr ON cr.Bin_ID = b.Bin_ID AND cr.Loading_ID = l.Loading_ID
LEFT JOIN User_Master cu ON cu.User_ID = cr.Cleaner_User_ID
LEFT JOIN QA_Record qa ON qa.Bin_ID = b.Bin_ID AND qa.Cleaning_ID = cr.Cleaning_ID
LEFT JOIN User_Master qu ON qu.User_ID = qa.QA_Inspector_User_ID;

-- ---------------------------------------------------------------------------
-- 2. vw_rpt_loading — Loading report base query
-- ---------------------------------------------------------------------------
CREATE OR REPLACE VIEW vw_rpt_loading AS
SELECT
  l.Loading_ID, l.Bin_ID, b.Bin_Number,
  l.Loader_User_ID, u.Full_Name AS Loader_Name,
  l.Bay_ID, bay.Bay_Code, bay.Bay_Name,
  l.Tank_ID, tank.Tank_Code, tank.Tank_Name,
  l.Material_ID, m.Material_Code, m.Material_Name, m.Hazard_Level,
  l.Quantity_Loaded, l.Unit_Of_Measure, l.Batch_Number,
  l.Expected_Unloading_Date, l.Loading_Start_At, l.Loading_Completed_At,
  l.Comments, l.Is_Current
FROM Loading_Record l
JOIN Bin_Master b ON b.Bin_ID = l.Bin_ID
JOIN User_Master u ON u.User_ID = l.Loader_User_ID
JOIN Bay_Master bay ON bay.Bay_ID = l.Bay_ID
JOIN Tank_Master tank ON tank.Tank_ID = l.Tank_ID
JOIN Material_Master m ON m.Material_ID = l.Material_ID;

-- ---------------------------------------------------------------------------
-- 3. vw_rpt_unloading — Unloading report base query
-- ---------------------------------------------------------------------------
CREATE OR REPLACE VIEW vw_rpt_unloading AS
SELECT
  un.Unloading_ID, un.Bin_ID, b.Bin_Number,
  un.Loading_ID, l.Material_ID, m.Material_Name, l.Batch_Number,
  l.Quantity_Loaded, un.Quantity_Unloaded,
  un.Unloader_User_ID, uu.Full_Name AS Unloader_Name,
  lu.Full_Name AS Loader_Name,
  un.Unloading_Condition,
  un.Unloading_Start_At, un.Unloading_Completed_At,
  un.Comments
FROM Unloading_Record un
JOIN Bin_Master b ON b.Bin_ID = un.Bin_ID
JOIN Loading_Record l ON l.Loading_ID = un.Loading_ID
JOIN User_Master uu ON uu.User_ID = un.Unloader_User_ID
JOIN User_Master lu ON lu.User_ID = l.Loader_User_ID
JOIN Material_Master m ON m.Material_ID = l.Material_ID;

-- ---------------------------------------------------------------------------
-- 4. vw_rpt_cleaning — Cleaning report base query
-- ---------------------------------------------------------------------------
CREATE OR REPLACE VIEW vw_rpt_cleaning AS
SELECT
  cr.Cleaning_ID, cr.Bin_ID, b.Bin_Number,
  cr.Cleaner_User_ID, u.Full_Name AS Cleaner_Name,
  cr.Cleaning_Method, cr.Cleaning_Agent,
  cr.Water_Temp_Celsius, cr.Rinse_Cycles,
  cr.Is_Reinspection_Cycle,
  cr.Cleaning_Start_At, cr.Cleaning_Completed_At,
  cr.Comments
FROM Cleaning_Record cr
JOIN Bin_Master b ON b.Bin_ID = cr.Bin_ID
JOIN User_Master u ON u.User_ID = cr.Cleaner_User_ID;

-- ---------------------------------------------------------------------------
-- 5. vw_rpt_qa — QA report base query with all 6 checklist items
-- ---------------------------------------------------------------------------
CREATE OR REPLACE VIEW vw_rpt_qa AS
SELECT
  qa.QA_ID, qa.Bin_ID, b.Bin_Number,
  qa.QA_Inspector_User_ID, u.Full_Name AS QA_Inspector_Name,
  qa.Cleaning_ID, cr.Cleaning_Method, cr.Cleaning_Agent,
  qa.Visual_Inspection, qa.Visual_Notes,
  qa.Residue_Check, qa.Residue_Notes,
  qa.Damage_Assessment, qa.Damage_Notes,
  qa.Odor_Check, qa.Odor_Notes,
  qa.Label_Integrity, qa.Label_Notes,
  qa.Seal_Integrity, qa.Seal_Notes,
  qa.Overall_Result, qa.Failure_Reason, qa.Is_Reinspection,
  qa.QA_Start_At, qa.QA_Completed_At
FROM QA_Record qa
JOIN Bin_Master b ON b.Bin_ID = qa.Bin_ID
JOIN User_Master u ON u.User_ID = qa.QA_Inspector_User_ID
JOIN Cleaning_Record cr ON cr.Cleaning_ID = qa.Cleaning_ID;

-- ---------------------------------------------------------------------------
-- 6. vw_rpt_rejected_bin — Rejected bins with consecutive fail count
-- ---------------------------------------------------------------------------
CREATE OR REPLACE VIEW vw_rpt_rejected_bin AS
SELECT
  b.Bin_ID, b.Bin_Number, b.Current_Status, b.Consecutive_Fail_Count,
  qa.QA_ID AS Last_QA_ID, qa.Overall_Result, qa.Failure_Reason,
  qa.QA_Completed_At AS Rejection_Date,
  u.Full_Name AS QA_Inspector_Name,
  DATEDIFF(CURDATE(), COALESCE(qa.QA_Completed_At, b.Last_QA_Date)) AS Days_Since_Rejection
FROM Bin_Master b
JOIN QA_Record qa ON qa.Bin_ID = b.Bin_ID
JOIN User_Master u ON u.User_ID = qa.QA_Inspector_User_ID
WHERE b.Current_Status = 'QA_Failed' AND qa.Overall_Result = 'FAIL'
ORDER BY qa.QA_Completed_At DESC;

-- ---------------------------------------------------------------------------
-- 7. vw_rpt_lifecycle — Full bin lifecycle timeline per cycle from Cycle_Record
-- ---------------------------------------------------------------------------
CREATE OR REPLACE VIEW vw_rpt_lifecycle AS
SELECT
  c.Cycle_ID, c.Bin_ID, b.Bin_Number,
  c.Cycle_Start_At, c.Cycle_End_At,
  c.Total_Cycle_Duration_Minutes,
  c.Loading_Duration_Minutes, c.Unloading_Duration_Minutes,
  c.Cleaning_Duration_Minutes, c.QA_Duration_Minutes,
  c.Reinspection_Count,
  qa.QA_ID, qa.Overall_Result,
  u.Full_Name AS QA_Inspector_Name
FROM Cycle_Record c
JOIN Bin_Master b ON b.Bin_ID = c.Bin_ID
JOIN QA_Record qa ON qa.QA_ID = c.QA_ID
JOIN User_Master u ON u.User_ID = qa.QA_Inspector_User_ID;

-- ---------------------------------------------------------------------------
-- 8. vw_rpt_user_activity — User operation counts from all transaction tables
-- ---------------------------------------------------------------------------
CREATE OR REPLACE VIEW vw_rpt_user_activity AS
SELECT
  u.User_ID, u.Username, u.Full_Name, u.Role,
  COALESCE(l.load_count,0) AS loading_count,
  COALESCE(un.unload_count,0) AS unloading_count,
  COALESCE(cl.clean_count,0) AS cleaning_count,
  COALESCE(qa.qa_count,0) AS qa_count,
  COALESCE(l.last_loading, un.last_unloading, cl.last_cleaning, qa.last_qa) AS last_activity
FROM User_Master u
LEFT JOIN (
  SELECT Loader_User_ID, COUNT(*) AS load_count, MAX(Loading_Start_At) AS last_loading
  FROM Loading_Record GROUP BY Loader_User_ID
) l ON l.Loader_User_ID = u.User_ID
LEFT JOIN (
  SELECT Unloader_User_ID, COUNT(*) AS unload_count, MAX(Unloading_Start_At) AS last_unloading
  FROM Unloading_Record GROUP BY Unloader_User_ID
) un ON un.Unloader_User_ID = u.User_ID
LEFT JOIN (
  SELECT Cleaner_User_ID, COUNT(*) AS clean_count, MAX(Cleaning_Start_At) AS last_cleaning
  FROM Cleaning_Record GROUP BY Cleaner_User_ID
) cl ON cl.Cleaner_User_ID = u.User_ID
LEFT JOIN (
  SELECT QA_Inspector_User_ID, COUNT(*) AS qa_count, MAX(QA_Start_At) AS last_qa
  FROM QA_Record GROUP BY QA_Inspector_User_ID
) qa ON qa.QA_Inspector_User_ID = u.User_ID;

-- ---------------------------------------------------------------------------
-- 9. vw_rpt_audit_trail — Filterable audit log with user names
-- ---------------------------------------------------------------------------
CREATE OR REPLACE VIEW vw_rpt_audit_trail AS
SELECT
  a.Audit_ID, a.Actor_User_ID, u.Full_Name AS Actor_Name,
  a.Action_Type, a.Target_Entity, a.Target_ID,
  a.Old_Value, a.New_Value, a.IP_Address, a.User_Agent,
  a.Event_Timestamp
FROM Audit_Log a
LEFT JOIN User_Master u ON u.User_ID = a.Actor_User_ID;

-- ============================================================
-- Migration 026: 026_create_report_procedure.sql
-- ============================================================

-- PBLMS — Migration 026: sp_generate_report
DELIMITER //

CREATE PROCEDURE sp_generate_report(
    IN  p_report_type   VARCHAR(50),
    IN  p_from_date     DATE,
    IN  p_to_date       DATE,
    IN  p_bin_number    VARCHAR(30),
    IN  p_operator_id   INT,
    IN  p_bay_id        INT,
    IN  p_material_id   INT,
    IN  p_page          INT,
    IN  p_page_size     INT,
    OUT p_success       TINYINT(1),
    OUT p_error_code    VARCHAR(100),
    OUT p_error_message VARCHAR(500)
)
BEGIN
    DECLARE v_offset INT DEFAULT 0;
    SET p_success=0; SET p_error_code=NULL; SET p_error_message=NULL;

    -- Validate page size
    IF p_page_size NOT IN(25,50,100) THEN SET p_page_size=25; END IF;
    IF p_page IS NULL OR p_page<1 THEN SET p_page=1; END IF;
    SET v_offset = (p_page-1) * p_page_size;

    -- Default date range: current month if both NULL
    IF p_from_date IS NULL AND p_to_date IS NULL THEN
        SET p_from_date = DATE_FORMAT(CURDATE(), '%Y-%m-01');
        SET p_to_date = CURDATE();
    END IF;

    -- Route to appropriate view based on report type
    IF p_report_type='loading' THEN
        SELECT COUNT(*) INTO @total FROM vw_rpt_loading
        WHERE (p_from_date IS NULL OR Loading_Start_At >= p_from_date)
          AND (p_to_date IS NULL OR Loading_Start_At <= p_to_date)
          AND (p_bin_number IS NULL OR Bin_Number = p_bin_number)
          AND (p_operator_id IS NULL OR Loader_User_ID = p_operator_id)
          AND (p_bay_id IS NULL OR Bay_ID = p_bay_id)
          AND (p_material_id IS NULL OR Material_ID = p_material_id);
        SELECT *, @total AS total_count FROM vw_rpt_loading
        WHERE (p_from_date IS NULL OR Loading_Start_At >= p_from_date)
          AND (p_to_date IS NULL OR Loading_Start_At <= p_to_date)
          AND (p_bin_number IS NULL OR Bin_Number = p_bin_number)
          AND (p_operator_id IS NULL OR Loader_User_ID = p_operator_id)
          AND (p_bay_id IS NULL OR Bay_ID = p_bay_id)
          AND (p_material_id IS NULL OR Material_ID = p_material_id)
        ORDER BY Loading_Start_At DESC LIMIT p_page_size OFFSET v_offset;

    ELSEIF p_report_type='unloading' THEN
        SELECT COUNT(*) INTO @total FROM vw_rpt_unloading
        WHERE (p_from_date IS NULL OR Unloading_Start_At >= p_from_date)
          AND (p_to_date IS NULL OR Unloading_Start_At <= p_to_date)
          AND (p_bin_number IS NULL OR Bin_Number = p_bin_number)
          AND (p_operator_id IS NULL OR Unloader_User_ID = p_operator_id);
        SELECT *, @total AS total_count FROM vw_rpt_unloading
        WHERE (p_from_date IS NULL OR Unloading_Start_At >= p_from_date)
          AND (p_to_date IS NULL OR Unloading_Start_At <= p_to_date)
          AND (p_bin_number IS NULL OR Bin_Number = p_bin_number)
          AND (p_operator_id IS NULL OR Unloader_User_ID = p_operator_id)
        ORDER BY Unloading_Start_At DESC LIMIT p_page_size OFFSET v_offset;

    ELSEIF p_report_type='cleaning' THEN
        SELECT COUNT(*) INTO @total FROM vw_rpt_cleaning
        WHERE (p_from_date IS NULL OR Cleaning_Start_At >= p_from_date)
          AND (p_to_date IS NULL OR Cleaning_Start_At <= p_to_date)
          AND (p_bin_number IS NULL OR Bin_Number = p_bin_number)
          AND (p_operator_id IS NULL OR Cleaner_User_ID = p_operator_id);
        SELECT *, @total AS total_count FROM vw_rpt_cleaning
        WHERE (p_from_date IS NULL OR Cleaning_Start_At >= p_from_date)
          AND (p_to_date IS NULL OR Cleaning_Start_At <= p_to_date)
          AND (p_bin_number IS NULL OR Bin_Number = p_bin_number)
          AND (p_operator_id IS NULL OR Cleaner_User_ID = p_operator_id)
        ORDER BY Cleaning_Start_At DESC LIMIT p_page_size OFFSET v_offset;

    ELSEIF p_report_type='qa' THEN
        SELECT COUNT(*) INTO @total FROM vw_rpt_qa
        WHERE (p_from_date IS NULL OR QA_Start_At >= p_from_date)
          AND (p_to_date IS NULL OR QA_Start_At <= p_to_date)
          AND (p_bin_number IS NULL OR Bin_Number = p_bin_number)
          AND (p_operator_id IS NULL OR QA_Inspector_User_ID = p_operator_id);
        SELECT *, @total AS total_count FROM vw_rpt_qa
        WHERE (p_from_date IS NULL OR QA_Start_At >= p_from_date)
          AND (p_to_date IS NULL OR QA_Start_At <= p_to_date)
          AND (p_bin_number IS NULL OR Bin_Number = p_bin_number)
          AND (p_operator_id IS NULL OR QA_Inspector_User_ID = p_operator_id)
        ORDER BY QA_Start_At DESC LIMIT p_page_size OFFSET v_offset;

    ELSEIF p_report_type='rejected-bin' THEN
        SELECT *, COUNT(*) OVER() AS total_count FROM vw_rpt_rejected_bin
        ORDER BY Rejection_Date DESC LIMIT p_page_size OFFSET v_offset;

    ELSEIF p_report_type='bin-lifecycle' THEN
        SELECT COUNT(*) INTO @total FROM vw_rpt_lifecycle
        WHERE p_bin_number IS NULL OR Bin_Number = p_bin_number;
        SELECT *, @total AS total_count FROM vw_rpt_lifecycle
        WHERE p_bin_number IS NULL OR Bin_Number = p_bin_number
        ORDER BY Cycle_End_At DESC LIMIT p_page_size OFFSET v_offset;

    ELSEIF p_report_type='user-activity' THEN
        SELECT *, COUNT(*) OVER() AS total_count FROM vw_rpt_user_activity
        WHERE (p_operator_id IS NULL OR User_ID = p_operator_id)
        ORDER BY User_ID LIMIT p_page_size OFFSET v_offset;

    ELSEIF p_report_type='audit-trail' THEN
        SELECT COUNT(*) INTO @total FROM vw_rpt_audit_trail
        WHERE (p_from_date IS NULL OR Event_Timestamp >= p_from_date)
          AND (p_to_date IS NULL OR Event_Timestamp <= p_to_date)
          AND (p_operator_id IS NULL OR Actor_User_ID = p_operator_id);
        SELECT *, @total AS total_count FROM vw_rpt_audit_trail
        WHERE (p_from_date IS NULL OR Event_Timestamp >= p_from_date)
          AND (p_to_date IS NULL OR Event_Timestamp <= p_to_date)
          AND (p_operator_id IS NULL OR Actor_User_ID = p_operator_id)
        ORDER BY Event_Timestamp DESC LIMIT p_page_size OFFSET v_offset;

    ELSE
        SET p_error_code='VALIDATION_ERROR';
        SET p_error_message=CONCAT('Unknown report type: ', p_report_type);
        LEAVE sp_generate_report_label;
    END IF;

    SET p_success=1;
END //
DELIMITER ;

-- ============================================================
-- Migration 027: 027_create_audit_history_procedure.sql
-- ============================================================

-- PBLMS — Migration 027: sp_get_audit_history
DELIMITER //

CREATE PROCEDURE sp_get_audit_history(
    IN  p_entity_type   VARCHAR(30),  -- 'bin_history' or 'audit_log'
    IN  p_bin_id        INT,
    IN  p_user_id       INT,
    IN  p_action_type   VARCHAR(100),
    IN  p_from_date     DATETIME,
    IN  p_to_date       DATETIME,
    IN  p_page          INT,
    IN  p_page_size     INT,
    OUT p_success       TINYINT(1),
    OUT p_error_code    VARCHAR(100),
    OUT p_error_message VARCHAR(500)
)
BEGIN
    DECLARE v_offset INT DEFAULT 0;
    SET p_success=0; SET p_error_code=NULL; SET p_error_message=NULL;

    IF p_page_size NOT IN(25,50,100) THEN SET p_page_size=25; END IF;
    IF p_page<1 THEN SET p_page=1; END IF;
    SET v_offset=(p_page-1)*p_page_size;

    IF p_entity_type='bin_history' THEN
        SELECT COUNT(*) INTO @total FROM Bin_History h
        LEFT JOIN User_Master u ON u.User_ID=h.Acting_User_ID
        WHERE (p_bin_id IS NULL OR h.Bin_ID=p_bin_id)
          AND (p_user_id IS NULL OR h.Acting_User_ID=p_user_id)
          AND (p_from_date IS NULL OR h.Event_Timestamp>=p_from_date)
          AND (p_to_date IS NULL OR h.Event_Timestamp<=p_to_date);
        SELECT h.*, u.Full_Name AS Acting_User_Name, @total AS total_count
        FROM Bin_History h
        LEFT JOIN User_Master u ON u.User_ID=h.Acting_User_ID
        WHERE (p_bin_id IS NULL OR h.Bin_ID=p_bin_id)
          AND (p_user_id IS NULL OR h.Acting_User_ID=p_user_id)
          AND (p_from_date IS NULL OR h.Event_Timestamp>=p_from_date)
          AND (p_to_date IS NULL OR h.Event_Timestamp<=p_to_date)
        ORDER BY h.Event_Timestamp DESC LIMIT p_page_size OFFSET v_offset;

    ELSEIF p_entity_type='audit_log' THEN
        SELECT COUNT(*) INTO @total FROM Audit_Log a
        LEFT JOIN User_Master u ON u.User_ID=a.Actor_User_ID
        WHERE (p_user_id IS NULL OR a.Actor_User_ID=p_user_id)
          AND (p_action_type IS NULL OR a.Action_Type=p_action_type)
          AND (p_from_date IS NULL OR a.Event_Timestamp>=p_from_date)
          AND (p_to_date IS NULL OR a.Event_Timestamp<=p_to_date);
        SELECT a.*, u.Full_Name AS Actor_Name, @total AS total_count
        FROM Audit_Log a
        LEFT JOIN User_Master u ON u.User_ID=a.Actor_User_ID
        WHERE (p_user_id IS NULL OR a.Actor_User_ID=p_user_id)
          AND (p_action_type IS NULL OR a.Action_Type=p_action_type)
          AND (p_from_date IS NULL OR a.Event_Timestamp>=p_from_date)
          AND (p_to_date IS NULL OR a.Event_Timestamp<=p_to_date)
        ORDER BY a.Event_Timestamp DESC LIMIT p_page_size OFFSET v_offset;

    ELSE
        SET p_error_code='VALIDATION_ERROR';
        SET p_error_message='Invalid entity_type. Must be bin_history or audit_log';
        LEAVE sp_get_audit_history_label;
    END IF;

    SET p_success=1;
END //
DELIMITER ;

