const fs = require('fs');
const path = require('path');
const dir = path.join(__dirname, 'migrations');

// ---------------------------------------------------------------------------
// STEP 1: Fix the label bugs in migrations 026 and 027 (in-place)
// ---------------------------------------------------------------------------
const fixLabel = (filepath) => {
  let content = fs.readFileSync(filepath, 'utf8');
  // Replace unlabeled BEGIN with sp_main: BEGIN
  content = content.replace(/^\)\s*\n(BEGIN)\s*\n/m, ')\nsp_main: BEGIN\n');
  // Replace LEAVE xxx_label with LEAVE sp_main
  content = content.replace(/LEAVE\s+\w+_label\s*;/g, 'LEAVE sp_main;');
  // Replace END // with END sp_main; //
  content = content.replace(/^END\s*\/\/\s*$/m, 'END sp_main; //');
  fs.writeFileSync(filepath, content, 'utf8');
  console.log('Fixed labels in: ' + path.basename(filepath));
};

fixLabel(path.join(dir, '026_create_report_procedure.sql'));
fixLabel(path.join(dir, '027_create_audit_history_procedure.sql'));

// ---------------------------------------------------------------------------
// STEP 2: Generate the repair SQL from migrations 023-027
// ---------------------------------------------------------------------------
const files = [
  '023_create_dashboard_views.sql',
  '024_create_dashboard_procedure.sql',
  '025_create_report_objects.sql',
  '026_create_report_procedure.sql',
  '027_create_audit_history_procedure.sql',
];

let sql = `-- =============================================================================
-- PBLMS - Repair Script: Migrations 023-027
-- =============================================================================
-- Idempotent: safe to run multiple times.
-- Run: mysql -u root -p pblms < database/migrations/repair_023_027.sql
-- =============================================================================

`;

for (const file of files) {
  let content = fs.readFileSync(path.join(dir, file), 'utf8');
  content = content.replace(/^DELIMITER\s*\/\/\s*$/gm, '');
  content = content.replace(/^DELIMITER\s*;\s*$/gm, '');
  content = content.replace(/END\s*\/\//g, 'END;');
  const m = content.match(/CREATE\s+PROCEDURE\s+(\w+)/);
  if (m) {
    content = content.replace(
      /CREATE\s+PROCEDURE\s+\w+/,
      'DROP PROCEDURE IF EXISTS ' + m[1] + ';\n\nCREATE PROCEDURE ' + m[1]
    );
  }
  sql += '-- Migration: ' + file + '\n';
  sql += content.trim() + '\n\n';
}

sql += `-- Populate Schema_Migrations
INSERT IGNORE INTO Schema_Migrations (filename) VALUES
  ('023_create_dashboard_views.sql'),
  ('024_create_dashboard_procedure.sql'),
  ('025_create_report_objects.sql'),
  ('026_create_report_procedure.sql'),
  ('027_create_audit_history_procedure.sql');

-- Grant EXECUTE to application user
GRANT EXECUTE ON PROCEDURE pblms.sp_generate_dashboard_metrics TO 'pblms_app'@'%';
GRANT EXECUTE ON PROCEDURE pblms.sp_generate_report TO 'pblms_app'@'%';
GRANT EXECUTE ON PROCEDURE pblms.sp_get_audit_history TO 'pblms_app'@'%';
FLUSH PRIVILEGES;
`;

fs.writeFileSync(path.join(dir, 'repair_023_027.sql'), sql, 'utf8');
console.log('Generated: repair_023_027.sql (' + (sql.length / 1024).toFixed(1) + ' KB)');

