-- =============================================================================
-- PBLMS — sp_insert_bin_history
-- Appends an immutable lifecycle history record for a bin.
-- =============================================================================
-- Inputs:
--   p_bin_id               INT          — Bin_ID
--   p_previous_status      VARCHAR(50)  — Status before transition
--   p_new_status           VARCHAR(50)  — Status after transition
--   p_acting_user_id       INT          — User who triggered the transition
--   p_operation_type       VARCHAR(50)  — e.g. 'START_LOADING'
--   p_operation_record_id  INT          — FK to transaction record (nullable)
--   p_operation_record_type VARCHAR(30) — Table name of FK (nullable)
--   p_remarks              VARCHAR(500) — Optional notes (nullable)
--   p_cycle_number         INT          — Cycle number (nullable)
--
-- Outputs:
--   p_success, p_error_code, p_error_message
--   Data: history_id (new record ID)
-- =============================================================================
-- SECURITY: INSERT-only — no UPDATE or DELETE is ever performed.
-- Immutability is enforced at the database privilege level.
-- =============================================================================

DELIMITER //

CREATE PROCEDURE sp_insert_bin_history(
    IN  p_bin_id                INT,
    IN  p_previous_status       VARCHAR(50),
    IN  p_new_status            VARCHAR(50),
    IN  p_acting_user_id        INT,
    IN  p_operation_type        VARCHAR(50),
    IN  p_operation_record_id   INT,
    IN  p_operation_record_type VARCHAR(30),
    IN  p_remarks               VARCHAR(500),
    IN  p_cycle_number          INT,
    OUT p_success               TINYINT(1),
    OUT p_error_code            VARCHAR(100),
    OUT p_error_message         VARCHAR(500)
)
BEGIN
    SET p_success = 0;
    SET p_error_code = NULL;
    SET p_error_message = NULL;

    INSERT INTO Bin_History (
        Bin_ID, Previous_Status, New_Status, Acting_User_ID,
        Operation_Type, Operation_Record_ID, Operation_Record_Type,
        Remarks, Cycle_Number
    ) VALUES (
        p_bin_id, p_previous_status, p_new_status, p_acting_user_id,
        p_operation_type, p_operation_record_id, p_operation_record_type,
        p_remarks, p_cycle_number
    );

    SET p_success = 1;
    SELECT LAST_INSERT_ID() AS history_id;
END //

DELIMITER ;