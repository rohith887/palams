-- =============================================================================
-- PBLMS — sp_insert_audit_log
-- Records a system-level audit event for security and compliance.
-- =============================================================================
-- Inputs:
--   p_actor_user_id  INT           — User who performed the action (NULL for system)
--   p_action_type    VARCHAR(100)  — e.g. 'LOGIN_SUCCESS', 'MASTER_UPDATE', 'ROLE_CHANGED'
--   p_target_entity  VARCHAR(50)   — Table name of affected record (nullable)
--   p_target_id      INT           — PK of affected record (nullable)
--   p_old_value      JSON          — Previous state snapshot (nullable)
--   p_new_value      JSON          — New state snapshot (nullable)
--   p_ip_address     VARCHAR(45)   — Client IP (nullable)
--   p_user_agent     VARCHAR(500)  — Client user agent (nullable)
--
-- Outputs:
--   p_success, p_error_code, p_error_message
--   Data: audit_id (new record ID)
-- =============================================================================
-- SECURITY: INSERT-only — no UPDATE or DELETE is ever performed.
-- Immutability is enforced at the database privilege level.
-- =============================================================================

DELIMITER //

CREATE PROCEDURE sp_insert_audit_log(
    IN  p_actor_user_id  INT,
    IN  p_action_type    VARCHAR(100),
    IN  p_target_entity  VARCHAR(50),
    IN  p_target_id      INT,
    IN  p_old_value      JSON,
    IN  p_new_value      JSON,
    IN  p_ip_address     VARCHAR(45),
    IN  p_user_agent     VARCHAR(500),
    OUT p_success        TINYINT(1),
    OUT p_error_code     VARCHAR(100),
    OUT p_error_message  VARCHAR(500)
)
BEGIN
    SET p_success = 0;
    SET p_error_code = NULL;
    SET p_error_message = NULL;

    INSERT INTO Audit_Log (
        Actor_User_ID, Action_Type, Target_Entity, Target_ID,
        Old_Value, New_Value, IP_Address, User_Agent
    ) VALUES (
        p_actor_user_id, p_action_type, p_target_entity, p_target_id,
        p_old_value, p_new_value, p_ip_address, p_user_agent
    );

    SET p_success = 1;
    SELECT LAST_INSERT_ID() AS audit_id;
END //

DELIMITER ;