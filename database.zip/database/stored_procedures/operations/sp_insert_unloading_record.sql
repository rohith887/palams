-- =============================================================================
-- PBLMS — sp_insert_unloading_record
-- Inserts a new Unloading_Record and validates all FK references.
-- Workflow orchestration is handled by the workflow engine.
-- =============================================================================
-- Inputs:
--   p_bin_id, p_loading_id, p_unloader_user_id, p_quantity_unloaded,
--   p_unloading_condition, p_unloading_start_at, p_comments
-- Outputs:
--   p_success, p_error_code, p_error_message + unloading_id on success
-- =============================================================================

DELIMITER //

CREATE PROCEDURE sp_insert_unloading_record(
    IN  p_bin_id                INT,
    IN  p_loading_id            INT,
    IN  p_unloader_user_id      INT,
    IN  p_quantity_unloaded     DECIMAL(10,3),
    IN  p_unloading_condition   VARCHAR(30),
    IN  p_unloading_start_at    DATETIME,
    IN  p_comments              VARCHAR(500),
    OUT p_success               TINYINT(1),
    OUT p_error_code            VARCHAR(100),
    OUT p_error_message         VARCHAR(500)
)
BEGIN
    DECLARE v_loading_quantity DECIMAL(10,3);

    SET p_success = 0;
    SET p_error_code = NULL;
    SET p_error_message = NULL;

    -- Validate FK references
    IF NOT EXISTS (SELECT 1 FROM Bin_Master WHERE Bin_ID = p_bin_id AND Is_Active = 1) THEN
        SET p_error_code = 'BIN_NOT_FOUND';
        SET p_error_message = 'Bin not found or inactive';
    ELSEIF NOT EXISTS (SELECT 1 FROM User_Master WHERE User_ID = p_unloader_user_id AND Is_Active = 1) THEN
        SET p_error_code = 'NOT_FOUND';
        SET p_error_message = 'Unloader user not found or inactive';
    ELSEIF NOT EXISTS (SELECT 1 FROM Loading_Record WHERE Loading_ID = p_loading_id) THEN
        SET p_error_code = 'NOT_FOUND';
        SET p_error_message = 'Loading record not found';
    ELSEIF p_quantity_unloaded <= 0 THEN
        SET p_error_code = 'VALIDATION_ERROR';
        SET p_error_message = 'Quantity unloaded must be greater than zero';
    ELSEIF p_unloading_condition NOT IN ('Normal', 'Damaged', 'Contamination_Suspected') THEN
        SET p_error_code = 'VALIDATION_ERROR';
        SET p_error_message = 'Unloading condition must be Normal, Damaged, or Contamination_Suspected';
    ELSE
        -- Validate quantity does not exceed what was loaded
        SELECT Quantity_Loaded INTO v_loading_quantity
        FROM Loading_Record
        WHERE Loading_ID = p_loading_id;

        IF p_quantity_unloaded > v_loading_quantity THEN
            SET p_error_code = 'VALIDATION_ERROR';
            SET p_error_message = 'Quantity unloaded exceeds quantity loaded';
        ELSE
            START TRANSACTION;

            INSERT INTO Unloading_Record (
                Bin_ID, Loading_ID, Unloader_User_ID,
                Quantity_Unloaded, Unloading_Condition,
                Unloading_Start_At, Comments
            ) VALUES (
                p_bin_id, p_loading_id, p_unloader_user_id,
                p_quantity_unloaded, p_unloading_condition,
                p_unloading_start_at, p_comments
            );

            SET p_success = 1;
            SELECT LAST_INSERT_ID() AS unloading_id;

            COMMIT;
        END IF;
    END IF;
END //

DELIMITER ;