-- =============================================================================
-- PBLMS — sp_insert_loading_record
-- Inserts a new Loading_Record and validates all FK references.
-- Workflow orchestration (lock, history, audit, status transition) is handled
-- by the workflow engine service — this SP ONLY handles the data insert.
-- =============================================================================
-- Inputs:
--   p_bin_id, p_loader_user_id, p_bay_id, p_tank_id, p_material_id,
--   p_quantity_loaded, p_unit_of_measure, p_batch_number,
--   p_expected_unloading_date, p_loading_start_at, p_comments
-- Outputs:
--   p_success, p_error_code, p_error_message + loading_id on success
-- =============================================================================

DELIMITER //

CREATE PROCEDURE sp_insert_loading_record(
    IN  p_bin_id                  INT,
    IN  p_loader_user_id          INT,
    IN  p_bay_id                  INT,
    IN  p_tank_id                  INT,
    IN  p_material_id             INT,
    IN  p_quantity_loaded         DECIMAL(10,3),
    IN  p_unit_of_measure         VARCHAR(20),
    IN  p_batch_number            VARCHAR(100),
    IN  p_expected_unloading_date DATE,
    IN  p_loading_start_at        DATETIME,
    IN  p_comments                VARCHAR(500),
    OUT p_success                 TINYINT(1),
    OUT p_error_code              VARCHAR(100),
    OUT p_error_message           VARCHAR(500)
)
BEGIN
    SET p_success = 0;
    SET p_error_code = NULL;
    SET p_error_message = NULL;

    -- Validate FK references
    IF NOT EXISTS (SELECT 1 FROM Bin_Master WHERE Bin_ID = p_bin_id AND Is_Active = 1) THEN
        SET p_error_code = 'BIN_NOT_FOUND';
        SET p_error_message = 'Bin not found or inactive';
    ELSEIF NOT EXISTS (SELECT 1 FROM User_Master WHERE User_ID = p_loader_user_id AND Is_Active = 1) THEN
        SET p_error_code = 'NOT_FOUND';
        SET p_error_message = 'Loader user not found or inactive';
    ELSEIF NOT EXISTS (SELECT 1 FROM Bay_Master WHERE Bay_ID = p_bay_id AND Is_Active = 1) THEN
        SET p_error_code = 'NOT_FOUND';
        SET p_error_message = 'Bay not found or inactive';
    ELSEIF NOT EXISTS (SELECT 1 FROM Tank_Master WHERE Tank_ID = p_tank_id AND Is_Active = 1) THEN
        SET p_error_code = 'NOT_FOUND';
        SET p_error_message = 'Tank not found or inactive';
    ELSEIF NOT EXISTS (SELECT 1 FROM Material_Master WHERE Material_ID = p_material_id AND Is_Active = 1) THEN
        SET p_error_code = 'NOT_FOUND';
        SET p_error_message = 'Material not found or inactive';
    ELSEIF p_quantity_loaded <= 0 THEN
        SET p_error_code = 'VALIDATION_ERROR';
        SET p_error_message = 'Quantity loaded must be greater than zero';
    ELSEIF p_expected_unloading_date <= CURDATE() THEN
        SET p_error_code = 'VALIDATION_ERROR';
        SET p_error_message = 'Expected unloading date must be in the future';
    ELSE
        START TRANSACTION;

        INSERT INTO Loading_Record (
            Bin_ID, Loader_User_ID, Bay_ID, Tank_ID, Material_ID,
            Quantity_Loaded, Unit_Of_Measure, Batch_Number,
            Expected_Unloading_Date, Loading_Start_At, Comments
        ) VALUES (
            p_bin_id, p_loader_user_id, p_bay_id, p_tank_id, p_material_id,
            p_quantity_loaded, p_unit_of_measure, p_batch_number,
            p_expected_unloading_date, p_loading_start_at, p_comments
        );

        SET p_success = 1;
        SELECT LAST_INSERT_ID() AS loading_id;

        COMMIT;
    END IF;
END //

DELIMITER ;