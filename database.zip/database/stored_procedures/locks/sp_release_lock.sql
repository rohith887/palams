-- =============================================================================
-- PBLMS — sp_release_lock
-- Releases an operation lock held by a specific user on a specific bin.
-- Idempotent — succeeds even if no matching lock exists.
-- =============================================================================
-- Inputs:
--   p_bin_id   INT — Bin to unlock
--   p_user_id  INT — User who holds the lock
--
-- Outputs:
--   p_success, p_error_code, p_error_message
--   Data: rows_deleted (INT) — number of locks removed (0 or 1)
-- =============================================================================

DELIMITER //

CREATE PROCEDURE sp_release_lock(
    IN  p_bin_id        INT,
    IN  p_user_id       INT,
    OUT p_success       TINYINT(1),
    OUT p_error_code    VARCHAR(100),
    OUT p_error_message VARCHAR(500)
)
BEGIN
    DECLARE v_rows_deleted INT DEFAULT 0;

    SET p_success = 0;
    SET p_error_code = NULL;
    SET p_error_message = NULL;

    START TRANSACTION;

    DELETE FROM Lock_Table
    WHERE  Bin_ID = p_bin_id
      AND  Locked_By_User_ID = p_user_id;

    SET v_rows_deleted = ROW_COUNT();

    SET p_success = 1;
    SELECT v_rows_deleted AS rows_deleted;

    COMMIT;
END //

DELIMITER ;