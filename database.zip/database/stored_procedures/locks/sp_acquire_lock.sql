-- =============================================================================
-- PBLMS — sp_acquire_lock
-- Acquires an exclusive operation lock on a bin.
-- The UNIQUE constraint on Lock_Table.Bin_ID guarantees mutual exclusion.
-- =============================================================================
-- Inputs:
--   p_bin_id          INT          — Bin to lock
--   p_user_id         INT          — User acquiring the lock
--   p_operation_type  VARCHAR(50)  — e.g. 'START_LOADING'
--   p_lock_duration_minutes INT    — Lock TTL in minutes (default 60)
--
-- Outputs:
--   p_success, p_error_code, p_error_message
--   Data: lock_id, lock_expires_at, locked_by_name (if already locked)
-- =============================================================================
-- Error codes:
--   BIN_NOT_FOUND             — Bin does not exist
--   BIN_OPERATION_IN_PROGRESS — Active lock held by another user
-- =============================================================================

DELIMITER //

CREATE PROCEDURE sp_acquire_lock(
    IN  p_bin_id                INT,
    IN  p_user_id               INT,
    IN  p_operation_type        VARCHAR(50),
    IN  p_lock_duration_minutes INT,
    OUT p_success               TINYINT(1),
    OUT p_error_code            VARCHAR(100),
    OUT p_error_message         VARCHAR(500)
)
BEGIN
    DECLARE v_bin_exists       TINYINT(1) DEFAULT 0;
    DECLARE v_existing_lock_id INT;
    DECLARE v_lock_expires     DATETIME;
    DECLARE v_lock_holder_id   INT;
    DECLARE v_lock_holder_name VARCHAR(150);
    DECLARE v_new_lock_id      INT;
    DECLARE v_expires_at       DATETIME;

    SET p_success = 0;
    SET p_error_code = NULL;
    SET p_error_message = NULL;

    -- Default duration to 60 minutes if not provided
    IF p_lock_duration_minutes IS NULL OR p_lock_duration_minutes <= 0 THEN
        SET p_lock_duration_minutes = 60;
    END IF;

    -- Verify bin exists
    SELECT COUNT(*) INTO v_bin_exists FROM Bin_Master WHERE Bin_ID = p_bin_id;
    IF v_bin_exists = 0 THEN
        SET p_error_code = 'BIN_NOT_FOUND';
        SET p_error_message = 'Bin not found';
    ELSE
        START TRANSACTION;

        -- Check for existing active lock
        SELECT l.Lock_ID, l.Expires_At, l.Locked_By_User_ID, u.Full_Name
        INTO   v_existing_lock_id, v_lock_expires, v_lock_holder_id, v_lock_holder_name
        FROM   Lock_Table l
               LEFT JOIN User_Master u ON u.User_ID = l.Locked_By_User_ID
        WHERE  l.Bin_ID = p_bin_id;

        IF v_existing_lock_id IS NOT NULL THEN
            -- Lock exists — check if expired
            IF v_lock_expires <= NOW() THEN
                -- Expired lock — remove it, then proceed to acquire new lock
                DELETE FROM Lock_Table WHERE Lock_ID = v_existing_lock_id;
            ELSE
                -- Active lock held by someone
                IF v_lock_holder_id = p_user_id THEN
                    -- Same user — return existing lock (idempotent)
                    SET p_success = 1;
                    SELECT v_existing_lock_id AS lock_id,
                           v_lock_expires AS lock_expires_at;
                    COMMIT;
                    LEAVE sp_acquire_lock_label;
                ELSE
                    -- Different user — conflict
                    SET p_error_code = 'BIN_OPERATION_IN_PROGRESS';
                    SET p_error_message = CONCAT('Bin is currently locked by ', v_lock_holder_name);
                    ROLLBACK;
                    SELECT v_lock_holder_name AS locked_by_name;
                    LEAVE sp_acquire_lock_label;
                END IF;
            END IF;
        END IF;

        -- Acquire new lock
        SET v_expires_at = DATE_ADD(NOW(), INTERVAL p_lock_duration_minutes MINUTE);

        INSERT INTO Lock_Table (Bin_ID, Locked_By_User_ID, Operation_Type, Expires_At)
        VALUES (p_bin_id, p_user_id, p_operation_type, v_expires_at);

        SET v_new_lock_id = LAST_INSERT_ID();

        SET p_success = 1;
        SELECT v_new_lock_id AS lock_id,
               v_expires_at AS lock_expires_at;

        COMMIT;
    END IF;

    -- Label for early exit inside the ELSE block
    BEGIN END;
END //

DELIMITER ;