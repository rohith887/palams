-- =============================================================================
-- PBLMS — sp_manage_bay Stored Procedure
-- Pharmaceutical Bin Lifecycle Management System
-- =============================================================================
-- Purpose:
--   Handles Bay_Master CRUD operations (CREATE, UPDATE, DEACTIVATE).
--   Deactivation cascades to child Tanks.
--   Prevents deactivation if bay has active bins assigned.
--
-- Input Parameters:
--   p_action       VARCHAR(20)  — CREATE / UPDATE / DEACTIVATE
--   p_admin_user_id INT         — Administrator performing the action
--   p_bay_id        INT         — Bay_ID (required for UPDATE/DEACTIVATE)
--   p_bay_code      VARCHAR(20) — Bay_Code (required for CREATE)
--   p_bay_name      VARCHAR(100)— Bay_Name (required for CREATE/UPDATE)
--   p_location_desc VARCHAR(500)— Location_Description (optional)
--
-- Output Parameters:
--   p_success, p_error_code, p_error_message
--   Data: bay_id (on CREATE)
-- =============================================================================

DELIMITER //

CREATE PROCEDURE sp_manage_bay(
    IN  p_action         VARCHAR(20),
    IN  p_admin_user_id  INT,
    IN  p_bay_id         INT,
    IN  p_bay_code       VARCHAR(20),
    IN  p_bay_name       VARCHAR(100),
    IN  p_location_desc  VARCHAR(500),
    OUT p_success        TINYINT(1),
    OUT p_error_code     VARCHAR(100),
    OUT p_error_message  VARCHAR(500)
)
BEGIN
    SET p_success = 0;
    SET p_error_code = NULL;
    SET p_error_message = NULL;

    IF p_action = 'CREATE' THEN
        IF EXISTS (SELECT 1 FROM Bay_Master WHERE Bay_Code = p_bay_code) THEN
            SET p_error_code = 'DUPLICATE_ENTRY';
            SET p_error_message = CONCAT('Bay code "', p_bay_code, '" already exists');
        ELSE
            INSERT INTO Bay_Master (Bay_Code, Bay_Name, Location_Description, Created_By)
            VALUES (p_bay_code, p_bay_name, p_location_desc, p_admin_user_id);
            SET p_success = 1;
            SELECT LAST_INSERT_ID() AS bay_id;
        END IF;

    ELSEIF p_action = 'UPDATE' THEN
        IF NOT EXISTS (SELECT 1 FROM Bay_Master WHERE Bay_ID = p_bay_id) THEN
            SET p_error_code = 'NOT_FOUND';
            SET p_error_message = 'Bay not found';
        ELSE
            UPDATE Bay_Master
            SET Bay_Name = p_bay_name,
                Location_Description = p_location_desc
            WHERE Bay_ID = p_bay_id;
            SET p_success = 1;
        END IF;

    ELSEIF p_action = 'DEACTIVATE' THEN
        IF NOT EXISTS (SELECT 1 FROM Bay_Master WHERE Bay_ID = p_bay_id) THEN
            SET p_error_code = 'NOT_FOUND';
            SET p_error_message = 'Bay not found';
        ELSEIF EXISTS (
            SELECT 1 FROM Bin_Master
            WHERE Current_Bay_ID = p_bay_id
              AND Current_Status NOT IN ('Awaiting_Loading', 'Retired')
              AND Is_Active = 1
        ) THEN
            SET p_error_code = 'LOCATION_IN_USE';
            SET p_error_message = 'Cannot deactivate bay with active bin assignments';
        ELSE
            UPDATE Bay_Master SET Is_Active = 0 WHERE Bay_ID = p_bay_id;
            UPDATE Tank_Master SET Is_Active = 0 WHERE Bay_ID = p_bay_id;
            SET p_success = 1;
        END IF;

    ELSE
        SET p_error_code = 'VALIDATION_ERROR';
        SET p_error_message = CONCAT('Invalid action: ', p_action);
    END IF;
END //

DELIMITER ;