-- =============================================================================
-- PBLMS — sp_manage_tank Stored Procedure
-- Pharmaceutical Bin Lifecycle Management System
-- =============================================================================
-- Inputs: p_action(CREATE/UPDATE/DEACTIVATE), p_admin_user_id, p_tank_id,
--         p_bay_id, p_tank_code, p_tank_name, p_tank_capacity
-- Outputs: p_success, p_error_code, p_error_message + tank_id on CREATE
-- =============================================================================
DELIMITER //

CREATE PROCEDURE sp_manage_tank(
    IN  p_action          VARCHAR(20),
    IN  p_admin_user_id   INT,
    IN  p_tank_id         INT,
    IN  p_bay_id          INT,
    IN  p_tank_code       VARCHAR(20),
    IN  p_tank_name       VARCHAR(100),
    IN  p_tank_capacity   DECIMAL(10,3),
    OUT p_success         TINYINT(1),
    OUT p_error_code      VARCHAR(100),
    OUT p_error_message   VARCHAR(500)
)
BEGIN
    SET p_success = 0; SET p_error_code = NULL; SET p_error_message = NULL;

    IF p_action = 'CREATE' THEN
        IF NOT EXISTS (SELECT 1 FROM Bay_Master WHERE Bay_ID = p_bay_id AND Is_Active = 1) THEN
            SET p_error_code = 'NOT_FOUND'; SET p_error_message = 'Bay not found or inactive';
        ELSEIF EXISTS (SELECT 1 FROM Tank_Master WHERE Tank_Code = p_tank_code) THEN
            SET p_error_code = 'DUPLICATE_ENTRY'; SET p_error_message = CONCAT('Tank code "', p_tank_code, '" already exists');
        ELSE
            INSERT INTO Tank_Master (Bay_ID, Tank_Code, Tank_Name, Tank_Capacity, Created_By)
            VALUES (p_bay_id, p_tank_code, p_tank_name, p_tank_capacity, p_admin_user_id);
            SET p_success = 1; SELECT LAST_INSERT_ID() AS tank_id;
        END IF;

    ELSEIF p_action = 'UPDATE' THEN
        IF NOT EXISTS (SELECT 1 FROM Tank_Master WHERE Tank_ID = p_tank_id) THEN
            SET p_error_code = 'NOT_FOUND'; SET p_error_message = 'Tank not found';
        ELSE
            UPDATE Tank_Master SET Tank_Name = p_tank_name, Tank_Capacity = p_tank_capacity, Bay_ID = p_bay_id
            WHERE Tank_ID = p_tank_id;
            SET p_success = 1;
        END IF;

    ELSEIF p_action = 'DEACTIVATE' THEN
        IF NOT EXISTS (SELECT 1 FROM Tank_Master WHERE Tank_ID = p_tank_id) THEN
            SET p_error_code = 'NOT_FOUND'; SET p_error_message = 'Tank not found';
        ELSEIF EXISTS (SELECT 1 FROM Bin_Master WHERE Current_Tank_ID = p_tank_id AND Current_Status NOT IN ('Awaiting_Loading','Retired') AND Is_Active = 1) THEN
            SET p_error_code = 'LOCATION_IN_USE'; SET p_error_message = 'Cannot deactivate tank with active bin assignments';
        ELSE
            UPDATE Tank_Master SET Is_Active = 0 WHERE Tank_ID = p_tank_id;
            SET p_success = 1;
        END IF;

    ELSE SET p_error_code = 'VALIDATION_ERROR'; SET p_error_message = CONCAT('Invalid action: ', p_action);
    END IF;
END //

DELIMITER ;