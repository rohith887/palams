-- =============================================================================
-- PBLMS — sp_manage_material Stored Procedure
-- Pharmaceutical Bin Lifecycle Management System
-- =============================================================================
-- Handles Material_Master CRUD (CREATE/UPDATE/DEACTIVATE).
-- Validates Storage_Temp_Max_C > Storage_Temp_Min_C when both provided.
-- Inputs: p_action, p_admin_user_id, p_material_id, p_material_code,
--         p_material_name, p_material_category, p_hazard_level,
--         p_temp_min, p_temp_max, p_handling_instructions
-- Outputs: p_success, p_error_code, p_error_message + material_id on CREATE
-- =============================================================================
DELIMITER //

CREATE PROCEDURE sp_manage_material(
    IN  p_action                VARCHAR(20),
    IN  p_admin_user_id         INT,
    IN  p_material_id           INT,
    IN  p_material_code         VARCHAR(30),
    IN  p_material_name         VARCHAR(200),
    IN  p_material_category     VARCHAR(100),
    IN  p_hazard_level          VARCHAR(10),
    IN  p_temp_min              DECIMAL(5,2),
    IN  p_temp_max              DECIMAL(5,2),
    IN  p_handling_instructions VARCHAR(1000),
    OUT p_success               TINYINT(1),
    OUT p_error_code            VARCHAR(100),
    OUT p_error_message         VARCHAR(500)
)
BEGIN
    SET p_success = 0; SET p_error_code = NULL; SET p_error_message = NULL;

    IF p_hazard_level NOT IN ('Low','Medium','High') THEN
        SET p_error_code = 'VALIDATION_ERROR'; SET p_error_message = 'Hazard_Level must be Low, Medium, or High';
    ELSEIF p_temp_min IS NOT NULL AND p_temp_max IS NOT NULL AND p_temp_max <= p_temp_min THEN
        SET p_error_code = 'VALIDATION_ERROR'; SET p_error_message = 'Max temperature must exceed Min temperature';
    ELSEIF p_action = 'CREATE' THEN
        IF EXISTS (SELECT 1 FROM Material_Master WHERE Material_Code = p_material_code) THEN
            SET p_error_code = 'DUPLICATE_ENTRY'; SET p_error_message = CONCAT('Material code "', p_material_code, '" already exists');
        ELSE
            INSERT INTO Material_Master (Material_Code, Material_Name, Material_Category, Hazard_Level, Storage_Temp_Min_C, Storage_Temp_Max_C, Handling_Instructions, Created_By)
            VALUES (p_material_code, p_material_name, p_material_category, p_hazard_level, p_temp_min, p_temp_max, p_handling_instructions, p_admin_user_id);
            SET p_success = 1; SELECT LAST_INSERT_ID() AS material_id;
        END IF;

    ELSEIF p_action = 'UPDATE' THEN
        IF NOT EXISTS (SELECT 1 FROM Material_Master WHERE Material_ID = p_material_id) THEN
            SET p_error_code = 'NOT_FOUND'; SET p_error_message = 'Material not found';
        ELSE
            UPDATE Material_Master SET Material_Name = p_material_name, Material_Category = p_material_category,
                Hazard_Level = p_hazard_level, Storage_Temp_Min_C = p_temp_min, Storage_Temp_Max_C = p_temp_max,
                Handling_Instructions = p_handling_instructions
            WHERE Material_ID = p_material_id;
            SET p_success = 1;
        END IF;

    ELSEIF p_action = 'DEACTIVATE' THEN
        IF NOT EXISTS (SELECT 1 FROM Material_Master WHERE Material_ID = p_material_id) THEN
            SET p_error_code = 'NOT_FOUND'; SET p_error_message = 'Material not found';
        ELSE
            UPDATE Material_Master SET Is_Active = 0 WHERE Material_ID = p_material_id;
            SET p_success = 1;
        END IF;

    ELSE SET p_error_code = 'VALIDATION_ERROR'; SET p_error_message = CONCAT('Invalid action: ', p_action);
    END IF;
END //

DELIMITER ;