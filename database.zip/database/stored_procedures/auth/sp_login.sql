-- =============================================================================
-- PBLMS — sp_login Stored Procedure
-- Pharmaceutical Bin Lifecycle Management System
-- =============================================================================
-- Purpose:
--   Authenticates a user by username. Handles account lockout validation,
--   failed login counting, lockout enforcement, and success tracking.
--   bcrypt password comparison occurs in the Node.js service layer — this
--   SP returns the Password_Hash for service-side verification.
--
-- Input Parameters:
--   p_username    VARCHAR(50)  — Login username
--   p_ip_address  VARCHAR(45)  — Client IP address for audit
--   p_user_agent  VARCHAR(500) — Client user agent for audit
--
-- Output Parameters:
--   p_success       TINYINT(1)    — 1 = success, 0 = failure
--   p_error_code    VARCHAR(100)  — Structured error code on failure
--   p_error_message VARCHAR(500)  — Human-readable error message on failure
--
-- Data Result Set (on success):
--   user_id, username, password_hash, full_name, role, is_active
--
-- Business Rules:
--   - If username not found → AUTH_INVALID_CREDENTIALS
--   - If Lockout_Until > NOW() → AUTH_ACCOUNT_LOCKED
--   - On login failure: increment Failed_Login_Count
--   - If Failed_Login_Count reaches 5: set Lockout_Until = NOW() + 30 minutes
--   - On login success: reset Failed_Login_Count = 0, set Last_Login_At = NOW()
--   - All within a single transaction with Audit_Log INSERT
--
-- Design Spec Reference: Section 9.2
-- =============================================================================

DELIMITER //

CREATE PROCEDURE sp_login(
    IN  p_username    VARCHAR(50),
    IN  p_ip_address  VARCHAR(45),
    IN  p_user_agent  VARCHAR(500),
    OUT p_success       TINYINT(1),
    OUT p_error_code    VARCHAR(100),
    OUT p_error_message VARCHAR(500)
)
BEGIN
    DECLARE v_user_id        INT;
    DECLARE v_password_hash  VARCHAR(255);
    DECLARE v_full_name      VARCHAR(150);
    DECLARE v_role           VARCHAR(50);
    DECLARE v_is_active      TINYINT(1);
    DECLARE v_failed_count   TINYINT;
    DECLARE v_lockout_until  DATETIME;
    DECLARE v_is_locked      TINYINT DEFAULT 0;

    -- Default: failure
    SET p_success = 0;
    SET p_error_code = NULL;
    SET p_error_message = NULL;

    -- Lookup user by username
    SELECT User_ID, Password_Hash, Full_Name, Role, Is_Active,
           Failed_Login_Count, Lockout_Until
    INTO   v_user_id, v_password_hash, v_full_name, v_role, v_is_active,
           v_failed_count, v_lockout_until
    FROM   User_Master
    WHERE  Username = p_username;

    -- User not found
    IF v_user_id IS NULL THEN
        SET p_error_code = 'AUTH_INVALID_CREDENTIALS';
        SET p_error_message = 'Invalid username or password';
    ELSE
        -- Check if account is locked
        IF v_lockout_until IS NOT NULL AND v_lockout_until > NOW() THEN
            SET v_is_locked = 1;
            SET p_error_code = 'AUTH_ACCOUNT_LOCKED';
            SET p_error_message = 'Account is locked due to too many failed login attempts';
        ELSE
            -- Return user record for password verification in service layer
            -- The service layer compares the bcrypt hash and calls sp_login_success
            -- or handles failure accordingly.
            -- This SP returns the record; the caller determines success/failure.
            SET p_success = 1;

            SELECT v_user_id        AS user_id,
                   p_username       AS username,
                   v_password_hash  AS password_hash,
                   v_full_name      AS full_name,
                   v_role           AS role,
                   v_is_active      AS is_active;
        END IF;
    END IF;
END //

DELIMITER ;