-- =============================================================================
-- PBLMS — sp_logout Stored Procedure
-- Pharmaceutical Bin Lifecycle Management System
-- =============================================================================
-- Purpose:
--   Revokes a refresh token on user logout. Sets Is_Revoked = 1 on the
--   matching Refresh_Token row, preventing reuse of the token.
--
-- Input Parameters:
--   p_user_id     INT          — Authenticated user ID
--   p_token_hash  VARCHAR(255) — bcrypt hash of the refresh token to revoke
--
-- Output Parameters:
--   p_success       TINYINT(1)    — 1 = success
--   p_error_code    VARCHAR(100)
--   p_error_message VARCHAR(500)
--
-- Design Spec Reference: Section 9.2
-- =============================================================================

DELIMITER //

CREATE PROCEDURE sp_logout(
    IN  p_user_id       INT,
    IN  p_token_hash    VARCHAR(255),
    OUT p_success       TINYINT(1),
    OUT p_error_code    VARCHAR(100),
    OUT p_error_message VARCHAR(500)
)
BEGIN
    DECLARE v_rows_affected INT DEFAULT 0;

    SET p_success = 0;
    SET p_error_code = NULL;
    SET p_error_message = NULL;

    -- Revoke the specific refresh token for this user
    UPDATE Refresh_Token
    SET    Is_Revoked = 1
    WHERE  Token_Hash = p_token_hash
      AND  User_ID = p_user_id;

    SET v_rows_affected = ROW_COUNT();

    IF v_rows_affected = 0 THEN
        -- Token not found or already revoked — idempotent, return success
        SET p_success = 1;
    ELSE
        SET p_success = 1;
    END IF;
END //

DELIMITER ;