-- =============================================================================
-- PBLMS — sp_refresh_token Stored Procedure
-- Pharmaceutical Bin Lifecycle Management System
-- =============================================================================
-- Purpose:
--   Validates a refresh token by looking up its hash in the Refresh_Token
--   table. Returns the associated user record if the token is valid,
--   not revoked, and not expired.
--
-- Input Parameters:
--   p_token_hash  VARCHAR(255) — bcrypt hash of the raw refresh token
--
-- Output Parameters:
--   p_success       TINYINT(1)    — 1 = valid, 0 = invalid
--   p_error_code    VARCHAR(100)  — AUTH_REFRESH_TOKEN_INVALID on failure
--   p_error_message VARCHAR(500)  — Error description
--
-- Data Result Set (on success):
--   user_id, role, full_name
--
-- Design Spec Reference: Section 9.2
-- =============================================================================

DELIMITER //

CREATE PROCEDURE sp_refresh_token(
    IN  p_token_hash    VARCHAR(255),
    OUT p_success       TINYINT(1),
    OUT p_error_code    VARCHAR(100),
    OUT p_error_message VARCHAR(500)
)
BEGIN
    DECLARE v_user_id   INT;
    DECLARE v_role      VARCHAR(50);
    DECLARE v_full_name VARCHAR(150);

    SET p_success = 0;
    SET p_error_code = NULL;
    SET p_error_message = NULL;

    -- Look up valid, non-revoked, non-expired refresh token
    SELECT rt.User_ID, u.Role, u.Full_Name
    INTO   v_user_id, v_role, v_full_name
    FROM   Refresh_Token rt
           INNER JOIN User_Master u ON u.User_ID = rt.User_ID
    WHERE  rt.Token_Hash = p_token_hash
      AND  rt.Is_Revoked = 0
      AND  rt.Expires_At > NOW();

    IF v_user_id IS NULL THEN
        SET p_error_code = 'AUTH_REFRESH_TOKEN_INVALID';
        SET p_error_message = 'Refresh token is invalid, revoked, or expired';
    ELSE
        SET p_success = 1;

        SELECT v_user_id   AS user_id,
               v_role      AS role,
               v_full_name AS full_name;
    END IF;
END //

DELIMITER ;