-- PBLMS — Migration 027: sp_get_audit_history
DELIMITER //

CREATE PROCEDURE sp_get_audit_history(
    IN  p_entity_type   VARCHAR(30),  -- 'bin_history' or 'audit_log'
    IN  p_bin_id        INT,
    IN  p_user_id       INT,
    IN  p_action_type   VARCHAR(100),
    IN  p_from_date     DATETIME,
    IN  p_to_date       DATETIME,
    IN  p_page          INT,
    IN  p_page_size     INT,
    OUT p_success       TINYINT(1),
    OUT p_error_code    VARCHAR(100),
    OUT p_error_message VARCHAR(500)
)
sp_main: BEGIN
    DECLARE v_offset INT DEFAULT 0;
    SET p_success=0; SET p_error_code=NULL; SET p_error_message=NULL;

    IF p_page_size NOT IN(25,50,100) THEN SET p_page_size=25; END IF;
    IF p_page<1 THEN SET p_page=1; END IF;
    SET v_offset=(p_page-1)*p_page_size;

    IF p_entity_type='bin_history' THEN
        SELECT COUNT(*) INTO @total FROM Bin_History h
        LEFT JOIN User_Master u ON u.User_ID=h.Acting_User_ID
        WHERE (p_bin_id IS NULL OR h.Bin_ID=p_bin_id)
          AND (p_user_id IS NULL OR h.Acting_User_ID=p_user_id)
          AND (p_from_date IS NULL OR h.Event_Timestamp>=p_from_date)
          AND (p_to_date IS NULL OR h.Event_Timestamp<=p_to_date);
        SELECT h.*, u.Full_Name AS Acting_User_Name, @total AS total_count
        FROM Bin_History h
        LEFT JOIN User_Master u ON u.User_ID=h.Acting_User_ID
        WHERE (p_bin_id IS NULL OR h.Bin_ID=p_bin_id)
          AND (p_user_id IS NULL OR h.Acting_User_ID=p_user_id)
          AND (p_from_date IS NULL OR h.Event_Timestamp>=p_from_date)
          AND (p_to_date IS NULL OR h.Event_Timestamp<=p_to_date)
        ORDER BY h.Event_Timestamp DESC LIMIT p_page_size OFFSET v_offset;

    ELSEIF p_entity_type='audit_log' THEN
        SELECT COUNT(*) INTO @total FROM Audit_Log a
        LEFT JOIN User_Master u ON u.User_ID=a.Actor_User_ID
        WHERE (p_user_id IS NULL OR a.Actor_User_ID=p_user_id)
          AND (p_action_type IS NULL OR a.Action_Type=p_action_type)
          AND (p_from_date IS NULL OR a.Event_Timestamp>=p_from_date)
          AND (p_to_date IS NULL OR a.Event_Timestamp<=p_to_date);
        SELECT a.*, u.Full_Name AS Actor_Name, @total AS total_count
        FROM Audit_Log a
        LEFT JOIN User_Master u ON u.User_ID=a.Actor_User_ID
        WHERE (p_user_id IS NULL OR a.Actor_User_ID=p_user_id)
          AND (p_action_type IS NULL OR a.Action_Type=p_action_type)
          AND (p_from_date IS NULL OR a.Event_Timestamp>=p_from_date)
          AND (p_to_date IS NULL OR a.Event_Timestamp<=p_to_date)
        ORDER BY a.Event_Timestamp DESC LIMIT p_page_size OFFSET v_offset;

    ELSE
        SET p_error_code='VALIDATION_ERROR';
        SET p_error_message='Invalid entity_type. Must be bin_history or audit_log';
        LEAVE sp_main;
    END IF;

    SET p_success=1;
END sp_main; //
DELIMITER ;