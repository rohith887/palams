-- =============================================================================
-- PBLMS - Repair Script: Migrations 023-027
-- =============================================================================
-- Idempotent: safe to run multiple times.
-- Run: mysql -u root -p pblms < database/migrations/repair_023_027.sql
-- =============================================================================

-- Migration: 023_create_dashboard_views.sql
-- PBLMS Migration 023: Cycle_Record + Dashboard Views
CREATE TABLE IF NOT EXISTS Cycle_Record (
    Cycle_ID INT AUTO_INCREMENT PRIMARY KEY,
    Bin_ID INT NOT NULL,
    QA_ID INT NOT NULL,
    Cycle_Start_At DATETIME NOT NULL,
    Cycle_End_At DATETIME NOT NULL,
    Total_Cycle_Duration_Minutes INT NOT NULL,
    Loading_Duration_Minutes INT NOT NULL,
    Unloading_Duration_Minutes INT NOT NULL,
    Cleaning_Duration_Minutes INT NOT NULL,
    QA_Duration_Minutes INT NOT NULL,
    Reinspection_Count TINYINT NOT NULL DEFAULT 0,
    INDEX idx_bin_id (Bin_ID), INDEX idx_cycle_end (Cycle_End_At),
    CONSTRAINT fk_cycle_bin FOREIGN KEY (Bin_ID) REFERENCES Bin_Master(Bin_ID) ON DELETE RESTRICT,
    CONSTRAINT fk_cycle_qa FOREIGN KEY (QA_ID) REFERENCES QA_Record(QA_ID) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Active locks view
CREATE OR REPLACE VIEW vw_active_locks AS
SELECT l.Lock_ID, l.Bin_ID, b.Bin_Number, l.Locked_By_User_ID, u.Full_Name AS locked_by_name,
       l.Operation_Type, l.Lock_Timestamp, l.Expires_At
FROM Lock_Table l
JOIN Bin_Master b ON b.Bin_ID = l.Bin_ID
JOIN User_Master u ON u.User_ID = l.Locked_By_User_ID;

-- Admin dashboard
CREATE OR REPLACE VIEW vw_dashboard_admin AS
SELECT
  (SELECT COUNT(*) FROM Bin_Master WHERE Is_Active=1) AS total_active_bins,
  (SELECT COUNT(*) FROM Bin_Master WHERE Current_Status='Awaiting_Loading' AND Is_Active=1) AS awaiting_loading,
  (SELECT COUNT(*) FROM Bin_Master WHERE Current_Status='Loading_In_Progress' AND Is_Active=1) AS loading_in_progress,
  (SELECT COUNT(*) FROM Bin_Master WHERE Current_Status='Awaiting_Unloading' AND Is_Active=1) AS awaiting_unloading,
  (SELECT COUNT(*) FROM Bin_Master WHERE Current_Status='Unloading_In_Progress' AND Is_Active=1) AS unloading_in_progress,
  (SELECT COUNT(*) FROM Bin_Master WHERE Current_Status='Awaiting_Cleaning' AND Is_Active=1) AS awaiting_cleaning,
  (SELECT COUNT(*) FROM Bin_Master WHERE Current_Status='Cleaning_In_Progress' AND Is_Active=1) AS cleaning_in_progress,
  (SELECT COUNT(*) FROM Bin_Master WHERE Current_Status='Awaiting_QA' AND Is_Active=1) AS awaiting_qa,
  (SELECT COUNT(*) FROM Bin_Master WHERE Current_Status='QA_In_Progress' AND Is_Active=1) AS qa_in_progress,
  (SELECT COUNT(*) FROM Bin_Master WHERE Current_Status='QA_Failed' AND Is_Active=1) AS qa_failed,
  (SELECT COUNT(*) FROM Bin_Master WHERE Current_Status='Reinspection_Cleaning' AND Is_Active=1) AS reinspection_cleaning,
  (SELECT COUNT(*) FROM Bin_Master WHERE Current_Status='Awaiting_Reinspection' AND Is_Active=1) AS awaiting_reinspection,
  (SELECT COUNT(*) FROM Bin_Master WHERE Current_Status='Retired' AND Is_Active=1) AS retired,
  (SELECT COUNT(*) FROM Bin_Master WHERE Requires_Admin_Review=1) AS admin_review_bins,
  (SELECT COUNT(*) FROM Bin_Master WHERE Overdue_Unloading=1) AS overdue_unloading,
  (SELECT COUNT(*) FROM Loading_Record WHERE DATE(Loading_Start_At)=CURDATE()) AS today_loading,
  (SELECT COUNT(*) FROM Unloading_Record WHERE DATE(Unloading_Start_At)=CURDATE()) AS today_unloading,
  (SELECT COUNT(*) FROM Cleaning_Record WHERE DATE(Cleaning_Start_At)=CURDATE()) AS today_cleaning,
  (SELECT COUNT(*) FROM QA_Record WHERE DATE(QA_Start_At)=CURDATE()) AS today_qa,
  COALESCE((SELECT ROUND(SUM(Overall_Result='PASS')*100.0/COUNT(*),1) FROM QA_Record WHERE DATE(QA_Start_At)=CURDATE()),0) AS qa_pass_rate_today,
  COALESCE((SELECT ROUND(SUM(Overall_Result='PASS')*100.0/COUNT(*),1) FROM QA_Record WHERE QA_Start_At>=DATE_SUB(CURDATE(),INTERVAL 7 DAY)),0) AS qa_pass_rate_7day,
  COALESCE((SELECT ROUND(AVG(Total_Cycle_Duration_Minutes)) FROM Cycle_Record WHERE Cycle_End_At>=DATE_SUB(CURDATE(),INTERVAL 30 DAY)),0) AS avg_cycle_time_30day;

-- Loader dashboard
CREATE OR REPLACE VIEW vw_dashboard_loader AS
SELECT
  (SELECT COUNT(*) FROM Bin_Master WHERE Current_Status='Awaiting_Loading' AND Is_Active=1) AS awaiting_loading,
  (SELECT COUNT(*) FROM Loading_Record WHERE DATE(Loading_Start_At)=CURDATE()) AS today_loadings;

-- Unloader dashboard
CREATE OR REPLACE VIEW vw_dashboard_unloader AS
SELECT
  (SELECT COUNT(*) FROM Bin_Master WHERE Current_Status='Awaiting_Unloading' AND Is_Active=1) AS awaiting_unloading,
  (SELECT COUNT(*) FROM Loading_Record l JOIN Bin_Master b ON b.Bin_ID=l.Bin_ID WHERE b.Overdue_Unloading=1 AND l.Is_Current=1) AS overdue_unloading;

-- Cleaner dashboard
CREATE OR REPLACE VIEW vw_dashboard_cleaner AS
SELECT
  (SELECT COUNT(*) FROM Bin_Master WHERE Current_Status='Awaiting_Cleaning' AND Is_Active=1) AS awaiting_cleaning,
  (SELECT COUNT(*) FROM Bin_Master WHERE Current_Status='Reinspection_Cleaning' AND Is_Active=1) AS reinspection_cleaning;

-- QA dashboard
CREATE OR REPLACE VIEW vw_dashboard_qa AS
SELECT
  (SELECT COUNT(*) FROM Bin_Master WHERE Current_Status='Awaiting_QA' AND Is_Active=1) AS awaiting_qa,
  (SELECT COUNT(*) FROM Bin_Master WHERE Current_Status='Awaiting_Reinspection' AND Is_Active=1) AS awaiting_reinspection,
  (SELECT COUNT(*) FROM QA_Record WHERE DATE(QA_Start_At)=CURDATE() AND Overall_Result='FAIL') AS today_failures,
  COALESCE((SELECT ROUND(SUM(Overall_Result='PASS')*100.0/COUNT(*),1) FROM QA_Record WHERE QA_Start_At>=DATE_SUB(CURDATE(),INTERVAL 7 DAY)),0) AS pass_rate_week;

-- Average cycle time
CREATE OR REPLACE VIEW vw_avg_cycle_time AS
SELECT COALESCE(ROUND(AVG(Total_Cycle_Duration_Minutes)),0) AS avg_minutes
FROM Cycle_Record WHERE Cycle_End_At>=DATE_SUB(CURDATE(),INTERVAL 30 DAY);

-- Migration: 024_create_dashboard_procedure.sql
-- PBLMS — Migration 024: sp_generate_dashboard_metrics

DROP PROCEDURE IF EXISTS sp_generate_dashboard_metrics;

CREATE PROCEDURE sp_generate_dashboard_metrics(
    IN  p_user_role     VARCHAR(50),
    OUT p_success       TINYINT(1),
    OUT p_error_code    VARCHAR(100),
    OUT p_error_message VARCHAR(500)
)
BEGIN
    SET p_success=0; SET p_error_code=NULL; SET p_error_message=NULL;

    IF p_user_role='Administrator' THEN
        SELECT * FROM vw_dashboard_admin;
    ELSEIF p_user_role='Loader' THEN
        SELECT * FROM vw_dashboard_loader;
    ELSEIF p_user_role='Unloader' THEN
        SELECT * FROM vw_dashboard_unloader;
    ELSEIF p_user_role='Cleaner' THEN
        SELECT * FROM vw_dashboard_cleaner;
    ELSEIF p_user_role='QA_Inspector' THEN
        SELECT * FROM vw_dashboard_qa;
    ELSE
        SELECT * FROM vw_dashboard_loader;
    END IF;

    SET p_success=1;
END;

-- Migration: 025_create_report_objects.sql
-- =============================================================================
-- PBLMS — Migration 025: Report Database Objects
-- Pharmaceutical Bin Lifecycle Management System
-- =============================================================================
-- Design Spec Reference: Section 4.5
-- Creates all report-related views required by the Reports module.
-- =============================================================================

-- ---------------------------------------------------------------------------
-- 1. vw_bin_lifecycle_summary — Per-bin current state with latest operation
-- ---------------------------------------------------------------------------
CREATE OR REPLACE VIEW vw_bin_lifecycle_summary AS
SELECT
  b.Bin_ID, b.Bin_Number, b.QR_Code_Value, b.Current_Status, b.Is_Active,
  b.Current_Bay_ID, b.Current_Tank_ID, b.Requires_Admin_Review,
  b.Requires_QA_Attention, b.Overdue_Unloading, b.Consecutive_Fail_Count,
  b.Last_QA_Date, b.Row_Version, b.Created_At,
  bt.Type_Name AS Bin_Type_Name,
  bc.Category_Name AS Bin_Category_Name,
  bay.Bay_Code, bay.Bay_Name,
  tank.Tank_Code, tank.Tank_Name,
  l.Loading_ID, l.Loader_User_ID, lu.Full_Name AS Loader_Name,
  l.Material_ID, m.Material_Name, l.Batch_Number, l.Quantity_Loaded,
  l.Unit_Of_Measure, l.Expected_Unloading_Date,
  l.Loading_Start_At, l.Loading_Completed_At,
  un.Unloading_ID, un.Unloader_User_ID, uu.Full_Name AS Unloader_Name,
  un.Unloading_Condition, un.Quantity_Unloaded,
  cr.Cleaning_ID, cr.Cleaner_User_ID, cu.Full_Name AS Cleaner_Name,
  cr.Cleaning_Method, cr.Cleaning_Agent,
  qa.QA_ID, qa.QA_Inspector_User_ID, qu.Full_Name AS QA_Inspector_Name,
  qa.Overall_Result, qa.Failure_Reason, qa.QA_Completed_At
FROM Bin_Master b
LEFT JOIN Bin_Type_Master bt ON bt.Bin_Type_ID = b.Bin_Type_ID
LEFT JOIN Bin_Category_Master bc ON bc.Bin_Category_ID = b.Bin_Category_ID
LEFT JOIN Bay_Master bay ON bay.Bay_ID = b.Current_Bay_ID
LEFT JOIN Tank_Master tank ON tank.Tank_ID = b.Current_Tank_ID
LEFT JOIN Loading_Record l ON l.Bin_ID = b.Bin_ID AND l.Is_Current = 1
LEFT JOIN User_Master lu ON lu.User_ID = l.Loader_User_ID
LEFT JOIN Material_Master m ON m.Material_ID = l.Material_ID
LEFT JOIN Unloading_Record un ON un.Bin_ID = b.Bin_ID AND un.Loading_ID = l.Loading_ID
LEFT JOIN User_Master uu ON uu.User_ID = un.Unloader_User_ID
LEFT JOIN Cleaning_Record cr ON cr.Bin_ID = b.Bin_ID AND cr.Loading_ID = l.Loading_ID
LEFT JOIN User_Master cu ON cu.User_ID = cr.Cleaner_User_ID
LEFT JOIN QA_Record qa ON qa.Bin_ID = b.Bin_ID AND qa.Cleaning_ID = cr.Cleaning_ID
LEFT JOIN User_Master qu ON qu.User_ID = qa.QA_Inspector_User_ID;

-- ---------------------------------------------------------------------------
-- 2. vw_rpt_loading — Loading report base query
-- ---------------------------------------------------------------------------
CREATE OR REPLACE VIEW vw_rpt_loading AS
SELECT
  l.Loading_ID, l.Bin_ID, b.Bin_Number,
  l.Loader_User_ID, u.Full_Name AS Loader_Name,
  l.Bay_ID, bay.Bay_Code, bay.Bay_Name,
  l.Tank_ID, tank.Tank_Code, tank.Tank_Name,
  l.Material_ID, m.Material_Code, m.Material_Name, m.Hazard_Level,
  l.Quantity_Loaded, l.Unit_Of_Measure, l.Batch_Number,
  l.Expected_Unloading_Date, l.Loading_Start_At, l.Loading_Completed_At,
  l.Comments, l.Is_Current
FROM Loading_Record l
JOIN Bin_Master b ON b.Bin_ID = l.Bin_ID
JOIN User_Master u ON u.User_ID = l.Loader_User_ID
JOIN Bay_Master bay ON bay.Bay_ID = l.Bay_ID
JOIN Tank_Master tank ON tank.Tank_ID = l.Tank_ID
JOIN Material_Master m ON m.Material_ID = l.Material_ID;

-- ---------------------------------------------------------------------------
-- 3. vw_rpt_unloading — Unloading report base query
-- ---------------------------------------------------------------------------
CREATE OR REPLACE VIEW vw_rpt_unloading AS
SELECT
  un.Unloading_ID, un.Bin_ID, b.Bin_Number,
  un.Loading_ID, l.Material_ID, m.Material_Name, l.Batch_Number,
  l.Quantity_Loaded, un.Quantity_Unloaded,
  un.Unloader_User_ID, uu.Full_Name AS Unloader_Name,
  lu.Full_Name AS Loader_Name,
  un.Unloading_Condition,
  un.Unloading_Start_At, un.Unloading_Completed_At,
  un.Comments
FROM Unloading_Record un
JOIN Bin_Master b ON b.Bin_ID = un.Bin_ID
JOIN Loading_Record l ON l.Loading_ID = un.Loading_ID
JOIN User_Master uu ON uu.User_ID = un.Unloader_User_ID
JOIN User_Master lu ON lu.User_ID = l.Loader_User_ID
JOIN Material_Master m ON m.Material_ID = l.Material_ID;

-- ---------------------------------------------------------------------------
-- 4. vw_rpt_cleaning — Cleaning report base query
-- ---------------------------------------------------------------------------
CREATE OR REPLACE VIEW vw_rpt_cleaning AS
SELECT
  cr.Cleaning_ID, cr.Bin_ID, b.Bin_Number,
  cr.Cleaner_User_ID, u.Full_Name AS Cleaner_Name,
  cr.Cleaning_Method, cr.Cleaning_Agent,
  cr.Water_Temp_Celsius, cr.Rinse_Cycles,
  cr.Is_Reinspection_Cycle,
  cr.Cleaning_Start_At, cr.Cleaning_Completed_At,
  cr.Comments
FROM Cleaning_Record cr
JOIN Bin_Master b ON b.Bin_ID = cr.Bin_ID
JOIN User_Master u ON u.User_ID = cr.Cleaner_User_ID;

-- ---------------------------------------------------------------------------
-- 5. vw_rpt_qa — QA report base query with all 6 checklist items
-- ---------------------------------------------------------------------------
CREATE OR REPLACE VIEW vw_rpt_qa AS
SELECT
  qa.QA_ID, qa.Bin_ID, b.Bin_Number,
  qa.QA_Inspector_User_ID, u.Full_Name AS QA_Inspector_Name,
  qa.Cleaning_ID, cr.Cleaning_Method, cr.Cleaning_Agent,
  qa.Visual_Inspection, qa.Visual_Notes,
  qa.Residue_Check, qa.Residue_Notes,
  qa.Damage_Assessment, qa.Damage_Notes,
  qa.Odor_Check, qa.Odor_Notes,
  qa.Label_Integrity, qa.Label_Notes,
  qa.Seal_Integrity, qa.Seal_Notes,
  qa.Overall_Result, qa.Failure_Reason, qa.Is_Reinspection,
  qa.QA_Start_At, qa.QA_Completed_At
FROM QA_Record qa
JOIN Bin_Master b ON b.Bin_ID = qa.Bin_ID
JOIN User_Master u ON u.User_ID = qa.QA_Inspector_User_ID
JOIN Cleaning_Record cr ON cr.Cleaning_ID = qa.Cleaning_ID;

-- ---------------------------------------------------------------------------
-- 6. vw_rpt_rejected_bin — Rejected bins with consecutive fail count
-- ---------------------------------------------------------------------------
CREATE OR REPLACE VIEW vw_rpt_rejected_bin AS
SELECT
  b.Bin_ID, b.Bin_Number, b.Current_Status, b.Consecutive_Fail_Count,
  qa.QA_ID AS Last_QA_ID, qa.Overall_Result, qa.Failure_Reason,
  qa.QA_Completed_At AS Rejection_Date,
  u.Full_Name AS QA_Inspector_Name,
  DATEDIFF(CURDATE(), COALESCE(qa.QA_Completed_At, b.Last_QA_Date)) AS Days_Since_Rejection
FROM Bin_Master b
JOIN QA_Record qa ON qa.Bin_ID = b.Bin_ID
JOIN User_Master u ON u.User_ID = qa.QA_Inspector_User_ID
WHERE b.Current_Status = 'QA_Failed' AND qa.Overall_Result = 'FAIL'
ORDER BY qa.QA_Completed_At DESC;

-- ---------------------------------------------------------------------------
-- 7. vw_rpt_lifecycle — Full bin lifecycle timeline per cycle from Cycle_Record
-- ---------------------------------------------------------------------------
CREATE OR REPLACE VIEW vw_rpt_lifecycle AS
SELECT
  c.Cycle_ID, c.Bin_ID, b.Bin_Number,
  c.Cycle_Start_At, c.Cycle_End_At,
  c.Total_Cycle_Duration_Minutes,
  c.Loading_Duration_Minutes, c.Unloading_Duration_Minutes,
  c.Cleaning_Duration_Minutes, c.QA_Duration_Minutes,
  c.Reinspection_Count,
  qa.QA_ID, qa.Overall_Result,
  u.Full_Name AS QA_Inspector_Name
FROM Cycle_Record c
JOIN Bin_Master b ON b.Bin_ID = c.Bin_ID
JOIN QA_Record qa ON qa.QA_ID = c.QA_ID
JOIN User_Master u ON u.User_ID = qa.QA_Inspector_User_ID;

-- ---------------------------------------------------------------------------
-- 8. vw_rpt_user_activity — User operation counts from all transaction tables
-- ---------------------------------------------------------------------------
CREATE OR REPLACE VIEW vw_rpt_user_activity AS
SELECT
  u.User_ID, u.Username, u.Full_Name, u.Role,
  COALESCE(l.load_count,0) AS loading_count,
  COALESCE(un.unload_count,0) AS unloading_count,
  COALESCE(cl.clean_count,0) AS cleaning_count,
  COALESCE(qa.qa_count,0) AS qa_count,
  COALESCE(l.last_loading, un.last_unloading, cl.last_cleaning, qa.last_qa) AS last_activity
FROM User_Master u
LEFT JOIN (
  SELECT Loader_User_ID, COUNT(*) AS load_count, MAX(Loading_Start_At) AS last_loading
  FROM Loading_Record GROUP BY Loader_User_ID
) l ON l.Loader_User_ID = u.User_ID
LEFT JOIN (
  SELECT Unloader_User_ID, COUNT(*) AS unload_count, MAX(Unloading_Start_At) AS last_unloading
  FROM Unloading_Record GROUP BY Unloader_User_ID
) un ON un.Unloader_User_ID = u.User_ID
LEFT JOIN (
  SELECT Cleaner_User_ID, COUNT(*) AS clean_count, MAX(Cleaning_Start_At) AS last_cleaning
  FROM Cleaning_Record GROUP BY Cleaner_User_ID
) cl ON cl.Cleaner_User_ID = u.User_ID
LEFT JOIN (
  SELECT QA_Inspector_User_ID, COUNT(*) AS qa_count, MAX(QA_Start_At) AS last_qa
  FROM QA_Record GROUP BY QA_Inspector_User_ID
) qa ON qa.QA_Inspector_User_ID = u.User_ID;

-- ---------------------------------------------------------------------------
-- 9. vw_rpt_audit_trail — Filterable audit log with user names
-- ---------------------------------------------------------------------------
CREATE OR REPLACE VIEW vw_rpt_audit_trail AS
SELECT
  a.Audit_ID, a.Actor_User_ID, u.Full_Name AS Actor_Name,
  a.Action_Type, a.Target_Entity, a.Target_ID,
  a.Old_Value, a.New_Value, a.IP_Address, a.User_Agent,
  a.Event_Timestamp
FROM Audit_Log a
LEFT JOIN User_Master u ON u.User_ID = a.Actor_User_ID;

-- Migration: 026_create_report_procedure.sql
-- PBLMS — Migration 026: sp_generate_report

DROP PROCEDURE IF EXISTS sp_generate_report;

CREATE PROCEDURE sp_generate_report(
    IN  p_report_type   VARCHAR(50),
    IN  p_from_date     DATE,
    IN  p_to_date       DATE,
    IN  p_bin_number    VARCHAR(30),
    IN  p_operator_id   INT,
    IN  p_bay_id        INT,
    IN  p_material_id   INT,
    IN  p_page          INT,
    IN  p_page_size     INT,
    OUT p_success       TINYINT(1),
    OUT p_error_code    VARCHAR(100),
    OUT p_error_message VARCHAR(500)
)
sp_main: BEGIN
    DECLARE v_offset INT DEFAULT 0;
    SET p_success=0; SET p_error_code=NULL; SET p_error_message=NULL;

    -- Validate page size
    IF p_page_size NOT IN(25,50,100) THEN SET p_page_size=25; END IF;
    IF p_page IS NULL OR p_page<1 THEN SET p_page=1; END IF;
    SET v_offset = (p_page-1) * p_page_size;

    -- Default date range: current month if both NULL
    IF p_from_date IS NULL AND p_to_date IS NULL THEN
        SET p_from_date = DATE_FORMAT(CURDATE(), '%Y-%m-01');
        SET p_to_date = CURDATE();
    END IF;

    -- Route to appropriate view based on report type
    IF p_report_type='loading' THEN
        SELECT COUNT(*) INTO @total FROM vw_rpt_loading
        WHERE (p_from_date IS NULL OR Loading_Start_At >= p_from_date)
          AND (p_to_date IS NULL OR Loading_Start_At <= p_to_date)
          AND (p_bin_number IS NULL OR Bin_Number = p_bin_number)
          AND (p_operator_id IS NULL OR Loader_User_ID = p_operator_id)
          AND (p_bay_id IS NULL OR Bay_ID = p_bay_id)
          AND (p_material_id IS NULL OR Material_ID = p_material_id);
        SELECT *, @total AS total_count FROM vw_rpt_loading
        WHERE (p_from_date IS NULL OR Loading_Start_At >= p_from_date)
          AND (p_to_date IS NULL OR Loading_Start_At <= p_to_date)
          AND (p_bin_number IS NULL OR Bin_Number = p_bin_number)
          AND (p_operator_id IS NULL OR Loader_User_ID = p_operator_id)
          AND (p_bay_id IS NULL OR Bay_ID = p_bay_id)
          AND (p_material_id IS NULL OR Material_ID = p_material_id)
        ORDER BY Loading_Start_At DESC LIMIT p_page_size OFFSET v_offset;

    ELSEIF p_report_type='unloading' THEN
        SELECT COUNT(*) INTO @total FROM vw_rpt_unloading
        WHERE (p_from_date IS NULL OR Unloading_Start_At >= p_from_date)
          AND (p_to_date IS NULL OR Unloading_Start_At <= p_to_date)
          AND (p_bin_number IS NULL OR Bin_Number = p_bin_number)
          AND (p_operator_id IS NULL OR Unloader_User_ID = p_operator_id);
        SELECT *, @total AS total_count FROM vw_rpt_unloading
        WHERE (p_from_date IS NULL OR Unloading_Start_At >= p_from_date)
          AND (p_to_date IS NULL OR Unloading_Start_At <= p_to_date)
          AND (p_bin_number IS NULL OR Bin_Number = p_bin_number)
          AND (p_operator_id IS NULL OR Unloader_User_ID = p_operator_id)
        ORDER BY Unloading_Start_At DESC LIMIT p_page_size OFFSET v_offset;

    ELSEIF p_report_type='cleaning' THEN
        SELECT COUNT(*) INTO @total FROM vw_rpt_cleaning
        WHERE (p_from_date IS NULL OR Cleaning_Start_At >= p_from_date)
          AND (p_to_date IS NULL OR Cleaning_Start_At <= p_to_date)
          AND (p_bin_number IS NULL OR Bin_Number = p_bin_number)
          AND (p_operator_id IS NULL OR Cleaner_User_ID = p_operator_id);
        SELECT *, @total AS total_count FROM vw_rpt_cleaning
        WHERE (p_from_date IS NULL OR Cleaning_Start_At >= p_from_date)
          AND (p_to_date IS NULL OR Cleaning_Start_At <= p_to_date)
          AND (p_bin_number IS NULL OR Bin_Number = p_bin_number)
          AND (p_operator_id IS NULL OR Cleaner_User_ID = p_operator_id)
        ORDER BY Cleaning_Start_At DESC LIMIT p_page_size OFFSET v_offset;

    ELSEIF p_report_type='qa' THEN
        SELECT COUNT(*) INTO @total FROM vw_rpt_qa
        WHERE (p_from_date IS NULL OR QA_Start_At >= p_from_date)
          AND (p_to_date IS NULL OR QA_Start_At <= p_to_date)
          AND (p_bin_number IS NULL OR Bin_Number = p_bin_number)
          AND (p_operator_id IS NULL OR QA_Inspector_User_ID = p_operator_id);
        SELECT *, @total AS total_count FROM vw_rpt_qa
        WHERE (p_from_date IS NULL OR QA_Start_At >= p_from_date)
          AND (p_to_date IS NULL OR QA_Start_At <= p_to_date)
          AND (p_bin_number IS NULL OR Bin_Number = p_bin_number)
          AND (p_operator_id IS NULL OR QA_Inspector_User_ID = p_operator_id)
        ORDER BY QA_Start_At DESC LIMIT p_page_size OFFSET v_offset;

    ELSEIF p_report_type='rejected-bin' THEN
        SELECT *, COUNT(*) OVER() AS total_count FROM vw_rpt_rejected_bin
        ORDER BY Rejection_Date DESC LIMIT p_page_size OFFSET v_offset;

    ELSEIF p_report_type='bin-lifecycle' THEN
        SELECT COUNT(*) INTO @total FROM vw_rpt_lifecycle
        WHERE p_bin_number IS NULL OR Bin_Number = p_bin_number;
        SELECT *, @total AS total_count FROM vw_rpt_lifecycle
        WHERE p_bin_number IS NULL OR Bin_Number = p_bin_number
        ORDER BY Cycle_End_At DESC LIMIT p_page_size OFFSET v_offset;

    ELSEIF p_report_type='user-activity' THEN
        SELECT *, COUNT(*) OVER() AS total_count FROM vw_rpt_user_activity
        WHERE (p_operator_id IS NULL OR User_ID = p_operator_id)
        ORDER BY User_ID LIMIT p_page_size OFFSET v_offset;

    ELSEIF p_report_type='audit-trail' THEN
        SELECT COUNT(*) INTO @total FROM vw_rpt_audit_trail
        WHERE (p_from_date IS NULL OR Event_Timestamp >= p_from_date)
          AND (p_to_date IS NULL OR Event_Timestamp <= p_to_date)
          AND (p_operator_id IS NULL OR Actor_User_ID = p_operator_id);
        SELECT *, @total AS total_count FROM vw_rpt_audit_trail
        WHERE (p_from_date IS NULL OR Event_Timestamp >= p_from_date)
          AND (p_to_date IS NULL OR Event_Timestamp <= p_to_date)
          AND (p_operator_id IS NULL OR Actor_User_ID = p_operator_id)
        ORDER BY Event_Timestamp DESC LIMIT p_page_size OFFSET v_offset;

    ELSE
        SET p_error_code='VALIDATION_ERROR';
        SET p_error_message=CONCAT('Unknown report type: ', p_report_type);
        LEAVE sp_main;
    END IF;

    SET p_success=1;
END sp_main; //

-- Migration: 027_create_audit_history_procedure.sql
-- PBLMS — Migration 027: sp_get_audit_history

DROP PROCEDURE IF EXISTS sp_get_audit_history;

CREATE PROCEDURE sp_get_audit_history(
    IN  p_entity_type   VARCHAR(30),  -- 'bin_history' or 'audit_log'
    IN  p_bin_id        INT,
    IN  p_user_id       INT,
    IN  p_action_type   VARCHAR(100),
    IN  p_from_date     DATETIME,
    IN  p_to_date       DATETIME,
    IN  p_page          INT,
    IN  p_page_size     INT,
    OUT p_success       TINYINT(1),
    OUT p_error_code    VARCHAR(100),
    OUT p_error_message VARCHAR(500)
)
sp_main: BEGIN
    DECLARE v_offset INT DEFAULT 0;
    SET p_success=0; SET p_error_code=NULL; SET p_error_message=NULL;

    IF p_page_size NOT IN(25,50,100) THEN SET p_page_size=25; END IF;
    IF p_page<1 THEN SET p_page=1; END IF;
    SET v_offset=(p_page-1)*p_page_size;

    IF p_entity_type='bin_history' THEN
        SELECT COUNT(*) INTO @total FROM Bin_History h
        LEFT JOIN User_Master u ON u.User_ID=h.Acting_User_ID
        WHERE (p_bin_id IS NULL OR h.Bin_ID=p_bin_id)
          AND (p_user_id IS NULL OR h.Acting_User_ID=p_user_id)
          AND (p_from_date IS NULL OR h.Event_Timestamp>=p_from_date)
          AND (p_to_date IS NULL OR h.Event_Timestamp<=p_to_date);
        SELECT h.*, u.Full_Name AS Acting_User_Name, @total AS total_count
        FROM Bin_History h
        LEFT JOIN User_Master u ON u.User_ID=h.Acting_User_ID
        WHERE (p_bin_id IS NULL OR h.Bin_ID=p_bin_id)
          AND (p_user_id IS NULL OR h.Acting_User_ID=p_user_id)
          AND (p_from_date IS NULL OR h.Event_Timestamp>=p_from_date)
          AND (p_to_date IS NULL OR h.Event_Timestamp<=p_to_date)
        ORDER BY h.Event_Timestamp DESC LIMIT p_page_size OFFSET v_offset;

    ELSEIF p_entity_type='audit_log' THEN
        SELECT COUNT(*) INTO @total FROM Audit_Log a
        LEFT JOIN User_Master u ON u.User_ID=a.Actor_User_ID
        WHERE (p_user_id IS NULL OR a.Actor_User_ID=p_user_id)
          AND (p_action_type IS NULL OR a.Action_Type=p_action_type)
          AND (p_from_date IS NULL OR a.Event_Timestamp>=p_from_date)
          AND (p_to_date IS NULL OR a.Event_Timestamp<=p_to_date);
        SELECT a.*, u.Full_Name AS Actor_Name, @total AS total_count
        FROM Audit_Log a
        LEFT JOIN User_Master u ON u.User_ID=a.Actor_User_ID
        WHERE (p_user_id IS NULL OR a.Actor_User_ID=p_user_id)
          AND (p_action_type IS NULL OR a.Action_Type=p_action_type)
          AND (p_from_date IS NULL OR a.Event_Timestamp>=p_from_date)
          AND (p_to_date IS NULL OR a.Event_Timestamp<=p_to_date)
        ORDER BY a.Event_Timestamp DESC LIMIT p_page_size OFFSET v_offset;

    ELSE
        SET p_error_code='VALIDATION_ERROR';
        SET p_error_message='Invalid entity_type. Must be bin_history or audit_log';
        LEAVE sp_main;
    END IF;

    SET p_success=1;
END sp_main; //

-- Populate Schema_Migrations
INSERT IGNORE INTO Schema_Migrations (filename) VALUES
  ('023_create_dashboard_views.sql'),
  ('024_create_dashboard_procedure.sql'),
  ('025_create_report_objects.sql'),
  ('026_create_report_procedure.sql'),
  ('027_create_audit_history_procedure.sql');

-- Grant EXECUTE to application user
GRANT EXECUTE ON PROCEDURE pblms.sp_generate_dashboard_metrics TO 'pblms_app'@'%';
GRANT EXECUTE ON PROCEDURE pblms.sp_generate_report TO 'pblms_app'@'%';
GRANT EXECUTE ON PROCEDURE pblms.sp_get_audit_history TO 'pblms_app'@'%';
FLUSH PRIVILEGES;
