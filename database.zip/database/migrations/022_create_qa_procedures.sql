-- =============================================================================
-- PBLMS — Migration 022: QA_Record Table + sp_start_qa + sp_complete_qa
-- =============================================================================
CREATE TABLE IF NOT EXISTS QA_Record (
    QA_ID INT AUTO_INCREMENT PRIMARY KEY,
    Bin_ID INT NOT NULL,
    Cleaning_ID INT NOT NULL,
    QA_Inspector_User_ID INT NOT NULL,
    Visual_Inspection ENUM('Pass','Fail') NOT NULL,
    Visual_Notes VARCHAR(500) NULL,
    Residue_Check ENUM('Pass','Fail') NOT NULL,
    Residue_Notes VARCHAR(500) NULL,
    Damage_Assessment ENUM('Pass','Fail') NOT NULL,
    Damage_Notes VARCHAR(500) NULL,
    Odor_Check ENUM('Pass','Fail') NOT NULL,
    Odor_Notes VARCHAR(500) NULL,
    Label_Integrity ENUM('Pass','Fail') NOT NULL,
    Label_Notes VARCHAR(500) NULL,
    Seal_Integrity ENUM('Pass','Fail') NOT NULL,
    Seal_Notes VARCHAR(500) NULL,
    Overall_Result ENUM('PASS','FAIL') NOT NULL,
    Failure_Reason VARCHAR(1000) NULL,
    Is_Reinspection TINYINT(1) NOT NULL DEFAULT 0,
    QA_Start_At DATETIME NOT NULL,
    QA_Completed_At DATETIME NULL,
    INDEX idx_bin_id (Bin_ID), INDEX idx_cleaning_id (Cleaning_ID),
    CONSTRAINT chk_failure_reason CHECK (Overall_Result='PASS' OR Failure_Reason IS NOT NULL),
    CONSTRAINT fk_qa_bin FOREIGN KEY (Bin_ID) REFERENCES Bin_Master(Bin_ID) ON DELETE RESTRICT,
    CONSTRAINT fk_qa_cleaning FOREIGN KEY (Cleaning_ID) REFERENCES Cleaning_Record(Cleaning_ID) ON DELETE RESTRICT,
    CONSTRAINT fk_qa_inspector FOREIGN KEY (QA_Inspector_User_ID) REFERENCES User_Master(User_ID) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DELIMITER //

CREATE PROCEDURE sp_start_qa(
    IN  p_bin_id INT, IN p_user_id INT, IN p_user_role VARCHAR(50), IN p_row_version INT,
    OUT p_success TINYINT(1), OUT p_error_code VARCHAR(100), OUT p_error_message VARCHAR(500)
)
sp_start: BEGIN
    DECLARE v_from_status VARCHAR(50); DECLARE v_is_reinspection TINYINT DEFAULT 0;
    DECLARE v_rows_affected INT; DECLARE v_requires_qa TINYINT;

    SET p_success=0; SET p_error_code=NULL; SET p_error_message=NULL;

    SELECT Current_Status, Requires_QA_Attention INTO v_from_status, v_requires_qa FROM Bin_Master WHERE Bin_ID=p_bin_id;
    IF v_from_status IS NULL THEN SET p_error_code='BIN_NOT_FOUND'; SET p_error_message='Bin not found'; LEAVE sp_start;
    ELSEIF v_from_status NOT IN('Awaiting_QA','Awaiting_Reinspection') THEN
        SET p_error_code='INVALID_TRANSITION'; SET p_error_message='Bin is not awaiting QA'; LEAVE sp_start;
    END IF;
    IF v_from_status='Awaiting_Reinspection' THEN SET v_is_reinspection=1; END IF;

    CALL sp_validate_workflow_transition(p_bin_id,v_from_status,'QA_In_Progress',p_user_role,p_row_version,
        @_v_p_success,@_v_p_error_code,@_v_p_error_message);
    SELECT @_v_p_success,@_v_p_error_code,@_v_p_error_message INTO p_success,p_error_code,p_error_message;
    IF p_success=0 THEN LEAVE sp_start; END IF;

    INSERT INTO Lock_Table(Bin_ID,Locked_By_User_ID,Operation_Type,Expires_At)
    VALUES(p_bin_id,p_user_id,'START_QA',DATE_ADD(NOW(),INTERVAL 60 MINUTE));

    UPDATE Bin_Master SET Current_Status='QA_In_Progress',Row_Version=Row_Version+1
    WHERE Bin_ID=p_bin_id AND Row_Version=p_row_version;
    SET v_rows_affected=ROW_COUNT();
    IF v_rows_affected=0 THEN
        SET p_error_code='CONCURRENT_MODIFICATION_CONFLICT'; SET p_error_message='Bin modified by another user';
        ROLLBACK; LEAVE sp_start;
    END IF;

    CALL sp_insert_bin_history(p_bin_id,v_from_status,'QA_In_Progress',p_user_id,'START_QA',NULL,NULL,NULL,NULL,
        @_hist_ok,@_hist_ec,@_hist_em);
    CALL sp_insert_audit_log(p_user_id,'START_QA','Bin_Master',p_bin_id,
        CONCAT('"',v_from_status,'"'),CONCAT('"QA_In_Progress"'),NULL,NULL,@_aud_ok,@_aud_ec,@_aud_em);

    SET p_success=1;
    SELECT cr.Cleaning_ID, cr.Cleaning_Method, cr.Cleaning_Agent, cr.Water_Temp_Celsius, cr.Rinse_Cycles,
           cr.Cleaning_Start_At, cr.Comments AS cleaning_comments,
           l.Material_ID, m.Material_Name, l.Batch_Number, l.Quantity_Loaded,
           v_requires_qa AS requires_qa_attention, v_is_reinspection AS is_reinspection
    FROM Cleaning_Record cr
    LEFT JOIN Loading_Record l ON l.Loading_ID=cr.Loading_ID
    LEFT JOIN Material_Master m ON m.Material_ID=l.Material_ID
    WHERE cr.Bin_ID=p_bin_id ORDER BY cr.Cleaning_ID DESC LIMIT 1;
END //

CREATE PROCEDURE sp_complete_qa(
    IN  p_bin_id INT, IN p_user_id INT, IN p_user_role VARCHAR(50),
    IN  p_visual ENUM('Pass','Fail'), IN p_visual_notes VARCHAR(500),
    IN  p_residue ENUM('Pass','Fail'), IN p_residue_notes VARCHAR(500),
    IN  p_damage ENUM('Pass','Fail'), IN p_damage_notes VARCHAR(500),
    IN  p_odor ENUM('Pass','Fail'), IN p_odor_notes VARCHAR(500),
    IN  p_label ENUM('Pass','Fail'), IN p_label_notes VARCHAR(500),
    IN  p_seal ENUM('Pass','Fail'), IN p_seal_notes VARCHAR(500),
    IN  p_overall_result ENUM('PASS','FAIL'), IN p_failure_reason VARCHAR(1000),
    IN  p_row_version INT,
    OUT p_success TINYINT(1), OUT p_error_code VARCHAR(100), OUT p_error_message VARCHAR(500)
)
sp_complete: BEGIN
    DECLARE v_is_reinspection TINYINT DEFAULT 0;
    DECLARE v_fail_count INT DEFAULT 0; DECLARE v_cleaning_id INT; DECLARE v_qa_id INT;
    DECLARE v_rows_affected INT; DECLARE v_final_status VARCHAR(50);

    SET p_success=0; SET p_error_code=NULL; SET p_error_message=NULL;

    -- Validate FAIL requires failure reason
    IF p_overall_result='FAIL' AND (p_failure_reason IS NULL OR CHAR_LENGTH(p_failure_reason)<20) THEN
        SET p_error_code='VALIDATION_ERROR'; SET p_error_message='Failure reason is required (minimum 20 characters)'; LEAVE sp_complete;
    END IF;

    SELECT Cleaning_ID INTO v_cleaning_id FROM Cleaning_Record WHERE Bin_ID=p_bin_id ORDER BY Cleaning_ID DESC LIMIT 1;
    IF v_cleaning_id IS NULL THEN SET p_error_code='NOT_FOUND'; SET p_error_message='No cleaning record found'; LEAVE sp_complete; END IF;

    SELECT EXISTS(SELECT 1 FROM Bin_History WHERE Bin_ID=p_bin_id AND Previous_Status='Reinspection_Cleaning') INTO v_is_reinspection;

    -- Determine final status
    IF p_overall_result='PASS' THEN
        SET v_final_status='Awaiting_Loading';
        -- Auto-transition: QA_In_Progress → QA_Passed → Awaiting_Loading
        -- Validate first transition
        CALL sp_validate_workflow_transition(p_bin_id,'QA_In_Progress','QA_Passed',p_user_role,p_row_version,
            @_v1,@_ec1,@_em1);
        SELECT @_v1 INTO p_success; SELECT @_ec1 INTO p_error_code; SELECT @_em1 INTO p_error_message;
        IF p_success=0 THEN LEAVE sp_complete; END IF;
    ELSE
        SET v_final_status='Reinspection_Cleaning';
        -- Auto-transition: QA_In_Progress → QA_Failed → Reinspection_Cleaning
        CALL sp_validate_workflow_transition(p_bin_id,'QA_In_Progress','QA_Failed',p_user_role,p_row_version,
            @_v1,@_ec1,@_em1);
        SELECT @_v1 INTO p_success; SELECT @_ec1 INTO p_error_code; SELECT @_em1 INTO p_error_message;
        IF p_success=0 THEN LEAVE sp_complete; END IF;
    END IF;

    START TRANSACTION;

    -- Increment fail count for FAIL, reset for PASS
    IF p_overall_result='FAIL' THEN
        SELECT Consecutive_Fail_Count+1 INTO v_fail_count FROM Bin_Master WHERE Bin_ID=p_bin_id;
        IF v_fail_count>=3 THEN
            ROLLBACK; SET p_error_code='ADMIN_REVIEW_REQUIRED'; SET p_error_message='Bin requires Administrator review after 3+ consecutive QA failures'; LEAVE sp_complete;
        END IF;
    ELSE
        SET v_fail_count=0;
    END IF;

    -- Insert QA record
    INSERT INTO QA_Record(Bin_ID,Cleaning_ID,QA_Inspector_User_ID,
        Visual_Inspection,Visual_Notes,Residue_Check,Residue_Notes,
        Damage_Assessment,Damage_Notes,Odor_Check,Odor_Notes,
        Label_Integrity,Label_Notes,Seal_Integrity,Seal_Notes,
        Overall_Result,Failure_Reason,Is_Reinspection,QA_Start_At)
    VALUES(p_bin_id,v_cleaning_id,p_user_id,
        p_visual,p_visual_notes,p_residue,p_residue_notes,
        p_damage,p_damage_notes,p_odor,p_odor_notes,
        p_label,p_label_notes,p_seal,p_seal_notes,
        p_overall_result,p_failure_reason,v_is_reinspection,NOW());
    SET v_qa_id=LAST_INSERT_ID();

    -- Update bin status
    UPDATE Bin_Master SET Current_Status=v_final_status, Row_Version=Row_Version+1,
        Consecutive_Fail_Count=v_fail_count,
        Last_QA_Date=IF(p_overall_result='PASS',NOW(),Last_QA_Date),
        Requires_QA_Attention=0
    WHERE Bin_ID=p_bin_id AND Row_Version=p_row_version;
    SET v_rows_affected=ROW_COUNT();
    IF v_rows_affected=0 THEN ROLLBACK; SET p_error_code='CONCURRENT_MODIFICATION_CONFLICT'; LEAVE sp_complete; END IF;

    -- Release lock, history, audit
    CALL sp_release_lock(p_bin_id,p_user_id,@_lock_ok,@_lock_ec,@_lock_em);
    CALL sp_insert_bin_history(p_bin_id,'QA_In_Progress',v_final_status,p_user_id,'COMPLETE_QA',v_qa_id,'QA_Record',
        IF(p_overall_result='PASS','QA Passed','QA Failed'),NULL,@_hist_ok,@_hist_ec,@_hist_em);
    CALL sp_insert_audit_log(p_user_id,'COMPLETE_QA','Bin_Master',p_bin_id,
        CONCAT('"QA_In_Progress"'),CONCAT('"',v_final_status,'"'),NULL,NULL,@_aud_ok,@_aud_ec,@_aud_em);

    SET p_success=1;
    SELECT v_qa_id AS qa_id, v_final_status AS final_status;
    COMMIT;
END //

DELIMITER ;