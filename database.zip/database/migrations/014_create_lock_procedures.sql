-- Migration 014: sp_acquire_lock + sp_release_lock
DELIMITER //
CREATE PROCEDURE sp_acquire_lock(
    IN  p_bin_id                INT,          IN  p_user_id               INT,
    IN  p_operation_type        VARCHAR(50),  IN  p_lock_duration_minutes INT,
    OUT p_success               TINYINT(1),   OUT p_error_code            VARCHAR(100),
    OUT p_error_message         VARCHAR(500)
)
BEGIN
    DECLARE v_bin_exists TINYINT(1) DEFAULT 0; DECLARE v_existing_lock_id INT;
    DECLARE v_lock_expires DATETIME;           DECLARE v_lock_holder_id INT;
    DECLARE v_lock_holder_name VARCHAR(150);   DECLARE v_new_lock_id INT;
    DECLARE v_expires_at DATETIME;
    SET p_success=0; SET p_error_code=NULL; SET p_error_message=NULL;
    IF p_lock_duration_minutes IS NULL OR p_lock_duration_minutes<=0 THEN SET p_lock_duration_minutes=60; END IF;
    SELECT COUNT(*) INTO v_bin_exists FROM Bin_Master WHERE Bin_ID=p_bin_id;
    IF v_bin_exists=0 THEN SET p_error_code='BIN_NOT_FOUND'; SET p_error_message='Bin not found';
    ELSE START TRANSACTION;
        SELECT l.Lock_ID,l.Expires_At,l.Locked_By_User_ID,u.Full_Name
        INTO v_existing_lock_id,v_lock_expires,v_lock_holder_id,v_lock_holder_name
        FROM Lock_Table l LEFT JOIN User_Master u ON u.User_ID=l.Locked_By_User_ID WHERE l.Bin_ID=p_bin_id;
        IF v_existing_lock_id IS NOT NULL THEN
            IF v_lock_expires<=NOW() THEN DELETE FROM Lock_Table WHERE Lock_ID=v_existing_lock_id;
            ELSEIF v_lock_holder_id=p_user_id THEN SET p_success=1; SELECT v_existing_lock_id AS lock_id,v_lock_expires AS lock_expires_at; COMMIT;
            ELSE SET p_error_code='BIN_OPERATION_IN_PROGRESS'; SET p_error_message=CONCAT('Locked by ',v_lock_holder_name); ROLLBACK; SELECT v_lock_holder_name AS locked_by_name; END IF;
        END IF;
        IF p_success=0 AND p_error_code IS NULL THEN
            SET v_expires_at=DATE_ADD(NOW(),INTERVAL p_lock_duration_minutes MINUTE);
            INSERT INTO Lock_Table(Bin_ID,Locked_By_User_ID,Operation_Type,Expires_At) VALUES(p_bin_id,p_user_id,p_operation_type,v_expires_at);
            SET v_new_lock_id=LAST_INSERT_ID(); SET p_success=1;
            SELECT v_new_lock_id AS lock_id, v_expires_at AS lock_expires_at; COMMIT;
        END IF;
    END IF;
END //

CREATE PROCEDURE sp_release_lock(
    IN  p_bin_id        INT,  IN  p_user_id       INT,
    OUT p_success       TINYINT(1), OUT p_error_code VARCHAR(100), OUT p_error_message VARCHAR(500)
)
BEGIN
    DECLARE v_rows INT DEFAULT 0;
    SET p_success=0; SET p_error_code=NULL; SET p_error_message=NULL;
    START TRANSACTION;
    DELETE FROM Lock_Table WHERE Bin_ID=p_bin_id AND Locked_By_User_ID=p_user_id;
    SET v_rows=ROW_COUNT(); SET p_success=1; SELECT v_rows AS rows_deleted; COMMIT;
END //
DELIMITER ;