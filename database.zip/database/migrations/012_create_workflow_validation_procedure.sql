-- Migration 012: sp_validate_workflow_transition — single gatekeeper
DELIMITER //
CREATE PROCEDURE sp_validate_workflow_transition(
    IN  p_bin_id        INT,          IN  p_from_status   VARCHAR(50),
    IN  p_to_status     VARCHAR(50),  IN  p_user_role     VARCHAR(50),
    IN  p_row_version   INT,
    OUT p_success       TINYINT(1),   OUT p_error_code    VARCHAR(100),
    OUT p_error_message VARCHAR(500)
)
BEGIN
    DECLARE v_is_active TINYINT(1);   DECLARE v_current_status VARCHAR(50);
    DECLARE v_requires_admin TINYINT(1) DEFAULT 0;
    DECLARE v_current_row_version INT;
    DECLARE v_requires_lock TINYINT(1); DECLARE v_operation_type VARCHAR(50);
    DECLARE v_permitted_role VARCHAR(50);
    SET p_success=0; SET p_error_code=NULL; SET p_error_message=NULL;
    SELECT Is_Active,Current_Status,Requires_Admin_Review,Row_Version
    INTO v_is_active,v_current_status,v_requires_admin,v_current_row_version
    FROM Bin_Master WHERE Bin_ID=p_bin_id;
    IF v_current_row_version IS NULL THEN SET p_error_code='BIN_NOT_FOUND'; SET p_error_message='Bin not found';
    ELSEIF v_is_active=0 THEN SET p_error_code='BIN_INACTIVE'; SET p_error_message='Bin is inactive';
    ELSEIF v_current_status='Retired' THEN SET p_error_code='BIN_RETIRED'; SET p_error_message='Bin has been retired';
    ELSEIF v_requires_admin=1 THEN SET p_error_code='ADMIN_REVIEW_REQUIRED'; SET p_error_message='Bin requires Administrator review';
    ELSEIF v_current_row_version<>p_row_version THEN SET p_error_code='CONCURRENT_MODIFICATION_CONFLICT'; SET p_error_message='Bin modified by another user. Re-scan.';
    ELSE
        SELECT Requires_Lock,Operation_Type,Permitted_Role
        INTO v_requires_lock,v_operation_type,v_permitted_role
        FROM Transition_Master
        WHERE From_Status=p_from_status AND To_Status=p_to_status
          AND (Permitted_Role=p_user_role OR Permitted_Role='System');
        IF v_operation_type IS NULL THEN
            IF EXISTS(SELECT 1 FROM Transition_Master WHERE From_Status=p_from_status AND To_Status=p_to_status) THEN
                SET p_error_code='RBAC_FORBIDDEN'; SET p_error_message='Insufficient permissions';
            ELSE SET p_error_code='INVALID_TRANSITION'; SET p_error_message=CONCAT('Invalid transition from ',p_from_status,' to ',p_to_status); END IF;
        ELSE SET p_success=1; SELECT v_requires_lock AS requires_lock, v_operation_type AS operation_type; END IF;
    END IF;
END //
DELIMITER ;