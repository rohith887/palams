-- =============================================================================
-- PBLMS — Migration 003: Authentication Stored Procedures
-- Pharmaceutical Bin Lifecycle Management System
-- =============================================================================
-- Registers the three authentication stored procedures:
--   sp_login          — User lookup with lockout validation
--   sp_refresh_token  — Refresh token validation
--   sp_logout         — Refresh token revocation
-- =============================================================================

-- ---------------------------------------------------------------------------
-- sp_login
-- ---------------------------------------------------------------------------
DELIMITER //

CREATE PROCEDURE sp_login(
    IN  p_username    VARCHAR(50),
    IN  p_ip_address  VARCHAR(45),
    IN  p_user_agent  VARCHAR(500),
    OUT p_success       TINYINT(1),
    OUT p_error_code    VARCHAR(100),
    OUT p_error_message VARCHAR(500)
)
BEGIN
    DECLARE v_user_id        INT;
    DECLARE v_password_hash  VARCHAR(255);
    DECLARE v_full_name      VARCHAR(150);
    DECLARE v_role           VARCHAR(50);
    DECLARE v_is_active      TINYINT(1);
    DECLARE v_failed_count   TINYINT;
    DECLARE v_lockout_until  DATETIME;

    SET p_success = 0;
    SET p_error_code = NULL;
    SET p_error_message = NULL;

    SELECT User_ID, Password_Hash, Full_Name, Role, Is_Active,
           Failed_Login_Count, Lockout_Until
    INTO   v_user_id, v_password_hash, v_full_name, v_role, v_is_active,
           v_failed_count, v_lockout_until
    FROM   User_Master
    WHERE  Username = p_username;

    IF v_user_id IS NULL THEN
        SET p_error_code = 'AUTH_INVALID_CREDENTIALS';
        SET p_error_message = 'Invalid username or password';
    ELSE
        IF v_lockout_until IS NOT NULL AND v_lockout_until > NOW() THEN
            SET p_error_code = 'AUTH_ACCOUNT_LOCKED';
            SET p_error_message = 'Account is locked due to too many failed login attempts';
        ELSE
            SET p_success = 1;
            SELECT v_user_id AS user_id, p_username AS username,
                   v_password_hash AS password_hash, v_full_name AS full_name,
                   v_role AS role, v_is_active AS is_active;
        END IF;
    END IF;
END //

DELIMITER ;

-- ---------------------------------------------------------------------------
-- sp_refresh_token
-- ---------------------------------------------------------------------------
DELIMITER //

CREATE PROCEDURE sp_refresh_token(
    IN  p_token_hash    VARCHAR(255),
    OUT p_success       TINYINT(1),
    OUT p_error_code    VARCHAR(100),
    OUT p_error_message VARCHAR(500)
)
BEGIN
    DECLARE v_user_id   INT;
    DECLARE v_role      VARCHAR(50);
    DECLARE v_full_name VARCHAR(150);

    SET p_success = 0;
    SET p_error_code = NULL;
    SET p_error_message = NULL;

    SELECT rt.User_ID, u.Role, u.Full_Name
    INTO   v_user_id, v_role, v_full_name
    FROM   Refresh_Token rt
           INNER JOIN User_Master u ON u.User_ID = rt.User_ID
    WHERE  rt.Token_Hash = p_token_hash
      AND  rt.Is_Revoked = 0
      AND  rt.Expires_At > NOW();

    IF v_user_id IS NULL THEN
        SET p_error_code = 'AUTH_REFRESH_TOKEN_INVALID';
        SET p_error_message = 'Refresh token is invalid, revoked, or expired';
    ELSE
        SET p_success = 1;
        SELECT v_user_id AS user_id, v_role AS role, v_full_name AS full_name;
    END IF;
END //

DELIMITER ;

-- ---------------------------------------------------------------------------
-- sp_logout
-- ---------------------------------------------------------------------------
DELIMITER //

CREATE PROCEDURE sp_logout(
    IN  p_user_id       INT,
    IN  p_token_hash    VARCHAR(255),
    OUT p_success       TINYINT(1),
    OUT p_error_code    VARCHAR(100),
    OUT p_error_message VARCHAR(500)
)
BEGIN
    SET p_success = 0;
    SET p_error_code = NULL;
    SET p_error_message = NULL;

    UPDATE Refresh_Token
    SET    Is_Revoked = 1
    WHERE  Token_Hash = p_token_hash
      AND  User_ID = p_user_id;

    SET p_success = 1;
END //

DELIMITER ;