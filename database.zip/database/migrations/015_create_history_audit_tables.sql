-- Migration 015: Bin_History + Audit_Log immutable tables
CREATE TABLE IF NOT EXISTS Bin_History (
    History_ID INT AUTO_INCREMENT PRIMARY KEY,
    Bin_ID INT NOT NULL,
    Previous_Status VARCHAR(50) NOT NULL,
    New_Status VARCHAR(50) NOT NULL,
    Acting_User_ID INT NOT NULL,
    Operation_Type VARCHAR(50) NOT NULL,
    Operation_Record_ID INT NULL,
    Operation_Record_Type VARCHAR(30) NULL,
    Remarks VARCHAR(500) NULL,
    Cycle_Number INT NULL,
    Event_Timestamp DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_bin_timestamp (Bin_ID, Event_Timestamp),
    INDEX idx_acting_user (Acting_User_ID),
    CONSTRAINT fk_history_bin FOREIGN KEY (Bin_ID) REFERENCES Bin_Master(Bin_ID) ON DELETE RESTRICT,
    CONSTRAINT fk_history_user FOREIGN KEY (Acting_User_ID) REFERENCES User_Master(User_ID) ON DELETE RESTRICT,
    CONSTRAINT fk_history_prev FOREIGN KEY (Previous_Status) REFERENCES Status_Master(Status_Code) ON DELETE RESTRICT,
    CONSTRAINT fk_history_new  FOREIGN KEY (New_Status) REFERENCES Status_Master(Status_Code) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS Audit_Log (
    Audit_ID INT AUTO_INCREMENT PRIMARY KEY,
    Actor_User_ID INT NULL,
    Action_Type VARCHAR(100) NOT NULL,
    Target_Entity VARCHAR(50) NULL,
    Target_ID INT NULL,
    Old_Value JSON NULL,
    New_Value JSON NULL,
    IP_Address VARCHAR(45) NULL,
    User_Agent VARCHAR(500) NULL,
    Event_Timestamp DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_actor_timestamp (Actor_User_ID, Event_Timestamp),
    INDEX idx_action_type (Action_Type),
    INDEX idx_target (Target_Entity, Target_ID),
    CONSTRAINT fk_audit_actor FOREIGN KEY (Actor_User_ID) REFERENCES User_Master(User_ID) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;