-- =============================================================================
-- PBLMS — Migration 006: Bin_Master Table
-- Pharmaceutical Bin Lifecycle Management System
-- =============================================================================
-- Purpose:
--   Creates the central Bin_Master table — the state record for every
--   physical bin in the system. This table drives all workflow decisions,
--   dashboard counts, and lock management.
--
--   Row_Version enables optimistic concurrency control.
--   Current_Status FK to Status_Master will be added in Phase 4 (migration 010).
--
-- Design Spec Reference: Section 4.2
-- Dependencies: Migration 004 (Bin_Type_Master, Bin_Category_Master, Bay_Master, Tank_Master)
--               Migration 001 (User_Master for Created_By FK)
-- =============================================================================

CREATE TABLE IF NOT EXISTS Bin_Master (
    Bin_ID INT AUTO_INCREMENT PRIMARY KEY,
    Bin_Number VARCHAR(30) NOT NULL,
    QR_Code_Value VARCHAR(200) NOT NULL,
    Bin_Type_ID INT NOT NULL,
    Bin_Category_ID INT NOT NULL,
    Capacity DECIMAL(10, 3) NOT NULL,
    Capacity_Unit VARCHAR(20) NOT NULL,
    Current_Status VARCHAR(50) NOT NULL DEFAULT 'Awaiting_Loading',
    Current_Bay_ID INT NULL,
    Current_Tank_ID INT NULL,
    Is_Active TINYINT(1) NOT NULL DEFAULT 1,
    Requires_Admin_Review TINYINT(1) NOT NULL DEFAULT 0,
    Requires_QA_Attention TINYINT(1) NOT NULL DEFAULT 0,
    Overdue_Unloading TINYINT(1) NOT NULL DEFAULT 0,
    Consecutive_Fail_Count TINYINT NOT NULL DEFAULT 0,
    Last_QA_Date DATETIME NULL,
    Row_Version INT NOT NULL DEFAULT 1,
    Created_At DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    Created_By INT NULL,
    Updated_At DATETIME NULL,

    UNIQUE KEY uq_bin_number (Bin_Number),
    UNIQUE KEY uq_qr_code_value (QR_Code_Value),
    INDEX idx_current_status (Current_Status),
    INDEX idx_current_bay_id (Current_Bay_ID),
    INDEX idx_is_active (Is_Active),
    INDEX idx_requires_admin_review (Requires_Admin_Review),

    CONSTRAINT chk_capacity_positive CHECK (Capacity > 0),
    CONSTRAINT fk_bin_type
        FOREIGN KEY (Bin_Type_ID) REFERENCES Bin_Type_Master(Bin_Type_ID)
        ON DELETE RESTRICT,
    CONSTRAINT fk_bin_category
        FOREIGN KEY (Bin_Category_ID) REFERENCES Bin_Category_Master(Bin_Category_ID)
        ON DELETE RESTRICT,
    CONSTRAINT fk_bin_bay
        FOREIGN KEY (Current_Bay_ID) REFERENCES Bay_Master(Bay_ID)
        ON DELETE RESTRICT,
    CONSTRAINT fk_bin_tank
        FOREIGN KEY (Current_Tank_ID) REFERENCES Tank_Master(Tank_ID)
        ON DELETE RESTRICT,
    CONSTRAINT fk_bin_created_by
        FOREIGN KEY (Created_By) REFERENCES User_Master(User_ID)
        ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;