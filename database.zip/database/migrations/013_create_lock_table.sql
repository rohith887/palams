-- Migration 013: Lock_Table for concurrent bin operation exclusion
CREATE TABLE IF NOT EXISTS Lock_Table (
    Lock_ID INT AUTO_INCREMENT PRIMARY KEY,
    Bin_ID INT NOT NULL,
    Locked_By_User_ID INT NOT NULL,
    Lock_Timestamp DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    Operation_Type VARCHAR(50) NOT NULL,
    Expires_At DATETIME NOT NULL,
    UNIQUE KEY uq_bin_lock (Bin_ID),
    INDEX idx_expires_at (Expires_At),
    INDEX idx_locked_by (Locked_By_User_ID),
    CONSTRAINT fk_lock_bin
        FOREIGN KEY (Bin_ID) REFERENCES Bin_Master(Bin_ID)
        ON DELETE RESTRICT,
    CONSTRAINT fk_lock_user
        FOREIGN KEY (Locked_By_User_ID) REFERENCES User_Master(User_ID)
        ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;