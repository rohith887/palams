-- =============================================================================
-- PBLMS — Migration 019: Unloading_Record Transaction Table
-- Pharmaceutical Bin Lifecycle Management System
-- =============================================================================
-- Design Spec Reference: Section 4.3
-- Dependencies:
--   Migration 006 (Bin_Master)
--   Migration 001 (User_Master)
--   Migration 017 (Loading_Record)
-- =============================================================================

CREATE TABLE IF NOT EXISTS Unloading_Record (
    Unloading_ID INT AUTO_INCREMENT PRIMARY KEY,
    Bin_ID INT NOT NULL,
    Loading_ID INT NOT NULL,
    Unloader_User_ID INT NOT NULL,
    Quantity_Unloaded DECIMAL(10, 3) NOT NULL,
    Unloading_Condition ENUM('Normal', 'Damaged', 'Contamination_Suspected') NOT NULL DEFAULT 'Normal',
    Unloading_Start_At DATETIME NOT NULL,
    Unloading_Completed_At DATETIME NULL,
    Comments VARCHAR(500) NULL,

    INDEX idx_bin_id (Bin_ID),
    INDEX idx_loading_id (Loading_ID),
    INDEX idx_unloader_user (Unloader_User_ID),

    CONSTRAINT chk_quantity_unloaded_positive CHECK (Quantity_Unloaded > 0),

    CONSTRAINT fk_unloading_bin
        FOREIGN KEY (Bin_ID) REFERENCES Bin_Master(Bin_ID)
        ON DELETE RESTRICT,
    CONSTRAINT fk_unloading_loading
        FOREIGN KEY (Loading_ID) REFERENCES Loading_Record(Loading_ID)
        ON DELETE RESTRICT,
    CONSTRAINT fk_unloading_unloader
        FOREIGN KEY (Unloader_User_ID) REFERENCES User_Master(User_ID)
        ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;