-- =============================================================================
-- PBLMS — Migration 009: User Management Stored Procedure (INSERTED AFTER 008)
-- =============================================================================
-- Purpose:
--   Creates sp_manage_user — a single stored procedure handling CREATE and
--   UPDATE actions on User_Master.  Passwords received from the service layer
--   are already bcrypt-hashed; no hashing occurs in MySQL.
--
--   Role changes are recorded in Audit_Log as specified by the design.
--
-- Design Spec Reference: Section 9.5 (sp_manage_user)
-- Tasks Reference: PBLMS-3-04
-- Dependencies: Migration 001 (User_Master), Migration 015 (Audit_Log — runtime only)
--
-- Note: This migration is numbered 009 even though it is being applied after
--       later-numbered migrations.  It fits logically between 008 (bin
--       registration) and 010 (workflow tables).  No renumbering of existing
--       migrations is required.
-- =============================================================================

DELIMITER //

CREATE PROCEDURE sp_manage_user(
    IN  p_admin_user_id    INT,
    IN  p_action           VARCHAR(10),    -- 'CREATE' or 'UPDATE'
    IN  p_target_user_id   INT,            -- required for UPDATE; NULL for CREATE
    IN  p_username         VARCHAR(50),    -- required for CREATE
    IN  p_password_hash    VARCHAR(255),   -- bcrypt hash from service layer; required for CREATE
    IN  p_full_name        VARCHAR(150),   -- required
    IN  p_role             VARCHAR(20),    -- required; validated against User_Master.Role enum
    IN  p_is_active        TINYINT(1),     -- only used on UPDATE; NULL means "no change"
    OUT p_success          TINYINT(1),
    OUT p_error_code       VARCHAR(100),
    OUT p_error_message    VARCHAR(500)
)
sp_mu_label: BEGIN
    DECLARE v_old_role VARCHAR(20);

    SET p_success = 0;
    SET p_error_code = NULL;
    SET p_error_message = NULL;

    -- Validate action
    IF p_action NOT IN ('CREATE', 'UPDATE') THEN
        SET p_error_code = 'VALIDATION_ERROR';
        SET p_error_message = 'Action must be CREATE or UPDATE';
        LEAVE sp_mu_label;
    END IF;

    -- CREATE
    IF p_action = 'CREATE' THEN
        IF p_username IS NULL OR p_password_hash IS NULL OR p_full_name IS NULL OR p_role IS NULL THEN
            SET p_error_code = 'VALIDATION_ERROR';
            SET p_error_message = 'Username, password, full name, and role are required';
            LEAVE sp_mu_label;
        END IF;

        IF p_role NOT IN ('Administrator', 'Loader', 'Unloader', 'Cleaner', 'QA_Inspector') THEN
            SET p_error_code = 'VALIDATION_ERROR';
            SET p_error_message = 'Invalid role. Must be Administrator, Loader, Unloader, Cleaner, or QA_Inspector';
            LEAVE sp_mu_label;
        END IF;

        IF EXISTS (SELECT 1 FROM User_Master WHERE Username = p_username) THEN
            SET p_error_code = 'DUPLICATE_ENTRY';
            SET p_error_message = CONCAT('Username "', p_username, '" already exists');
            LEAVE sp_mu_label;
        END IF;

        INSERT INTO User_Master (Username, Password_Hash, Full_Name, Role, Created_By)
        VALUES (p_username, p_password_hash, p_full_name, p_role, p_admin_user_id);

        SET p_success = 1;
        SELECT LAST_INSERT_ID() AS user_id;
        LEAVE sp_mu_label;
    END IF;

    -- UPDATE
    IF p_action = 'UPDATE' THEN
        IF p_target_user_id IS NULL OR NOT EXISTS (SELECT 1 FROM User_Master WHERE User_ID = p_target_user_id) THEN
            SET p_error_code = 'NOT_FOUND';
            SET p_error_message = 'User not found';
            LEAVE sp_mu_label;
        END IF;

        SELECT Role INTO v_old_role FROM User_Master WHERE User_ID = p_target_user_id;

        IF p_full_name IS NOT NULL THEN
            UPDATE User_Master SET Full_Name = p_full_name, Updated_At = NOW(), Updated_By = p_admin_user_id
            WHERE User_ID = p_target_user_id;
        END IF;

        IF p_role IS NOT NULL AND p_role != '' THEN
            IF p_role NOT IN ('Administrator', 'Loader', 'Unloader', 'Cleaner', 'QA_Inspector') THEN
                SET p_error_code = 'VALIDATION_ERROR';
                SET p_error_message = 'Invalid role. Must be Administrator, Loader, Unloader, Cleaner, or QA_Inspector';
                LEAVE sp_mu_label;
            END IF;

            UPDATE User_Master SET Role = p_role, Updated_At = NOW(), Updated_By = p_admin_user_id
            WHERE User_ID = p_target_user_id;

            IF v_old_role != p_role THEN
                INSERT INTO Audit_Log (Actor_User_ID, Action_Type, Target_Entity, Target_ID,
                    Old_Value, New_Value)
                VALUES (p_admin_user_id, 'ROLE_CHANGED', 'User_Master', p_target_user_id,
                    CONCAT('{"role":"', v_old_role, '"}'),
                    CONCAT('{"role":"', p_role, '"'));
            END IF;
        END IF;

        IF p_is_active IS NOT NULL THEN
            UPDATE User_Master SET Is_Active = p_is_active, Updated_At = NOW(), Updated_By = p_admin_user_id
            WHERE User_ID = p_target_user_id;
        END IF;

        SET p_success = 1;
        LEAVE sp_mu_label;
    END IF;

END //

DELIMITER ;