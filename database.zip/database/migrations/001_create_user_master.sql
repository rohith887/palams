-- =============================================================================
-- PBLMS — Migration 001: User_Master and Refresh_Token Tables
-- Pharmaceutical Bin Lifecycle Management System
-- =============================================================================
-- Purpose:
--   Creates the User_Master and Refresh_Token tables required for
--   authentication, session management, and account lockout.
--
-- Tables:
--   User_Master    — Central identity and credential store for all users
--   Refresh_Token  — Server-side refresh token storage with revocation support
--
-- Indexes:
--   UNIQUE on User_Master.Username
--   UNIQUE on Refresh_Token.Token_Hash
--   COMPOSITE on Refresh_Token(User_ID, Is_Revoked)
--
-- Foreign Keys:
--   User_Master.Created_By → User_Master.User_ID (self-referencing, NULL for bootstrap admin)
--   User_Master.Updated_By → User_Master.User_ID (NULL)
--   Refresh_Token.User_ID → User_Master.User_ID
--
-- Dependencies: None (User_Master is a foundational table)
-- Design Spec Reference: Sections 4.2, 4.4
-- =============================================================================

-- ---------------------------------------------------------------------------
-- User_Master — Central user identity table
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS User_Master (
    User_ID INT AUTO_INCREMENT PRIMARY KEY,
    Username VARCHAR(50) NOT NULL,
    Password_Hash VARCHAR(255) NOT NULL,
    Full_Name VARCHAR(150) NOT NULL,
    Role ENUM('Administrator', 'Loader', 'Unloader', 'Cleaner', 'QA_Inspector') NOT NULL,
    Is_Active TINYINT(1) NOT NULL DEFAULT 1,
    Failed_Login_Count TINYINT NOT NULL DEFAULT 0,
    Lockout_Until DATETIME NULL,
    Last_Login_At DATETIME NULL,
    Created_At DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    Created_By INT NULL,
    Updated_At DATETIME NULL,
    Updated_By INT NULL,

    UNIQUE KEY uq_username (Username),
    INDEX idx_role (Role),
    INDEX idx_is_active (Is_Active)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------------
-- Refresh_Token — Server-side refresh token management
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS Refresh_Token (
    Token_ID INT AUTO_INCREMENT PRIMARY KEY,
    User_ID INT NOT NULL,
    Token_Hash VARCHAR(255) NOT NULL,
    Issued_At DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    Expires_At DATETIME NOT NULL,
    Is_Revoked TINYINT(1) NOT NULL DEFAULT 0,
    Device_Info VARCHAR(500) NULL,

    UNIQUE KEY uq_token_hash (Token_Hash),
    INDEX idx_user_revoked (User_ID, Is_Revoked),
    INDEX idx_expires_at (Expires_At),
    CONSTRAINT fk_refresh_token_user
        FOREIGN KEY (User_ID) REFERENCES User_Master(User_ID)
        ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------------
-- Self-referencing foreign keys for audit columns
-- Added via ALTER TABLE after User_Master is created
-- ---------------------------------------------------------------------------
ALTER TABLE User_Master
    ADD CONSTRAINT fk_user_created_by
        FOREIGN KEY (Created_By) REFERENCES User_Master(User_ID)
        ON DELETE SET NULL,
    ADD CONSTRAINT fk_user_updated_by
        FOREIGN KEY (Updated_By) REFERENCES User_Master(User_ID)
        ON DELETE SET NULL;