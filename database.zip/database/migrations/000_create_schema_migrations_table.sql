-- =============================================================================
-- PBLMS — Migration 000: Schema_Migrations Tracking Table
-- Pharmaceutical Bin Lifecycle Management System
-- =============================================================================
-- Purpose:
--   Creates the Schema_Migrations table that tracks which migration files
--   have been applied to the database. The db-migrate.sh script checks this
--   table before applying any migration to prevent duplicate execution.
--
-- Table:
--   Schema_Migrations
--     migration_id  — Sequential primary key
--     filename      — Migration file name (e.g., '001_create_user_master.sql')
--     applied_at    — Timestamp when the migration was applied
--
-- Dependencies: None (this is the first migration applied)
-- =============================================================================

CREATE TABLE IF NOT EXISTS Schema_Migrations (
    migration_id INT AUTO_INCREMENT PRIMARY KEY,
    filename VARCHAR(200) NOT NULL,
    applied_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uq_filename (filename)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;