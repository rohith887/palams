-- Migration 011: Seed all 13 lifecycle statuses and 15 workflow transitions
-- Statuses (design spec section 6.1)
INSERT INTO Status_Master (Status_Code, Status_Label, Display_Order, Is_Terminal, Description) VALUES
('Awaiting_Loading',       'Awaiting Loading',        1,  0, 'Bin ready for loading operation'),
('Loading_In_Progress',    'Loading In Progress',     2,  0, 'Loader actively filling the bin'),
('Awaiting_Unloading',     'Awaiting Unloading',      3,  0, 'Bin loaded, awaiting unloading'),
('Unloading_In_Progress',  'Unloading In Progress',   4,  0, 'Unloader actively emptying the bin'),
('Awaiting_Cleaning',      'Awaiting Cleaning',       5,  0, 'Bin emptied, needs cleaning'),
('Cleaning_In_Progress',   'Cleaning In Progress',    6,  0, 'Cleaner actively cleaning the bin'),
('Awaiting_QA',            'Awaiting QA',             7,  0, 'Bin cleaned, awaiting QA inspection'),
('QA_In_Progress',         'QA In Progress',          8,  0, 'QA Inspector evaluating the bin'),
('QA_Passed',              'QA Passed',               9,  0, 'Bin passed QA inspection'),
('QA_Failed',              'QA Failed',               10, 0, 'Bin failed QA inspection'),
('Reinspection_Cleaning',  'Reinspection Cleaning',   11, 0, 'Bin needs re-cleaning after QA failure'),
('Awaiting_Reinspection',  'Awaiting Reinspection',   12, 0, 'Bin re-cleaned, awaiting re-inspection'),
('Retired',                'Retired',                 13, 1, 'Bin permanently retired from service');

-- 15 transitions (design spec table 5.2)
INSERT INTO Transition_Master (From_Status, To_Status, Permitted_Role, Operation_Type, Requires_Lock, Description) VALUES
('Awaiting_Loading',       'Loading_In_Progress',   'Loader',         'START_LOADING',       1, 'Loader starts loading'),
('Loading_In_Progress',    'Awaiting_Unloading',    'Loader',         'COMPLETE_LOADING',    1, 'Loader completes loading'),
('Awaiting_Unloading',     'Unloading_In_Progress',  'Unloader',       'START_UNLOADING',     1, 'Unloader starts unloading'),
('Unloading_In_Progress',  'Awaiting_Cleaning',     'Unloader',       'COMPLETE_UNLOADING',  1, 'Unloader completes unloading'),
('Awaiting_Cleaning',      'Cleaning_In_Progress',  'Cleaner',        'START_CLEANING',      1, 'Cleaner starts cleaning'),
('Cleaning_In_Progress',   'Awaiting_QA',           'Cleaner',        'COMPLETE_CLEANING',   1, 'Cleaner completes cleaning'),
('Awaiting_QA',            'QA_In_Progress',        'QA_Inspector',   'START_QA',            1, 'QA Inspector starts inspection'),
('QA_In_Progress',         'QA_Passed',             'QA_Inspector',   'COMPLETE_QA_PASS',    1, 'QA Inspector marks PASS'),
('QA_Passed',              'Awaiting_Loading',      'System',         'CYCLE_RESET',         0, 'Auto: bin returns to loading pool'),
('QA_In_Progress',         'QA_Failed',             'QA_Inspector',   'COMPLETE_QA_FAIL',    1, 'QA Inspector marks FAIL'),
('QA_Failed',              'Reinspection_Cleaning', 'System',         'REINSPECTION_TRIGGER',0, 'Auto: bin sent for re-cleaning'),
('Reinspection_Cleaning',  'Cleaning_In_Progress',  'Cleaner',        'START_CLEANING',      1, 'Cleaner starts reinspection cleaning'),
('Awaiting_Reinspection',  'QA_In_Progress',        'QA_Inspector',   'START_QA',            1, 'QA Inspector starts re-inspection'),
('Awaiting_Loading',       'Retired',               'Administrator',  'RETIRE_BIN',          0, 'Administrator retires bin'),
('Any',                    'Any',                   'Administrator',  'ADMIN_LOCK_RELEASE',  0, 'Administrator forcibly releases lock');