-- =============================================================================
-- PBLMS — Migration 017: Loading_Record Transaction Table
-- Pharmaceutical Bin Lifecycle Management System
-- =============================================================================
-- Design Spec Reference: Section 4.3
-- Dependencies:
--   Migration 006 (Bin_Master)
--   Migration 001 (User_Master)
--   Migration 004 (Bay_Master, Tank_Master, Material_Master)
-- =============================================================================

CREATE TABLE IF NOT EXISTS Loading_Record (
    Loading_ID INT AUTO_INCREMENT PRIMARY KEY,
    Bin_ID INT NOT NULL,
    Loader_User_ID INT NOT NULL,
    Bay_ID INT NOT NULL,
    Tank_ID INT NOT NULL,
    Material_ID INT NOT NULL,
    Quantity_Loaded DECIMAL(10, 3) NOT NULL,
    Unit_Of_Measure VARCHAR(20) NOT NULL,
    Batch_Number VARCHAR(100) NOT NULL,
    Expected_Unloading_Date DATE NOT NULL,
    Loading_Start_At DATETIME NOT NULL,
    Loading_Completed_At DATETIME NULL,
    Comments VARCHAR(500) NULL,
    Is_Current TINYINT(1) NOT NULL DEFAULT 1,

    INDEX idx_bin_id (Bin_ID),
    INDEX idx_loader_user (Loader_User_ID),
    INDEX idx_expected_unloading (Expected_Unloading_Date, Is_Current),
    INDEX idx_material (Material_ID),

    CONSTRAINT chk_quantity_positive CHECK (Quantity_Loaded > 0),

    CONSTRAINT fk_loading_bin
        FOREIGN KEY (Bin_ID) REFERENCES Bin_Master(Bin_ID)
        ON DELETE RESTRICT,
    CONSTRAINT fk_loading_loader
        FOREIGN KEY (Loader_User_ID) REFERENCES User_Master(User_ID)
        ON DELETE RESTRICT,
    CONSTRAINT fk_loading_bay
        FOREIGN KEY (Bay_ID) REFERENCES Bay_Master(Bay_ID)
        ON DELETE RESTRICT,
    CONSTRAINT fk_loading_tank
        FOREIGN KEY (Tank_ID) REFERENCES Tank_Master(Tank_ID)
        ON DELETE RESTRICT,
    CONSTRAINT fk_loading_material
        FOREIGN KEY (Material_ID) REFERENCES Material_Master(Material_ID)
        ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;