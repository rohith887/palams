-- PBLMS — Migration 026: sp_generate_report
DELIMITER //

CREATE PROCEDURE sp_generate_report(
    IN  p_report_type   VARCHAR(50),
    IN  p_from_date     DATE,
    IN  p_to_date       DATE,
    IN  p_bin_number    VARCHAR(30),
    IN  p_operator_id   INT,
    IN  p_bay_id        INT,
    IN  p_material_id   INT,
    IN  p_page          INT,
    IN  p_page_size     INT,
    OUT p_success       TINYINT(1),
    OUT p_error_code    VARCHAR(100),
    OUT p_error_message VARCHAR(500)
)
sp_main: BEGIN
    DECLARE v_offset INT DEFAULT 0;
    SET p_success=0; SET p_error_code=NULL; SET p_error_message=NULL;

    -- Validate page size
    IF p_page_size NOT IN(25,50,100) THEN SET p_page_size=25; END IF;
    IF p_page IS NULL OR p_page<1 THEN SET p_page=1; END IF;
    SET v_offset = (p_page-1) * p_page_size;

    -- Default date range: current month if both NULL
    IF p_from_date IS NULL AND p_to_date IS NULL THEN
        SET p_from_date = DATE_FORMAT(CURDATE(), '%Y-%m-01');
        SET p_to_date = CURDATE();
    END IF;

    -- Route to appropriate view based on report type
    IF p_report_type='loading' THEN
        SELECT COUNT(*) INTO @total FROM vw_rpt_loading
        WHERE (p_from_date IS NULL OR Loading_Start_At >= p_from_date)
          AND (p_to_date IS NULL OR Loading_Start_At <= p_to_date)
          AND (p_bin_number IS NULL OR Bin_Number = p_bin_number)
          AND (p_operator_id IS NULL OR Loader_User_ID = p_operator_id)
          AND (p_bay_id IS NULL OR Bay_ID = p_bay_id)
          AND (p_material_id IS NULL OR Material_ID = p_material_id);
        SELECT *, @total AS total_count FROM vw_rpt_loading
        WHERE (p_from_date IS NULL OR Loading_Start_At >= p_from_date)
          AND (p_to_date IS NULL OR Loading_Start_At <= p_to_date)
          AND (p_bin_number IS NULL OR Bin_Number = p_bin_number)
          AND (p_operator_id IS NULL OR Loader_User_ID = p_operator_id)
          AND (p_bay_id IS NULL OR Bay_ID = p_bay_id)
          AND (p_material_id IS NULL OR Material_ID = p_material_id)
        ORDER BY Loading_Start_At DESC LIMIT p_page_size OFFSET v_offset;

    ELSEIF p_report_type='unloading' THEN
        SELECT COUNT(*) INTO @total FROM vw_rpt_unloading
        WHERE (p_from_date IS NULL OR Unloading_Start_At >= p_from_date)
          AND (p_to_date IS NULL OR Unloading_Start_At <= p_to_date)
          AND (p_bin_number IS NULL OR Bin_Number = p_bin_number)
          AND (p_operator_id IS NULL OR Unloader_User_ID = p_operator_id);
        SELECT *, @total AS total_count FROM vw_rpt_unloading
        WHERE (p_from_date IS NULL OR Unloading_Start_At >= p_from_date)
          AND (p_to_date IS NULL OR Unloading_Start_At <= p_to_date)
          AND (p_bin_number IS NULL OR Bin_Number = p_bin_number)
          AND (p_operator_id IS NULL OR Unloader_User_ID = p_operator_id)
        ORDER BY Unloading_Start_At DESC LIMIT p_page_size OFFSET v_offset;

    ELSEIF p_report_type='cleaning' THEN
        SELECT COUNT(*) INTO @total FROM vw_rpt_cleaning
        WHERE (p_from_date IS NULL OR Cleaning_Start_At >= p_from_date)
          AND (p_to_date IS NULL OR Cleaning_Start_At <= p_to_date)
          AND (p_bin_number IS NULL OR Bin_Number = p_bin_number)
          AND (p_operator_id IS NULL OR Cleaner_User_ID = p_operator_id);
        SELECT *, @total AS total_count FROM vw_rpt_cleaning
        WHERE (p_from_date IS NULL OR Cleaning_Start_At >= p_from_date)
          AND (p_to_date IS NULL OR Cleaning_Start_At <= p_to_date)
          AND (p_bin_number IS NULL OR Bin_Number = p_bin_number)
          AND (p_operator_id IS NULL OR Cleaner_User_ID = p_operator_id)
        ORDER BY Cleaning_Start_At DESC LIMIT p_page_size OFFSET v_offset;

    ELSEIF p_report_type='qa' THEN
        SELECT COUNT(*) INTO @total FROM vw_rpt_qa
        WHERE (p_from_date IS NULL OR QA_Start_At >= p_from_date)
          AND (p_to_date IS NULL OR QA_Start_At <= p_to_date)
          AND (p_bin_number IS NULL OR Bin_Number = p_bin_number)
          AND (p_operator_id IS NULL OR QA_Inspector_User_ID = p_operator_id);
        SELECT *, @total AS total_count FROM vw_rpt_qa
        WHERE (p_from_date IS NULL OR QA_Start_At >= p_from_date)
          AND (p_to_date IS NULL OR QA_Start_At <= p_to_date)
          AND (p_bin_number IS NULL OR Bin_Number = p_bin_number)
          AND (p_operator_id IS NULL OR QA_Inspector_User_ID = p_operator_id)
        ORDER BY QA_Start_At DESC LIMIT p_page_size OFFSET v_offset;

    ELSEIF p_report_type='rejected-bin' THEN
        SELECT *, COUNT(*) OVER() AS total_count FROM vw_rpt_rejected_bin
        ORDER BY Rejection_Date DESC LIMIT p_page_size OFFSET v_offset;

    ELSEIF p_report_type='bin-lifecycle' THEN
        SELECT COUNT(*) INTO @total FROM vw_rpt_lifecycle
        WHERE p_bin_number IS NULL OR Bin_Number = p_bin_number;
        SELECT *, @total AS total_count FROM vw_rpt_lifecycle
        WHERE p_bin_number IS NULL OR Bin_Number = p_bin_number
        ORDER BY Cycle_End_At DESC LIMIT p_page_size OFFSET v_offset;

    ELSEIF p_report_type='user-activity' THEN
        SELECT *, COUNT(*) OVER() AS total_count FROM vw_rpt_user_activity
        WHERE (p_operator_id IS NULL OR User_ID = p_operator_id)
        ORDER BY User_ID LIMIT p_page_size OFFSET v_offset;

    ELSEIF p_report_type='audit-trail' THEN
        SELECT COUNT(*) INTO @total FROM vw_rpt_audit_trail
        WHERE (p_from_date IS NULL OR Event_Timestamp >= p_from_date)
          AND (p_to_date IS NULL OR Event_Timestamp <= p_to_date)
          AND (p_operator_id IS NULL OR Actor_User_ID = p_operator_id);
        SELECT *, @total AS total_count FROM vw_rpt_audit_trail
        WHERE (p_from_date IS NULL OR Event_Timestamp >= p_from_date)
          AND (p_to_date IS NULL OR Event_Timestamp <= p_to_date)
          AND (p_operator_id IS NULL OR Actor_User_ID = p_operator_id)
        ORDER BY Event_Timestamp DESC LIMIT p_page_size OFFSET v_offset;

    ELSE
        SET p_error_code='VALIDATION_ERROR';
        SET p_error_message=CONCAT('Unknown report type: ', p_report_type);
        LEAVE sp_main;
    END IF;

    SET p_success=1;
END sp_main; //
DELIMITER ;