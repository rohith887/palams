-- =============================================================================
-- PBLMS — Migration 021: Cleaning_Record Table + sp_start_cleaning + sp_complete_cleaning
-- =============================================================================
CREATE TABLE IF NOT EXISTS Cleaning_Record (
    Cleaning_ID INT AUTO_INCREMENT PRIMARY KEY,
    Bin_ID INT NOT NULL,
    Loading_ID INT NOT NULL,
    Cleaner_User_ID INT NOT NULL,
    Cleaning_Method ENUM('Rinse', 'Chemical_Wash', 'Steam_Clean') NOT NULL,
    Cleaning_Agent VARCHAR(100) NOT NULL,
    Water_Temp_Celsius DECIMAL(5,2) NOT NULL,
    Rinse_Cycles TINYINT NOT NULL DEFAULT 1,
    Is_Reinspection_Cycle TINYINT(1) NOT NULL DEFAULT 0,
    Cleaning_Start_At DATETIME NOT NULL,
    Cleaning_Completed_At DATETIME NULL,
    Comments VARCHAR(500) NULL,
    INDEX idx_bin_id (Bin_ID), INDEX idx_loading_id (Loading_ID),
    CONSTRAINT chk_water_temp CHECK (Water_Temp_Celsius BETWEEN 0 AND 100),
    CONSTRAINT chk_rinse_cycles CHECK (Rinse_Cycles >= 1),
    CONSTRAINT fk_cleaning_bin FOREIGN KEY (Bin_ID) REFERENCES Bin_Master(Bin_ID) ON DELETE RESTRICT,
    CONSTRAINT fk_cleaning_loading FOREIGN KEY (Loading_ID) REFERENCES Loading_Record(Loading_ID) ON DELETE RESTRICT,
    CONSTRAINT fk_cleaning_cleaner FOREIGN KEY (Cleaner_User_ID) REFERENCES User_Master(User_ID) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DELIMITER //

CREATE PROCEDURE sp_start_cleaning(
    IN  p_bin_id INT, IN p_user_id INT, IN p_user_role VARCHAR(50), IN p_row_version INT,
    OUT p_success TINYINT(1), OUT p_error_code VARCHAR(100), OUT p_error_message VARCHAR(500)
)
sp_start: BEGIN
    DECLARE v_from_status VARCHAR(50); DECLARE v_is_reinspection TINYINT DEFAULT 0;
    DECLARE v_lock_id INT; DECLARE v_rows_affected INT;

    SET p_success=0; SET p_error_code=NULL; SET p_error_message=NULL;

    -- Determine current status
    SELECT Current_Status INTO v_from_status FROM Bin_Master WHERE Bin_ID=p_bin_id;

    -- Validate bin is in a valid starting state
    IF v_from_status IS NULL THEN
        SET p_error_code='BIN_NOT_FOUND'; SET p_error_message='Bin not found'; LEAVE sp_start;
    ELSEIF v_from_status NOT IN('Awaiting_Cleaning','Reinspection_Cleaning') THEN
        SET p_error_code='INVALID_TRANSITION';
        SET p_error_message='Bin is not awaiting cleaning';
        LEAVE sp_start;
    END IF;

    IF v_from_status='Reinspection_Cleaning' THEN SET v_is_reinspection=1; END IF;

    -- Validate transition via session variables (OUT params require @)
    CALL sp_validate_workflow_transition(p_bin_id, v_from_status, 'Cleaning_In_Progress', p_user_role, p_row_version,
        @_v_p_success, @_v_p_error_code, @_v_p_error_message);
    SELECT @_v_p_success, @_v_p_error_code, @_v_p_error_message INTO p_success, p_error_code, p_error_message;
    IF p_success=0 THEN LEAVE sp_start; END IF;

    -- Acquire lock
    INSERT INTO Lock_Table (Bin_ID, Locked_By_User_ID, Operation_Type, Expires_At)
    VALUES (p_bin_id, p_user_id, 'START_CLEANING', DATE_ADD(NOW(), INTERVAL 60 MINUTE));

    -- Update bin status with optimistic locking
    UPDATE Bin_Master SET Current_Status='Cleaning_In_Progress', Row_Version=Row_Version+1
    WHERE Bin_ID=p_bin_id AND Row_Version=p_row_version;
    SET v_rows_affected=ROW_COUNT();
    IF v_rows_affected=0 THEN
        SET p_error_code='CONCURRENT_MODIFICATION_CONFLICT'; SET p_error_message='Bin modified by another user';
        ROLLBACK; LEAVE sp_start;
    END IF;

    -- Insert history and audit using session variables for OUT params
    CALL sp_insert_bin_history(p_bin_id, v_from_status, 'Cleaning_In_Progress', p_user_id,
        'START_CLEANING', NULL, NULL, NULL, NULL,
        @_hist_ok, @_hist_ec, @_hist_em);
    CALL sp_insert_audit_log(p_user_id, 'START_CLEANING', 'Bin_Master', p_bin_id,
        CONCAT('"', v_from_status, '"'), CONCAT('"Cleaning_In_Progress"'),
        NULL, NULL, @_aud_ok, @_aud_ec, @_aud_em);

    SET p_success=1;

    -- Return cleaning context from most recent loading record
    SELECT l.Loading_ID AS loading_id, l.Material_ID AS material_id, m.Material_Name,
           l.Batch_Number AS batch_number, l.Quantity_Loaded AS quantity_loaded,
           l.Loading_Start_At AS loading_start_at, l.Loading_Completed_At AS loading_completed_at,
           l.Comments AS loading_comments,
           un.Unloading_Condition AS unloading_condition, un.Comments AS unloading_comments,
           v_is_reinspection AS is_reinspection
    FROM Loading_Record l
    LEFT JOIN Material_Master m ON m.Material_ID=l.Material_ID
    LEFT JOIN Unloading_Record un ON un.Bin_ID=l.Bin_ID AND un.Loading_ID=l.Loading_ID
    WHERE l.Bin_ID=p_bin_id AND l.Is_Current=1
    ORDER BY l.Loading_ID DESC LIMIT 1;

END //

CREATE PROCEDURE sp_complete_cleaning(
    IN  p_bin_id INT, IN p_user_id INT, IN p_user_role VARCHAR(50),
    IN  p_method VARCHAR(20), IN p_agent VARCHAR(100), IN p_water_temp DECIMAL(5,2),
    IN  p_rinse_cycles INT, IN p_comments VARCHAR(500), IN p_row_version INT,
    OUT p_success TINYINT(1), OUT p_error_code VARCHAR(100), OUT p_error_message VARCHAR(500)
)
sp_complete: BEGIN
    DECLARE v_from_status VARCHAR(50); DECLARE v_to_status VARCHAR(50);
    DECLARE v_loading_id INT; DECLARE v_is_reinspection TINYINT DEFAULT 0;
    DECLARE v_cleaning_id INT; DECLARE v_rows_affected INT;

    SET p_success=0; SET p_error_code=NULL; SET p_error_message=NULL;

    -- Determine current status
    SELECT Current_Status INTO v_from_status FROM Bin_Master WHERE Bin_ID=p_bin_id;
    IF v_from_status IS NULL THEN
        SET p_error_code='BIN_NOT_FOUND'; SET p_error_message='Bin not found'; LEAVE sp_complete;
    END IF;

    -- Get active loading record
    SELECT Loading_ID INTO v_loading_id FROM Loading_Record
    WHERE Bin_ID=p_bin_id AND Is_Current=1 ORDER BY Loading_ID DESC LIMIT 1;
    IF v_loading_id IS NULL THEN
        SET p_error_code='NOT_FOUND'; SET p_error_message='No active loading record found'; LEAVE sp_complete;
    END IF;

    -- Determine if this is a reinspection cycle
    SET v_is_reinspection = EXISTS(
        SELECT 1 FROM Bin_History WHERE Bin_ID=p_bin_id AND Previous_Status='Reinspection_Cleaning'
    );

    -- Determine next status
    SET v_to_status = IF(v_is_reinspection, 'Awaiting_Reinspection', 'Awaiting_QA');

    -- Validate inputs
    IF p_method NOT IN('Rinse','Chemical_Wash','Steam_Clean') THEN
        SET p_error_code='VALIDATION_ERROR'; SET p_error_message='Invalid cleaning method'; LEAVE sp_complete;
    END IF;
    IF p_water_temp<0 OR p_water_temp>100 THEN
        SET p_error_code='VALIDATION_ERROR'; SET p_error_message='Water temperature must be 0-100°C'; LEAVE sp_complete;
    END IF;
    IF p_rinse_cycles<1 THEN
        SET p_error_code='VALIDATION_ERROR'; SET p_error_message='At least 1 rinse cycle required'; LEAVE sp_complete;
    END IF;

    START TRANSACTION;

    -- Validate transition
    CALL sp_validate_workflow_transition(p_bin_id, 'Cleaning_In_Progress', v_to_status, p_user_role, p_row_version,
        @_v_p_success, @_v_p_error_code, @_v_p_error_message);
    SELECT @_v_p_success, @_v_p_error_code, @_v_p_error_message INTO p_success, p_error_code, p_error_message;
    IF p_success=0 THEN ROLLBACK; LEAVE sp_complete; END IF;

    -- Insert cleaning record
    INSERT INTO Cleaning_Record (Bin_ID, Loading_ID, Cleaner_User_ID, Cleaning_Method, Cleaning_Agent,
        Water_Temp_Celsius, Rinse_Cycles, Is_Reinspection_Cycle, Cleaning_Start_At, Comments)
    VALUES (p_bin_id, v_loading_id, p_user_id, p_method, p_agent, p_water_temp, p_rinse_cycles,
        v_is_reinspection, NOW(), p_comments);
    SET v_cleaning_id=LAST_INSERT_ID();

    -- Update bin status
    UPDATE Bin_Master SET Current_Status=v_to_status, Row_Version=Row_Version+1
    WHERE Bin_ID=p_bin_id AND Row_Version=p_row_version;
    SET v_rows_affected=ROW_COUNT();
    IF v_rows_affected=0 THEN
        ROLLBACK; SET p_error_code='CONCURRENT_MODIFICATION_CONFLICT';
        SET p_error_message='Bin modified by another user'; LEAVE sp_complete;
    END IF;

    -- Release lock (idempotent)
    CALL sp_release_lock(p_bin_id, p_user_id, @_lock_ok, @_lock_ec, @_lock_em);

    -- History
    CALL sp_insert_bin_history(p_bin_id, 'Cleaning_In_Progress', v_to_status, p_user_id,
        'COMPLETE_CLEANING', v_cleaning_id, 'Cleaning_Record', p_comments, NULL,
        @_hist_ok, @_hist_ec, @_hist_em);

    -- Audit
    CALL sp_insert_audit_log(p_user_id, 'COMPLETE_CLEANING', 'Bin_Master', p_bin_id,
        CONCAT('"Cleaning_In_Progress"'), CONCAT('"', v_to_status, '"'), NULL, NULL,
        @_aud_ok, @_aud_ec, @_aud_em);

    SET p_success=1;
    SELECT v_cleaning_id AS cleaning_id, v_to_status AS next_status;
    COMMIT;
END //

DELIMITER ;