-- =============================================================================
-- PBLMS — Migration 024: Dashboard Views + sp_generate_dashboard_metrics
-- =============================================================================
-- Dependencies: migrations 001-022 only
--   Bin_Master(006), Loading_Record(017), Unloading_Record(019),
--   Cleaning_Record(021), QA_Record(022), User_Master(001), Lock_Table(013)
-- Note: avg_cycle_time_30day = 0 until Cycle_Record is created (migration 023).
-- =============================================================================

CREATE OR REPLACE VIEW vw_dashboard_admin AS
SELECT
  (SELECT COUNT(*) FROM Bin_Master WHERE Is_Active=1) AS total_active_bins,
  (SELECT COUNT(*) FROM Bin_Master WHERE Current_Status='Awaiting_Loading' AND Is_Active=1) AS awaiting_loading,
  (SELECT COUNT(*) FROM Bin_Master WHERE Current_Status='Loading_In_Progress' AND Is_Active=1) AS loading_in_progress,
  (SELECT COUNT(*) FROM Bin_Master WHERE Current_Status='Awaiting_Unloading' AND Is_Active=1) AS awaiting_unloading,
  (SELECT COUNT(*) FROM Bin_Master WHERE Current_Status='Unloading_In_Progress' AND Is_Active=1) AS unloading_in_progress,
  (SELECT COUNT(*) FROM Bin_Master WHERE Current_Status='Awaiting_Cleaning' AND Is_Active=1) AS awaiting_cleaning,
  (SELECT COUNT(*) FROM Bin_Master WHERE Current_Status='Cleaning_In_Progress' AND Is_Active=1) AS cleaning_in_progress,
  (SELECT COUNT(*) FROM Bin_Master WHERE Current_Status='Awaiting_QA' AND Is_Active=1) AS awaiting_qa,
  (SELECT COUNT(*) FROM Bin_Master WHERE Current_Status='QA_In_Progress' AND Is_Active=1) AS qa_in_progress,
  (SELECT COUNT(*) FROM Bin_Master WHERE Current_Status='QA_Failed' AND Is_Active=1) AS qa_failed,
  (SELECT COUNT(*) FROM Bin_Master WHERE Current_Status='Reinspection_Cleaning' AND Is_Active=1) AS reinspection_cleaning,
  (SELECT COUNT(*) FROM Bin_Master WHERE Current_Status='Awaiting_Reinspection' AND Is_Active=1) AS awaiting_reinspection,
  (SELECT COUNT(*) FROM Bin_Master WHERE Current_Status='Retired' AND Is_Active=1) AS retired,
  (SELECT COUNT(*) FROM Bin_Master WHERE Requires_Admin_Review=1) AS admin_review_bins,
  (SELECT COUNT(*) FROM Bin_Master WHERE Overdue_Unloading=1) AS overdue_unloading,
  (SELECT COUNT(*) FROM Loading_Record WHERE DATE(Loading_Start_At)=CURDATE()) AS today_loading,
  (SELECT COUNT(*) FROM Unloading_Record WHERE DATE(Unloading_Start_At)=CURDATE()) AS today_unloading,
  (SELECT COUNT(*) FROM Cleaning_Record WHERE DATE(Cleaning_Start_At)=CURDATE()) AS today_cleaning,
  (SELECT COUNT(*) FROM QA_Record WHERE DATE(QA_Start_At)=CURDATE()) AS today_qa,
  COALESCE((SELECT ROUND(SUM(Overall_Result='PASS')*100.0/COUNT(*),1) FROM QA_Record WHERE DATE(QA_Start_At)=CURDATE()),0) AS qa_pass_rate_today,
  COALESCE((SELECT ROUND(SUM(Overall_Result='PASS')*100.0/COUNT(*),1) FROM QA_Record WHERE QA_Start_At>=DATE_SUB(CURDATE(),INTERVAL 7 DAY)),0) AS qa_pass_rate_7day,
  0 AS avg_cycle_time_30day;

CREATE OR REPLACE VIEW vw_dashboard_loader AS
SELECT
  (SELECT COUNT(*) FROM Bin_Master WHERE Current_Status='Awaiting_Loading' AND Is_Active=1) AS awaiting_loading,
  (SELECT COUNT(*) FROM Loading_Record WHERE DATE(Loading_Start_At)=CURDATE()) AS today_loadings;

CREATE OR REPLACE VIEW vw_dashboard_unloader AS
SELECT
  (SELECT COUNT(*) FROM Bin_Master WHERE Current_Status='Awaiting_Unloading' AND Is_Active=1) AS awaiting_unloading,
  (SELECT COUNT(*) FROM Loading_Record l JOIN Bin_Master b ON b.Bin_ID=l.Bin_ID WHERE b.Overdue_Unloading=1 AND l.Is_Current=1) AS overdue_unloading;

CREATE OR REPLACE VIEW vw_dashboard_cleaner AS
SELECT
  (SELECT COUNT(*) FROM Bin_Master WHERE Current_Status='Awaiting_Cleaning' AND Is_Active=1) AS awaiting_cleaning,
  (SELECT COUNT(*) FROM Bin_Master WHERE Current_Status='Reinspection_Cleaning' AND Is_Active=1) AS reinspection_cleaning;

CREATE OR REPLACE VIEW vw_dashboard_qa AS
SELECT
  (SELECT COUNT(*) FROM Bin_Master WHERE Current_Status='Awaiting_QA' AND Is_Active=1) AS awaiting_qa,
  (SELECT COUNT(*) FROM Bin_Master WHERE Current_Status='Awaiting_Reinspection' AND Is_Active=1) AS awaiting_reinspection,
  (SELECT COUNT(*) FROM QA_Record WHERE DATE(QA_Start_At)=CURDATE() AND Overall_Result='FAIL') AS today_failures,
  COALESCE((SELECT ROUND(SUM(Overall_Result='PASS')*100.0/COUNT(*),1) FROM QA_Record WHERE QA_Start_At>=DATE_SUB(CURDATE(),INTERVAL 7 DAY)),0) AS pass_rate_week;

CREATE OR REPLACE VIEW vw_active_locks AS
SELECT l.Lock_ID, l.Bin_ID, b.Bin_Number, l.Locked_By_User_ID, u.Full_Name AS locked_by_name,
       l.Operation_Type, l.Lock_Timestamp, l.Expires_At
FROM Lock_Table l
JOIN Bin_Master b ON b.Bin_ID = l.Bin_ID
JOIN User_Master u ON u.User_ID = l.Locked_By_User_ID;

DROP PROCEDURE IF EXISTS sp_generate_dashboard_metrics;

CREATE PROCEDURE sp_generate_dashboard_metrics(
    IN  p_user_role     VARCHAR(50),
    OUT p_success       TINYINT(1),
    OUT p_error_code    VARCHAR(100),
    OUT p_error_message VARCHAR(500)
)
BEGIN
    SET p_success=0; SET p_error_code=NULL; SET p_error_message=NULL;

    IF p_user_role='Administrator' THEN
        SELECT * FROM vw_dashboard_admin;
    ELSEIF p_user_role='Loader' THEN
        SELECT * FROM vw_dashboard_loader;
    ELSEIF p_user_role='Unloader' THEN
        SELECT * FROM vw_dashboard_unloader;
    ELSEIF p_user_role='Cleaner' THEN
        SELECT * FROM vw_dashboard_cleaner;
    ELSEIF p_user_role='QA_Inspector' THEN
        SELECT * FROM vw_dashboard_qa;
    ELSE
        SELECT * FROM vw_dashboard_loader;
    END IF;

    SET p_success=1;
END;
