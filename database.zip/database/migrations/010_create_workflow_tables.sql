-- Migration 010: Status_Master + Transition_Master tables + FK to Bin_Master
CREATE TABLE IF NOT EXISTS Status_Master (
    Status_Code VARCHAR(50) PRIMARY KEY,
    Status_Label VARCHAR(100) NOT NULL,
    Display_Order INT NOT NULL DEFAULT 0,
    Is_Terminal TINYINT(1) NOT NULL DEFAULT 0,
    Description VARCHAR(500) NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS Transition_Master (
    Transition_ID INT AUTO_INCREMENT PRIMARY KEY,
    From_Status VARCHAR(50) NOT NULL,
    To_Status VARCHAR(50) NOT NULL,
    Permitted_Role VARCHAR(50) NOT NULL,
    Operation_Type VARCHAR(50) NOT NULL,
    Requires_Lock TINYINT(1) NOT NULL DEFAULT 1,
    Description VARCHAR(500) NULL,
    UNIQUE KEY uq_transition (From_Status, To_Status, Permitted_Role),
    INDEX idx_from_status (From_Status),
    INDEX idx_to_status (To_Status),
    CONSTRAINT fk_transition_from FOREIGN KEY (From_Status) REFERENCES Status_Master(Status_Code) ON DELETE RESTRICT,
    CONSTRAINT fk_transition_to   FOREIGN KEY (To_Status)   REFERENCES Status_Master(Status_Code) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

ALTER TABLE Bin_Master ADD CONSTRAINT fk_bin_current_status
    FOREIGN KEY (Current_Status) REFERENCES Status_Master(Status_Code) ON DELETE RESTRICT;