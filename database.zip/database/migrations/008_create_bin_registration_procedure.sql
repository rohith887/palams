-- PBLMS — Migration 008: sp_register_bin
DELIMITER //
CREATE PROCEDURE sp_register_bin(
    IN  p_admin_user_id    INT, IN  p_bin_number       VARCHAR(30),
    IN  p_qr_code_value    VARCHAR(200), IN  p_bin_type_id      INT,
    IN  p_bin_category_id  INT, IN  p_capacity         DECIMAL(10,3),
    IN  p_capacity_unit    VARCHAR(20),
    OUT p_success          TINYINT(1), OUT p_error_code VARCHAR(100), OUT p_error_message VARCHAR(500)
)
BEGIN
    SET p_success = 0; SET p_error_code = NULL; SET p_error_message = NULL;
    IF EXISTS (SELECT 1 FROM Bin_Master WHERE Bin_Number = p_bin_number) THEN
        SET p_error_code = 'DUPLICATE_ENTRY'; SET p_error_message = CONCAT('Bin number "', p_bin_number, '" already exists');
    ELSEIF EXISTS (SELECT 1 FROM Bin_Master WHERE QR_Code_Value = p_qr_code_value) THEN
        SET p_error_code = 'DUPLICATE_ENTRY'; SET p_error_message = 'QR code value already in use';
    ELSEIF NOT EXISTS (SELECT 1 FROM Bin_Type_Master WHERE Bin_Type_ID = p_bin_type_id AND Is_Active = 1) THEN
        SET p_error_code = 'VALIDATION_ERROR'; SET p_error_message = 'Bin type not found or inactive';
    ELSEIF NOT EXISTS (SELECT 1 FROM Bin_Category_Master WHERE Bin_Category_ID = p_bin_category_id AND Is_Active = 1) THEN
        SET p_error_code = 'VALIDATION_ERROR'; SET p_error_message = 'Bin category not found or inactive';
    ELSEIF p_capacity <= 0 THEN
        SET p_error_code = 'VALIDATION_ERROR'; SET p_error_message = 'Capacity must be greater than zero';
    ELSE
        INSERT INTO Bin_Master (Bin_Number, QR_Code_Value, Bin_Type_ID, Bin_Category_ID, Capacity, Capacity_Unit, Current_Status, Row_Version, Created_By)
        VALUES (p_bin_number, p_qr_code_value, p_bin_type_id, p_bin_category_id, p_capacity, p_capacity_unit, 'Awaiting_Loading', 1, p_admin_user_id);
        SET p_success = 1; SELECT LAST_INSERT_ID() AS bin_id;
    END IF;
END //
DELIMITER ;