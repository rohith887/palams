-- =============================================================================
-- PBLMS — Migration 025: Report Database Objects
-- Pharmaceutical Bin Lifecycle Management System
-- =============================================================================
-- Design Spec Reference: Section 4.5
-- Creates all report-related views required by the Reports module.
-- =============================================================================

-- ---------------------------------------------------------------------------
-- 1. vw_bin_lifecycle_summary — Per-bin current state with latest operation
-- ---------------------------------------------------------------------------
CREATE OR REPLACE VIEW vw_bin_lifecycle_summary AS
SELECT
  b.Bin_ID, b.Bin_Number, b.QR_Code_Value, b.Current_Status, b.Is_Active,
  b.Current_Bay_ID, b.Current_Tank_ID, b.Requires_Admin_Review,
  b.Requires_QA_Attention, b.Overdue_Unloading, b.Consecutive_Fail_Count,
  b.Last_QA_Date, b.Row_Version, b.Created_At,
  bt.Type_Name AS Bin_Type_Name,
  bc.Category_Name AS Bin_Category_Name,
  bay.Bay_Code, bay.Bay_Name,
  tank.Tank_Code, tank.Tank_Name,
  l.Loading_ID, l.Loader_User_ID, lu.Full_Name AS Loader_Name,
  l.Material_ID, m.Material_Name, l.Batch_Number, l.Quantity_Loaded,
  l.Unit_Of_Measure, l.Expected_Unloading_Date,
  l.Loading_Start_At, l.Loading_Completed_At,
  un.Unloading_ID, un.Unloader_User_ID, uu.Full_Name AS Unloader_Name,
  un.Unloading_Condition, un.Quantity_Unloaded,
  cr.Cleaning_ID, cr.Cleaner_User_ID, cu.Full_Name AS Cleaner_Name,
  cr.Cleaning_Method, cr.Cleaning_Agent,
  qa.QA_ID, qa.QA_Inspector_User_ID, qu.Full_Name AS QA_Inspector_Name,
  qa.Overall_Result, qa.Failure_Reason, qa.QA_Completed_At
FROM Bin_Master b
LEFT JOIN Bin_Type_Master bt ON bt.Bin_Type_ID = b.Bin_Type_ID
LEFT JOIN Bin_Category_Master bc ON bc.Bin_Category_ID = b.Bin_Category_ID
LEFT JOIN Bay_Master bay ON bay.Bay_ID = b.Current_Bay_ID
LEFT JOIN Tank_Master tank ON tank.Tank_ID = b.Current_Tank_ID
LEFT JOIN Loading_Record l ON l.Bin_ID = b.Bin_ID AND l.Is_Current = 1
LEFT JOIN User_Master lu ON lu.User_ID = l.Loader_User_ID
LEFT JOIN Material_Master m ON m.Material_ID = l.Material_ID
LEFT JOIN Unloading_Record un ON un.Bin_ID = b.Bin_ID AND un.Loading_ID = l.Loading_ID
LEFT JOIN User_Master uu ON uu.User_ID = un.Unloader_User_ID
LEFT JOIN Cleaning_Record cr ON cr.Bin_ID = b.Bin_ID AND cr.Loading_ID = l.Loading_ID
LEFT JOIN User_Master cu ON cu.User_ID = cr.Cleaner_User_ID
LEFT JOIN QA_Record qa ON qa.Bin_ID = b.Bin_ID AND qa.Cleaning_ID = cr.Cleaning_ID
LEFT JOIN User_Master qu ON qu.User_ID = qa.QA_Inspector_User_ID;

-- ---------------------------------------------------------------------------
-- 2. vw_rpt_loading — Loading report base query
-- ---------------------------------------------------------------------------
CREATE OR REPLACE VIEW vw_rpt_loading AS
SELECT
  l.Loading_ID, l.Bin_ID, b.Bin_Number,
  l.Loader_User_ID, u.Full_Name AS Loader_Name,
  l.Bay_ID, bay.Bay_Code, bay.Bay_Name,
  l.Tank_ID, tank.Tank_Code, tank.Tank_Name,
  l.Material_ID, m.Material_Code, m.Material_Name, m.Hazard_Level,
  l.Quantity_Loaded, l.Unit_Of_Measure, l.Batch_Number,
  l.Expected_Unloading_Date, l.Loading_Start_At, l.Loading_Completed_At,
  l.Comments, l.Is_Current
FROM Loading_Record l
JOIN Bin_Master b ON b.Bin_ID = l.Bin_ID
JOIN User_Master u ON u.User_ID = l.Loader_User_ID
JOIN Bay_Master bay ON bay.Bay_ID = l.Bay_ID
JOIN Tank_Master tank ON tank.Tank_ID = l.Tank_ID
JOIN Material_Master m ON m.Material_ID = l.Material_ID;

-- ---------------------------------------------------------------------------
-- 3. vw_rpt_unloading — Unloading report base query
-- ---------------------------------------------------------------------------
CREATE OR REPLACE VIEW vw_rpt_unloading AS
SELECT
  un.Unloading_ID, un.Bin_ID, b.Bin_Number,
  un.Loading_ID, l.Material_ID, m.Material_Name, l.Batch_Number,
  l.Quantity_Loaded, un.Quantity_Unloaded,
  un.Unloader_User_ID, uu.Full_Name AS Unloader_Name,
  lu.Full_Name AS Loader_Name,
  un.Unloading_Condition,
  un.Unloading_Start_At, un.Unloading_Completed_At,
  un.Comments
FROM Unloading_Record un
JOIN Bin_Master b ON b.Bin_ID = un.Bin_ID
JOIN Loading_Record l ON l.Loading_ID = un.Loading_ID
JOIN User_Master uu ON uu.User_ID = un.Unloader_User_ID
JOIN User_Master lu ON lu.User_ID = l.Loader_User_ID
JOIN Material_Master m ON m.Material_ID = l.Material_ID;

-- ---------------------------------------------------------------------------
-- 4. vw_rpt_cleaning — Cleaning report base query
-- ---------------------------------------------------------------------------
CREATE OR REPLACE VIEW vw_rpt_cleaning AS
SELECT
  cr.Cleaning_ID, cr.Bin_ID, b.Bin_Number,
  cr.Cleaner_User_ID, u.Full_Name AS Cleaner_Name,
  cr.Cleaning_Method, cr.Cleaning_Agent,
  cr.Water_Temp_Celsius, cr.Rinse_Cycles,
  cr.Is_Reinspection_Cycle,
  cr.Cleaning_Start_At, cr.Cleaning_Completed_At,
  cr.Comments
FROM Cleaning_Record cr
JOIN Bin_Master b ON b.Bin_ID = cr.Bin_ID
JOIN User_Master u ON u.User_ID = cr.Cleaner_User_ID;

-- ---------------------------------------------------------------------------
-- 5. vw_rpt_qa — QA report base query with all 6 checklist items
-- ---------------------------------------------------------------------------
CREATE OR REPLACE VIEW vw_rpt_qa AS
SELECT
  qa.QA_ID, qa.Bin_ID, b.Bin_Number,
  qa.QA_Inspector_User_ID, u.Full_Name AS QA_Inspector_Name,
  qa.Cleaning_ID, cr.Cleaning_Method, cr.Cleaning_Agent,
  qa.Visual_Inspection, qa.Visual_Notes,
  qa.Residue_Check, qa.Residue_Notes,
  qa.Damage_Assessment, qa.Damage_Notes,
  qa.Odor_Check, qa.Odor_Notes,
  qa.Label_Integrity, qa.Label_Notes,
  qa.Seal_Integrity, qa.Seal_Notes,
  qa.Overall_Result, qa.Failure_Reason, qa.Is_Reinspection,
  qa.QA_Start_At, qa.QA_Completed_At
FROM QA_Record qa
JOIN Bin_Master b ON b.Bin_ID = qa.Bin_ID
JOIN User_Master u ON u.User_ID = qa.QA_Inspector_User_ID
JOIN Cleaning_Record cr ON cr.Cleaning_ID = qa.Cleaning_ID;

-- ---------------------------------------------------------------------------
-- 6. vw_rpt_rejected_bin — Rejected bins with consecutive fail count
-- ---------------------------------------------------------------------------
CREATE OR REPLACE VIEW vw_rpt_rejected_bin AS
SELECT
  b.Bin_ID, b.Bin_Number, b.Current_Status, b.Consecutive_Fail_Count,
  qa.QA_ID AS Last_QA_ID, qa.Overall_Result, qa.Failure_Reason,
  qa.QA_Completed_At AS Rejection_Date,
  u.Full_Name AS QA_Inspector_Name,
  DATEDIFF(CURDATE(), COALESCE(qa.QA_Completed_At, b.Last_QA_Date)) AS Days_Since_Rejection
FROM Bin_Master b
JOIN QA_Record qa ON qa.Bin_ID = b.Bin_ID
JOIN User_Master u ON u.User_ID = qa.QA_Inspector_User_ID
WHERE b.Current_Status = 'QA_Failed' AND qa.Overall_Result = 'FAIL'
ORDER BY qa.QA_Completed_At DESC;

-- ---------------------------------------------------------------------------
-- 7. vw_rpt_lifecycle — Full bin lifecycle timeline per cycle from Cycle_Record
-- ---------------------------------------------------------------------------
CREATE OR REPLACE VIEW vw_rpt_lifecycle AS
SELECT
  c.Cycle_ID, c.Bin_ID, b.Bin_Number,
  c.Cycle_Start_At, c.Cycle_End_At,
  c.Total_Cycle_Duration_Minutes,
  c.Loading_Duration_Minutes, c.Unloading_Duration_Minutes,
  c.Cleaning_Duration_Minutes, c.QA_Duration_Minutes,
  c.Reinspection_Count,
  qa.QA_ID, qa.Overall_Result,
  u.Full_Name AS QA_Inspector_Name
FROM Cycle_Record c
JOIN Bin_Master b ON b.Bin_ID = c.Bin_ID
JOIN QA_Record qa ON qa.QA_ID = c.QA_ID
JOIN User_Master u ON u.User_ID = qa.QA_Inspector_User_ID;

-- ---------------------------------------------------------------------------
-- 8. vw_rpt_user_activity — User operation counts from all transaction tables
-- ---------------------------------------------------------------------------
CREATE OR REPLACE VIEW vw_rpt_user_activity AS
SELECT
  u.User_ID, u.Username, u.Full_Name, u.Role,
  COALESCE(l.load_count,0) AS loading_count,
  COALESCE(un.unload_count,0) AS unloading_count,
  COALESCE(cl.clean_count,0) AS cleaning_count,
  COALESCE(qa.qa_count,0) AS qa_count,
  COALESCE(l.last_loading, un.last_unloading, cl.last_cleaning, qa.last_qa) AS last_activity
FROM User_Master u
LEFT JOIN (
  SELECT Loader_User_ID, COUNT(*) AS load_count, MAX(Loading_Start_At) AS last_loading
  FROM Loading_Record GROUP BY Loader_User_ID
) l ON l.Loader_User_ID = u.User_ID
LEFT JOIN (
  SELECT Unloader_User_ID, COUNT(*) AS unload_count, MAX(Unloading_Start_At) AS last_unloading
  FROM Unloading_Record GROUP BY Unloader_User_ID
) un ON un.Unloader_User_ID = u.User_ID
LEFT JOIN (
  SELECT Cleaner_User_ID, COUNT(*) AS clean_count, MAX(Cleaning_Start_At) AS last_cleaning
  FROM Cleaning_Record GROUP BY Cleaner_User_ID
) cl ON cl.Cleaner_User_ID = u.User_ID
LEFT JOIN (
  SELECT QA_Inspector_User_ID, COUNT(*) AS qa_count, MAX(QA_Start_At) AS last_qa
  FROM QA_Record GROUP BY QA_Inspector_User_ID
) qa ON qa.QA_Inspector_User_ID = u.User_ID;

-- ---------------------------------------------------------------------------
-- 9. vw_rpt_audit_trail — Filterable audit log with user names
-- ---------------------------------------------------------------------------
CREATE OR REPLACE VIEW vw_rpt_audit_trail AS
SELECT
  a.Audit_ID, a.Actor_User_ID, u.Full_Name AS Actor_Name,
  a.Action_Type, a.Target_Entity, a.Target_ID,
  a.Old_Value, a.New_Value, a.IP_Address, a.User_Agent,
  a.Event_Timestamp
FROM Audit_Log a
LEFT JOIN User_Master u ON u.User_ID = a.Actor_User_ID;