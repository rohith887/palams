-- Migration 016: sp_insert_bin_history + sp_insert_audit_log
DELIMITER //

CREATE PROCEDURE sp_insert_bin_history(
    IN  p_bin_id INT, IN p_previous_status VARCHAR(50), IN p_new_status VARCHAR(50),
    IN  p_acting_user_id INT, IN p_operation_type VARCHAR(50),
    IN  p_operation_record_id INT, IN p_operation_record_type VARCHAR(30),
    IN  p_remarks VARCHAR(500), IN p_cycle_number INT,
    OUT p_success TINYINT(1), OUT p_error_code VARCHAR(100), OUT p_error_message VARCHAR(500)
)
BEGIN
    SET p_success=0; SET p_error_code=NULL; SET p_error_message=NULL;
    INSERT INTO Bin_History(Bin_ID,Previous_Status,New_Status,Acting_User_ID,Operation_Type,Operation_Record_ID,Operation_Record_Type,Remarks,Cycle_Number)
    VALUES(p_bin_id,p_previous_status,p_new_status,p_acting_user_id,p_operation_type,p_operation_record_id,p_operation_record_type,p_remarks,p_cycle_number);
    SET p_success=1; SELECT LAST_INSERT_ID() AS history_id;
END //

CREATE PROCEDURE sp_insert_audit_log(
    IN  p_actor_user_id INT, IN p_action_type VARCHAR(100), IN p_target_entity VARCHAR(50),
    IN  p_target_id INT, IN p_old_value JSON, IN p_new_value JSON,
    IN  p_ip_address VARCHAR(45), IN p_user_agent VARCHAR(500),
    OUT p_success TINYINT(1), OUT p_error_code VARCHAR(100), OUT p_error_message VARCHAR(500)
)
BEGIN
    SET p_success=0; SET p_error_code=NULL; SET p_error_message=NULL;
    INSERT INTO Audit_Log(Actor_User_ID,Action_Type,Target_Entity,Target_ID,Old_Value,New_Value,IP_Address,User_Agent)
    VALUES(p_actor_user_id,p_action_type,p_target_entity,p_target_id,p_old_value,p_new_value,p_ip_address,p_user_agent);
    SET p_success=1; SELECT LAST_INSERT_ID() AS audit_id;
END //

DELIMITER ;