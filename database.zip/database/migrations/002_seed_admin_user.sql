-- =============================================================================
-- PBLMS — Migration 002: Bootstrap Administrator User
-- Pharmaceutical Bin Lifecycle Management System
-- =============================================================================
-- Purpose:
--   Inserts the initial Administrator account into User_Master so that
--   the system can be accessed after deployment. The password is a bcrypt
--   hash with cost factor 12.
--
-- Default Credentials:
--   Username: admin
--   Password: Admin@PBLMS2024!
--   Role:     Administrator
--
-- SECURITY NOTE:
--   The Administrator MUST change this password immediately after first login.
--   This default password should be treated as a shared secret that is only
--   valid during initial system setup. In production, the password should be
--   changed before exposing the system to any network.
--
--   bcrypt hash of 'Admin@PBLMS2024!' with cost factor 12:
--   $2b$12$LJ3m4ys3YOlDkOmMrPJ7OOCCpNn1XGM4FGpWmFJFAzVONtFMiG8LS
--
-- Dependencies: Migration 001 (User_Master table must exist)
-- =============================================================================

INSERT INTO User_Master (Username, Password_Hash, Full_Name, Role, Is_Active, Created_By, Updated_By)
VALUES (
    'admin',
    '$2b$12$LJ3m4ys3YOlDkOmMrPJ7OOCCpNn1XGM4FGpWmFJFAzVONtFMiG8LS',
    'System Administrator',
    'Administrator',
    1,
    NULL,
    NULL
);