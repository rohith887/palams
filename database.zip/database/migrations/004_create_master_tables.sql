-- =============================================================================
-- PBLMS — Migration 004: Master Data Tables
-- Pharmaceutical Bin Lifecycle Management System
-- =============================================================================
-- Purpose:
--   Creates the five master data tables required before any operational
--   or workflow tables can be created:
--     - Bay_Master        — Physical facility zones
--     - Tank_Master       — Sub-locations within bays
--     - Material_Master   — Validated pharmaceutical materials
--     - Bin_Type_Master   — Physical bin type classifications
--     - Bin_Category_Master — Operational bin category classifications
--
-- Design Spec Reference: Section 4.2
-- Dependencies: Migration 001 (User_Master must exist for FK references)
-- =============================================================================

-- ---------------------------------------------------------------------------
-- Bay_Master — Physical facility zones
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS Bay_Master (
    Bay_ID INT AUTO_INCREMENT PRIMARY KEY,
    Bay_Code VARCHAR(20) NOT NULL,
    Bay_Name VARCHAR(100) NOT NULL,
    Location_Description VARCHAR(500) NULL,
    Is_Active TINYINT(1) NOT NULL DEFAULT 1,
    Created_At DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    Created_By INT NULL,

    UNIQUE KEY uq_bay_code (Bay_Code),
    INDEX idx_is_active (Is_Active),
    CONSTRAINT fk_bay_created_by
        FOREIGN KEY (Created_By) REFERENCES User_Master(User_ID)
        ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------------
-- Tank_Master — Sub-locations within bays
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS Tank_Master (
    Tank_ID INT AUTO_INCREMENT PRIMARY KEY,
    Bay_ID INT NOT NULL,
    Tank_Code VARCHAR(20) NOT NULL,
    Tank_Name VARCHAR(100) NOT NULL,
    Tank_Capacity DECIMAL(10, 3) NULL,
    Is_Active TINYINT(1) NOT NULL DEFAULT 1,
    Created_At DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    Created_By INT NULL,

    UNIQUE KEY uq_tank_code (Tank_Code),
    INDEX idx_bay_id (Bay_ID),
    INDEX idx_is_active (Is_Active),
    CONSTRAINT fk_tank_bay
        FOREIGN KEY (Bay_ID) REFERENCES Bay_Master(Bay_ID)
        ON DELETE RESTRICT,
    CONSTRAINT fk_tank_created_by
        FOREIGN KEY (Created_By) REFERENCES User_Master(User_ID)
        ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------------
-- Material_Master — Validated pharmaceutical materials
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS Material_Master (
    Material_ID INT AUTO_INCREMENT PRIMARY KEY,
    Material_Code VARCHAR(30) NOT NULL,
    Material_Name VARCHAR(200) NOT NULL,
    Material_Category VARCHAR(100) NULL,
    Hazard_Level ENUM('Low', 'Medium', 'High') NOT NULL,
    Storage_Temp_Min_C DECIMAL(5, 2) NULL,
    Storage_Temp_Max_C DECIMAL(5, 2) NULL,
    Handling_Instructions VARCHAR(1000) NULL,
    Is_Active TINYINT(1) NOT NULL DEFAULT 1,
    Created_At DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    Created_By INT NULL,

    UNIQUE KEY uq_material_code (Material_Code),
    INDEX idx_is_active (Is_Active),
    INDEX idx_hazard_level (Hazard_Level),
    CONSTRAINT chk_temp_range CHECK (
        Storage_Temp_Max_C IS NULL OR Storage_Temp_Min_C IS NULL
        OR Storage_Temp_Max_C > Storage_Temp_Min_C
    ),
    CONSTRAINT fk_material_created_by
        FOREIGN KEY (Created_By) REFERENCES User_Master(User_ID)
        ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------------
-- Bin_Type_Master — Physical bin type classifications
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS Bin_Type_Master (
    Bin_Type_ID INT AUTO_INCREMENT PRIMARY KEY,
    Type_Code VARCHAR(30) NOT NULL,
    Type_Name VARCHAR(100) NOT NULL,
    Is_Active TINYINT(1) NOT NULL DEFAULT 1,

    UNIQUE KEY uq_type_code (Type_Code),
    INDEX idx_is_active (Is_Active)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------------
-- Bin_Category_Master — Operational bin category classifications
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS Bin_Category_Master (
    Bin_Category_ID INT AUTO_INCREMENT PRIMARY KEY,
    Category_Code VARCHAR(30) NOT NULL,
    Category_Name VARCHAR(100) NOT NULL,
    Is_Active TINYINT(1) NOT NULL DEFAULT 1,

    UNIQUE KEY uq_category_code (Category_Code),
    INDEX idx_is_active (Is_Active)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;