-- =============================================================================
-- PBLMS — Migration 005: Seed Master Data
-- Pharmaceutical Bin Lifecycle Management System
-- =============================================================================
-- Purpose:
--   Seeds sample records into all master data tables for development
--   and testing. These records provide the foundation for operational
--   workflows and UI dropdown population.
--
-- Dependencies: Migration 004 (all master tables must exist)
-- =============================================================================

-- ---------------------------------------------------------------------------
-- Bay_Master — Sample facility zones
-- ---------------------------------------------------------------------------
INSERT INTO Bay_Master (Bay_Code, Bay_Name, Location_Description, Is_Active) VALUES
('BAY-A', 'Production Bay A', 'Main production area — east wing', 1),
('BAY-B', 'Production Bay B', 'Main production area — west wing', 1),
('BAY-C', 'Storage Bay C', 'Cold storage area for temperature-sensitive materials', 1),
('BAY-Q', 'Quarantine Bay Q', 'Holding area for bins awaiting inspection', 1);

-- ---------------------------------------------------------------------------
-- Tank_Master — Sample sub-locations (one tank belongs to exactly one bay)
-- ---------------------------------------------------------------------------
-- BAY-A tanks
SET @bay_a_id = (SELECT Bay_ID FROM Bay_Master WHERE Bay_Code = 'BAY-A');
INSERT INTO Tank_Master (Bay_ID, Tank_Code, Tank_Name, Tank_Capacity, Is_Active) VALUES
(@bay_a_id, 'TNK-A1', 'Reactor Tank A1', 5000.000, 1),
(@bay_a_id, 'TNK-A2', 'Reactor Tank A2', 5000.000, 1),
(@bay_a_id, 'TNK-A3', 'Mixing Tank A3', 3000.000, 1);

-- BAY-B tanks
SET @bay_b_id = (SELECT Bay_ID FROM Bay_Master WHERE Bay_Code = 'BAY-B');
INSERT INTO Tank_Master (Bay_ID, Tank_Code, Tank_Name, Tank_Capacity, Is_Active) VALUES
(@bay_b_id, 'TNK-B1', 'Reactor Tank B1', 5000.000, 1),
(@bay_b_id, 'TNK-B2', 'Blending Tank B2', 4000.000, 1);

-- BAY-C tanks
SET @bay_c_id = (SELECT Bay_ID FROM Bay_Master WHERE Bay_Code = 'BAY-C');
INSERT INTO Tank_Master (Bay_ID, Tank_Code, Tank_Name, Tank_Capacity, Is_Active) VALUES
(@bay_c_id, 'TNK-C1', 'Cold Storage Tank C1', 2000.000, 1);

-- ---------------------------------------------------------------------------
-- Material_Master — Validated pharmaceutical substances
-- ---------------------------------------------------------------------------
INSERT INTO Material_Master (Material_Code, Material_Name, Material_Category, Hazard_Level, Storage_Temp_Min_C, Storage_Temp_Max_C, Handling_Instructions, Is_Active) VALUES
('MAT-001', 'Paracetamol API', 'Active Pharmaceutical Ingredient', 'Low', 15.00, 30.00, 'Store in a dry, well-ventilated area. Avoid direct sunlight.', 1),
('MAT-002', 'Ibuprofen API', 'Active Pharmaceutical Ingredient', 'Low', 15.00, 25.00, 'Keep container tightly closed. Protect from moisture.', 1),
('MAT-003', 'Amoxicillin Trihydrate', 'Antibiotic API', 'Medium', 2.00, 8.00, 'Store refrigerated. Handle with gloves. Avoid inhalation of dust.', 1),
('MAT-004', 'Methylprednisolone', 'Corticosteroid API', 'High', 2.00, 8.00, 'HIGHLY POTENT — Use full PPE. Dedicated equipment required. Consult SOP-PH-042 before handling.', 1),
('MAT-005', 'Sodium Chloride Excipient', 'Excipient', 'Low', NULL, NULL, 'No special handling required. Keep dry.', 1),
('MAT-006', 'Microcrystalline Cellulose', 'Excipient', 'Low', NULL, NULL, 'Avoid dust generation. Use dust mask if ventilation is inadequate.', 1),
('MAT-007', 'Ethanol 96%', 'Solvent', 'High', 10.00, 25.00, 'HIGHLY FLAMMABLE. Store away from ignition sources. Use explosion-proof equipment.', 1);

-- ---------------------------------------------------------------------------
-- Bin_Type_Master — Physical bin type classifications
-- ---------------------------------------------------------------------------
INSERT INTO Bin_Type_Master (Type_Code, Type_Name, Is_Active) VALUES
('IBC', 'Intermediate Bulk Container', 1),
('DRUM', 'Stainless Steel Drum', 1),
('TOTE', 'Plastic Tote', 1),
('BIN-SS', 'Stainless Steel Bin', 1),
('BIN-HD', 'Heavy Duty Poly Bin', 1);

-- ---------------------------------------------------------------------------
-- Bin_Category_Master — Operational category classifications
-- ---------------------------------------------------------------------------
INSERT INTO Bin_Category_Master (Category_Code, Category_Name, Is_Active) VALUES
('PRIMARY', 'Primary Production', 1),
('SECONDARY', 'Secondary Processing', 1),
('QUARANTINE', 'Quarantine / Hold', 1),
('SAMPLING', 'Sampling', 1),
('TRANSPORT', 'Transport / Logistics', 1);