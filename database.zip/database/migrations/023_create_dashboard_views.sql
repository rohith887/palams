-- PBLMS Migration 023: Cycle_Record + Dashboard Views
CREATE TABLE IF NOT EXISTS Cycle_Record (
    Cycle_ID INT AUTO_INCREMENT PRIMARY KEY,
    Bin_ID INT NOT NULL,
    QA_ID INT NOT NULL,
    Cycle_Start_At DATETIME NOT NULL,
    Cycle_End_At DATETIME NOT NULL,
    Total_Cycle_Duration_Minutes INT NOT NULL,
    Loading_Duration_Minutes INT NOT NULL,
    Unloading_Duration_Minutes INT NOT NULL,
    Cleaning_Duration_Minutes INT NOT NULL,
    QA_Duration_Minutes INT NOT NULL,
    Reinspection_Count TINYINT NOT NULL DEFAULT 0,
    INDEX idx_bin_id (Bin_ID), INDEX idx_cycle_end (Cycle_End_At),
    CONSTRAINT fk_cycle_bin FOREIGN KEY (Bin_ID) REFERENCES Bin_Master(Bin_ID) ON DELETE RESTRICT,
    CONSTRAINT fk_cycle_qa FOREIGN KEY (QA_ID) REFERENCES QA_Record(QA_ID) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Active locks view
CREATE OR REPLACE VIEW vw_active_locks AS
SELECT l.Lock_ID, l.Bin_ID, b.Bin_Number, l.Locked_By_User_ID, u.Full_Name AS locked_by_name,
       l.Operation_Type, l.Lock_Timestamp, l.Expires_At
FROM Lock_Table l
JOIN Bin_Master b ON b.Bin_ID = l.Bin_ID
JOIN User_Master u ON u.User_ID = l.Locked_By_User_ID;

-- Admin dashboard
CREATE OR REPLACE VIEW vw_dashboard_admin AS
SELECT
  (SELECT COUNT(*) FROM Bin_Master WHERE Is_Active=1) AS total_active_bins,
  (SELECT COUNT(*) FROM Bin_Master WHERE Current_Status='Awaiting_Loading' AND Is_Active=1) AS awaiting_loading,
  (SELECT COUNT(*) FROM Bin_Master WHERE Current_Status='Loading_In_Progress' AND Is_Active=1) AS loading_in_progress,
  (SELECT COUNT(*) FROM Bin_Master WHERE Current_Status='Awaiting_Unloading' AND Is_Active=1) AS awaiting_unloading,
  (SELECT COUNT(*) FROM Bin_Master WHERE Current_Status='Unloading_In_Progress' AND Is_Active=1) AS unloading_in_progress,
  (SELECT COUNT(*) FROM Bin_Master WHERE Current_Status='Awaiting_Cleaning' AND Is_Active=1) AS awaiting_cleaning,
  (SELECT COUNT(*) FROM Bin_Master WHERE Current_Status='Cleaning_In_Progress' AND Is_Active=1) AS cleaning_in_progress,
  (SELECT COUNT(*) FROM Bin_Master WHERE Current_Status='Awaiting_QA' AND Is_Active=1) AS awaiting_qa,
  (SELECT COUNT(*) FROM Bin_Master WHERE Current_Status='QA_In_Progress' AND Is_Active=1) AS qa_in_progress,
  (SELECT COUNT(*) FROM Bin_Master WHERE Current_Status='QA_Failed' AND Is_Active=1) AS qa_failed,
  (SELECT COUNT(*) FROM Bin_Master WHERE Current_Status='Reinspection_Cleaning' AND Is_Active=1) AS reinspection_cleaning,
  (SELECT COUNT(*) FROM Bin_Master WHERE Current_Status='Awaiting_Reinspection' AND Is_Active=1) AS awaiting_reinspection,
  (SELECT COUNT(*) FROM Bin_Master WHERE Current_Status='Retired' AND Is_Active=1) AS retired,
  (SELECT COUNT(*) FROM Bin_Master WHERE Requires_Admin_Review=1) AS admin_review_bins,
  (SELECT COUNT(*) FROM Bin_Master WHERE Overdue_Unloading=1) AS overdue_unloading,
  (SELECT COUNT(*) FROM Loading_Record WHERE DATE(Loading_Start_At)=CURDATE()) AS today_loading,
  (SELECT COUNT(*) FROM Unloading_Record WHERE DATE(Unloading_Start_At)=CURDATE()) AS today_unloading,
  (SELECT COUNT(*) FROM Cleaning_Record WHERE DATE(Cleaning_Start_At)=CURDATE()) AS today_cleaning,
  (SELECT COUNT(*) FROM QA_Record WHERE DATE(QA_Start_At)=CURDATE()) AS today_qa,
  COALESCE((SELECT ROUND(SUM(Overall_Result='PASS')*100.0/COUNT(*),1) FROM QA_Record WHERE DATE(QA_Start_At)=CURDATE()),0) AS qa_pass_rate_today,
  COALESCE((SELECT ROUND(SUM(Overall_Result='PASS')*100.0/COUNT(*),1) FROM QA_Record WHERE QA_Start_At>=DATE_SUB(CURDATE(),INTERVAL 7 DAY)),0) AS qa_pass_rate_7day,
  COALESCE((SELECT ROUND(AVG(Total_Cycle_Duration_Minutes)) FROM Cycle_Record WHERE Cycle_End_At>=DATE_SUB(CURDATE(),INTERVAL 30 DAY)),0) AS avg_cycle_time_30day;

-- Loader dashboard
CREATE OR REPLACE VIEW vw_dashboard_loader AS
SELECT
  (SELECT COUNT(*) FROM Bin_Master WHERE Current_Status='Awaiting_Loading' AND Is_Active=1) AS awaiting_loading,
  (SELECT COUNT(*) FROM Loading_Record WHERE DATE(Loading_Start_At)=CURDATE()) AS today_loadings;

-- Unloader dashboard
CREATE OR REPLACE VIEW vw_dashboard_unloader AS
SELECT
  (SELECT COUNT(*) FROM Bin_Master WHERE Current_Status='Awaiting_Unloading' AND Is_Active=1) AS awaiting_unloading,
  (SELECT COUNT(*) FROM Loading_Record l JOIN Bin_Master b ON b.Bin_ID=l.Bin_ID WHERE b.Overdue_Unloading=1 AND l.Is_Current=1) AS overdue_unloading;

-- Cleaner dashboard
CREATE OR REPLACE VIEW vw_dashboard_cleaner AS
SELECT
  (SELECT COUNT(*) FROM Bin_Master WHERE Current_Status='Awaiting_Cleaning' AND Is_Active=1) AS awaiting_cleaning,
  (SELECT COUNT(*) FROM Bin_Master WHERE Current_Status='Reinspection_Cleaning' AND Is_Active=1) AS reinspection_cleaning;

-- QA dashboard
CREATE OR REPLACE VIEW vw_dashboard_qa AS
SELECT
  (SELECT COUNT(*) FROM Bin_Master WHERE Current_Status='Awaiting_QA' AND Is_Active=1) AS awaiting_qa,
  (SELECT COUNT(*) FROM Bin_Master WHERE Current_Status='Awaiting_Reinspection' AND Is_Active=1) AS awaiting_reinspection,
  (SELECT COUNT(*) FROM QA_Record WHERE DATE(QA_Start_At)=CURDATE() AND Overall_Result='FAIL') AS today_failures,
  COALESCE((SELECT ROUND(SUM(Overall_Result='PASS')*100.0/COUNT(*),1) FROM QA_Record WHERE QA_Start_At>=DATE_SUB(CURDATE(),INTERVAL 7 DAY)),0) AS pass_rate_week;

-- Average cycle time
CREATE OR REPLACE VIEW vw_avg_cycle_time AS
SELECT COALESCE(ROUND(AVG(Total_Cycle_Duration_Minutes)),0) AS avg_minutes
FROM Cycle_Record WHERE Cycle_End_At>=DATE_SUB(CURDATE(),INTERVAL 30 DAY);