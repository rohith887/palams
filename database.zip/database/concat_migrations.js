const fs = require('fs');
const path = require('path');

const migrationsDir = path.join(__dirname, 'migrations');
const outputFile = path.join(__dirname, 'PBLMS_Complete_Database.sql');

const order = [
  '000_create_schema_migrations_table.sql',
  '001_create_user_master.sql',
  '002_seed_admin_user.sql',
  '003_create_auth_procedures.sql',
  '004_create_master_tables.sql',
  '005_seed_master_data.sql',
  '006_create_bin_master.sql',
  '007_create_master_procedures.sql',
  '008_create_bin_registration_procedure.sql',
  '009_create_user_management_procedure.sql',
  '010_create_workflow_tables.sql',
  '011_seed_status_and_transitions.sql',
  '012_create_workflow_validation_procedure.sql',
  '013_create_lock_table.sql',
  '014_create_lock_procedures.sql',
  '015_create_history_audit_tables.sql',
  '016_create_history_audit_procedures.sql',
  '017_create_loading_record.sql',
  '018_create_loading_procedures.sql',
  '019_create_unloading_record.sql',
  '020_create_unloading_procedures.sql',
  '021_create_cleaning_procedures.sql',
  '022_create_qa_procedures.sql',
  '023_create_dashboard_views.sql',
  '024_create_dashboard_procedure.sql',
  '025_create_report_objects.sql',
  '026_create_report_procedure.sql',
  '027_create_audit_history_procedure.sql',
];

let combined = '-- =============================================================================\n';
combined += '-- PBLMS — Complete Database Installation Script\n';
combined += '-- Pharmaceutical Bin Lifecycle Management System\n';
combined += '--\n';
combined += '-- This script concatenates all 28 migrations (000 through 027)\n';
combined += '-- in sequential order for deployment on a fresh empty MySQL database.\n';
combined += '--\n';
combined += '-- Generated: ' + new Date().toISOString().slice(0, 10) + '\n';
combined += '-- =============================================================================\n\n';

for (let i = 0; i < order.length; i++) {
  const filename = order[i];
  const filePath = path.join(migrationsDir, filename);
  const content = fs.readFileSync(filePath, 'utf8');
  combined += '-- ============================================================\n';
  combined += '-- Migration ' + String(i).padStart(3,'0') + ': ' + filename + '\n';
  combined += '-- ============================================================\n\n';
  combined += content;
  combined += '\n\n';
}

fs.writeFileSync(outputFile, combined, 'utf8');
console.log('Output:', outputFile);
console.log('Size:', (combined.length / 1024).toFixed(1), 'KB');
console.log('Migrations:', order.length);

// Quick sanity check
for (const f of order) {
  if (!combined.includes(f.slice(0, 10))) {
    console.log('WARNING: ' + f + ' not found in output');
  }
}
console.log('All migrations verified in output.');